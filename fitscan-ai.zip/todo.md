# Project TODO

- [x] FitScan AI visual theme and design tokens
- [x] Original app icon and splash branding
- [ ] Welcome and privacy-first onboarding
- [ ] Fitness goals and baseline setup
- [x] Demo mode with labeled mock scan data
- [x] Home dashboard with empty and populated states
- [ ] Scan permission, setup, calibration, and guided capture flow
- [ ] Mock scan processing, quality, 3D result, and measurements
- [x] Progress timeline and movement assessment
- [ ] AI insights screen with confidence labeling
- [x] Profile, settings, privacy controls, and subscription screens
- [x] Centralized typed mock domain services and scan state
- [x] Unit/component test coverage for core flows
- [x] TypeScript, lint, and runtime verification
- [x] Typed AI core, scan, movement, and coach domain models
- [x] Provider interface and mock provider registry
- [x] AI feature flags and configuration defaults
- [x] AI request IDs, retry, timeout, and service error utilities
- [x] Safety-aware mock coach response contract
- [x] Structured fitness profile, goals, equipment, and movement-pattern types
- [x] Exercise catalog with safety notes and availability filtering
- [x] Workout templates and quick-start workout generator
- [x] Workout validation and session/timer state utilities
- [x] Neutral camera-assisted exercise feedback contracts
- [x] Production mobile shell and route registry
- [x] Reusable primary, secondary, premium card, header, and base card components
- [x] Responsive dimension and spacing helpers
- [x] Expanded five-tab navigation with Scan and Fitness destinations
- [x] Accessible press states and loading/disabled button behavior
- [x] Centralized UX tokens and typography scale
- [x] Surface, UX button, and header component variants
- [x] Fade-in, slide-up, stagger, and press-scale motion primitives
- [x] Accessible feedback patterns for loading, disabled, and interactive states
- [x] Core domain User, Scan, WorkoutSession, and Goal types
- [x] Result type and typed application error codes/factories
- [x] Generic repository interface and in-memory repository
- [x] API client with safe request results and endpoint registry
- [x] Auth state/service contracts without forcing account creation
- [x] Offline-first persistence and sync queue contracts
- [x] Scan, workout, progress, and AI orchestration service boundaries
- [x] Diagnostics, permissions, subscription, and feature-flag contracts
- [x] Complete onboarding, privacy, goals, and baseline setup routes
- [x] Complete scan result, confidence, AI insight, and coach routes
- [x] Add workout execution and timer interaction flow
- [x] Add AsyncStorage-backed persistence for profile, scans, and preferences
- [ ] Add navigation and state tests for the improved flows
- [x] Permission-aware scan entry and guided capture states
- [x] Confidence-labeled scan results and measurement explanations
- [x] AI insights and coach conversation route
- [x] Interactive workout session timer and completion state
- [ ] Tests for scan, coach, and workout navigation flows
- [x] Typed analytics models for scan, movement, workout, habit, goal, and recovery data
- [x] Normalization, cleaning, missing-data, completeness, and quality utilities
- [x] Statistics, trend, comparison, correlation, and anomaly utilities
- [x] Confidence-aware insight generation from longitudinal data
- [x] Connect analytics summaries to Progress and Coach screens
- [x] Add deterministic analytics tests and route verification
- [x] Typed camera capabilities, scan session states, calibration, framing, and pose models
- [x] Camera capability validation, permission recovery, orientation, distance, and framing utilities
- [x] Scan frame quality, visibility, landmark, coverage, and confidence utilities
- [x] Connect calibration and quality feedback to the guided scan UI
- [x] Add deterministic scan pipeline tests and validation states
- [x] Unified AI core models, errors, request builder, and output validation
- [x] AI provider adapters, router, orchestrator, model registry, and version policy
- [x] Confidence normalization and action/display confidence thresholds
- [x] AI input sanitization and versioned prompt templates
- [x] Vision frame, body detection, pose, measurement, and explanation contracts
- [x] Connect AI routing and confidence metadata to existing scan and coach services
- [x] Add deterministic AI platform tests and route validation
- [ ] Scan session state machine and failure reasons
- [ ] Camera capability, permission, orientation, and distance validation
- [ ] Calibration, framing, visibility, pose, coverage, and quality scoring utilities
- [ ] Calibration and quality feedback in the guided scan UI
- [ ] Deterministic scan pipeline tests and confidence validation
- [x] Connect the typed AI router and orchestrator to scan and coach services
- [x] Validate AI outputs and normalize confidence at service boundaries
- [x] Gate low-confidence recommendations and explain unavailable actions
- [x] Add scan failure recovery and retry states
- [x] Add deterministic scan/coach integration tests
- [x] Scan failure recovery, retry, and resumable session actions
- [x] Persist workout completion records alongside scan history
- [x] Surface persisted history in Progress and Fitness screens
- [x] Add deterministic reliability tests for recovery and persistence helpers
- [x] Surface persisted scan history in Progress
- [x] Surface persisted workout history in Fitness
- [x] Add reusable date and activity summary helpers
- [x] Add deterministic route and app-state utility tests
- [x] Scan detail route with confidence, measurements, and privacy context
- [x] Workout detail route with session summary and restart action
- [x] Navigate from persisted Progress and Fitness history cards
- [x] Add deterministic detail-route and activity-formatting tests
- [x] Improve first-time empty states across Home, Progress, Fitness, and Profile
- [x] Add onboarding completion confirmation and return-to-home action
- [x] Add route parameter and state utility validation tests
- [x] Platform-safe Expo Camera adapter with mock fallback
- [x] Camera permission and capability readiness state in Scan
- [x] Route and scan-state test helpers for core flows
- [x] Typed app configuration, runtime status, and global event bus
- [x] Profile service and user-readiness calculation
- [x] Home data aggregation and short-lived cache contracts
- [x] Cohesive scan/workout/coach/progress orchestration contracts
- [x] Sync, notifications, subscriptions, privacy export, and diagnostics contracts
- [x] Connect app status and event feedback to the mobile shell
- [x] Add deterministic architecture tests and route validation
- [x] Event-driven scan and workout lifecycle status state
- [x] Live scan status feedback from global events
- [x] Live workout status feedback from global events
- [x] Deterministic event/status integration tests
- [x] Emit SCAN_STARTED and SCAN_COMPLETED from the Scan screen
- [x] Emit WORKOUT_STARTED and WORKOUT_COMPLETED from the Workout screen
- [x] Validate live lifecycle status transitions with deterministic tests
- [x] Visible active scan/workout status banner
- [x] Explicit cancellation and interruption recovery states
- [x] Resume and discard actions for interrupted activity
- [x] Deterministic status-banner and recovery tests
- [x] Persist interrupted scan and workout session metadata
- [x] Add reusable resume/discard recovery helpers
- [x] Show active status banners on Progress and Fitness
- [x] Add deterministic interruption-recovery tests
- [x] Reusable resume/discard recovery banner
- [x] Visible recovery actions on Home and activity tabs
- [x] Safe resume routing for scan and workout sessions
- [x] Deterministic recovery-copy and state tests
- [x] Store precise scan view and workout round in interrupted activity state
- [x] Show recovery banner on Progress and Fitness
- [x] Resume scan/workout at the saved step when possible
- [x] Add deterministic recovery metadata tests
- [x] Typed personalization profile, preference signals, and user action models
- [x] Preference event store, validation, confidence, and ranking helpers
- [x] AI-v3 agent/task models, model registry, fallback chain, and calibration
- [x] Advanced vision/pose/measurement and safety contract utilities
- [x] Transparent subscription, entitlement, usage-limit, and mock billing models
- [ ] Environment, database, repository, API, migration, and offline infrastructure contracts
- [x] Connect personalization and entitlement summaries to Fitness, Coach, and Profile
- [x] Add deterministic tests for personalization, AI-v3, monetization, and infrastructure
- [x] Typed subscription plans, billing states, products, and entitlements
- [x] Usage tracker and non-blocking limit checker
- [x] Mock billing adapter with restore and purchase boundaries
- [x] Profile and Coach entitlement summaries without blocking basic scans
- [x] Deterministic monetization tests
- [x] Build a local personalization summary for coaching style, duration, and next-best action
- [x] Add free-plan entitlement summary and transparent premium affordance
- [x] Connect personalization summary to Coach responses
- [x] Connect entitlement summary to Profile
- [x] Add deterministic integration tests for Profile and Coach summaries
- [x] Transparent subscription route with free and premium comparison
- [x] Purchase and restore feedback using the billing boundary
- [x] Wire Profile subscription entry to the new route
- [x] Add deterministic subscription UI tests
- [x] Store precise scan view and workout round in interrupted activity state
- [x] Show recovery banner on Progress and Fitness
- [x] Resume scan/workout at the saved step when possible
- [x] Add deterministic recovery metadata tests
- [x] Align shared theme tokens with the supplied FitScan visual system
- [x] Refine reusable button/card primitives for accessible press states
- [ ] Apply calmer scan-first visual hierarchy to Home and Scan
- [x] Add deterministic UI token and interaction tests
- [x] Add scan-v4 typed session, stage, readiness, and quality contracts
- [x] Add Coach-v5 typed context, request, response, and safety contracts
- [ ] Connect scan quality and Coach limitations to existing routes
- [x] Add deterministic scan-v4 and Coach-v5 tests
- [x] Add workout-v6 typed models, preferences, constraints, and request contracts
- [x] Add equipment and difficulty matching plus adaptive planner helpers
- [x] Connect adaptive workout summary to Fitness and Workout journeys
- [x] Add deterministic workout-system tests
- [x] Add perceived-effort feedback controls to the Workout session
- [x] Show adaptive next-instruction guidance during workout execution
- [x] Persist completed workout feedback locally
- [x] Add deterministic workout feedback tests
- [x] Add supported language catalog with RTL metadata
- [x] Add offline translation dictionaries and fallback lookup
- [x] Add localized number, date, and unit format helpers
- [x] Add persistent language preference support
- [x] Connect navigation labels to the localization registry
- [x] Add deterministic i18n tests
- [x] Add language preference to persisted app state
- [x] Add Profile language picker using supported language metadata
- [x] Apply selected language to primary tab labels at runtime
- [x] Add deterministic language preference tests
- [x] Add localized Home, Scan, Coach, and Workout journey strings
- [x] Add reusable runtime translation access for feature screens
- [x] Connect Home, Scan, Coach, and Workout copy to persisted language state
- [x] Add deterministic journey-localization tests
- [x] Add reusable RTL direction and accessibility layout helpers
- [x] Add localized Progress, Profile, Scan, and subscription strings
- [x] Apply RTL metadata to the app shell and core surfaces
- [x] Add deterministic RTL and expanded localization tests
- [x] Store precise scan view and workout round in interrupted activity state
- [x] Show recovery banner on Progress and Fitness
- [x] Resume scan/workout at the saved step when possible
- [x] Add deterministic recovery metadata tests
- [x] Add scan-view and workout-round progress copy to RecoveryBanner
- [x] Add accessible recovery labels for precise resume context
- [x] Connect Home, Progress, and Fitness recovery placements to progress metadata
- [x] Add deterministic recovery-banner copy tests
- [x] Add localized recovery titles, body, progress, and action labels
- [x] Connect selected language to RecoveryBanner
- [x] Preserve precise progress in localized accessibility labels
- [x] Add deterministic localized recovery tests
- [x] Add localized scan-view progress formatter
- [x] Add localized workout-round progress formatter
- [x] Connect localized progress labels to Home and Progress recovery banners
- [x] Add deterministic localized progress-format tests
- [x] Add translated recovery progress templates for all remaining supported languages
- [x] Verify all supported languages have scan and workout progress coverage
- [x] Add deterministic all-language recovery formatter tests
- [x] Add namespaced translation lookup alongside flat keys
- [x] Add pluralization and interpolation helpers
- [x] Add translation version metadata
- [x] Add missing-key diagnostics without breaking fallback behavior
- [x] Add deterministic i18n architecture tests
- [x] Add personalization v7 typed signals and profile defaults
- [x] Add recency-aware signal scoring and aggregation
- [x] Add feedback extraction and next-best-action selection
- [x] Connect explainable personalization confidence to Fitness, Coach, and Profile
- [x] Add deterministic personalization v7 tests
- [x] Add persisted scan-to-signal adapter
- [x] Add persisted workout and effort-to-signal adapter
- [x] Replace Profile and Coach derived inputs with local history signals
- [x] Add deterministic persisted-signal adapter tests
- [x] Persist bounded perceived-effort feedback on completed workouts
- [x] Convert stored effort feedback into personalization v7 signals
- [x] Use effort signals in Profile and Coach recommendations
- [x] Add deterministic effort-signal tests
- [x] Add deterministic perceived-effort trend aggregation
- [x] Add effort trend interpretation and empty-state helpers
- [x] Connect a privacy-first effort trend card to Progress
- [x] Add deterministic effort-trend tests
- [x] Add deterministic recent-effort series helper
- [x] Add accessible labels for recent effort values
- [x] Connect a compact recent-effort visualization to Progress
- [x] Add deterministic effort-visualization tests
- [x] Add localized effort trend labels and interpretations
- [x] Add localized effort chart accessibility labels and empty state
- [x] Connect selected language to the Progress effort trend card
- [x] Add deterministic effort-trend localization tests
- [x] Add bounded effort trend range options
- [x] Add deterministic workout filtering by selected date range
- [x] Connect localized range controls to the Progress effort card
- [x] Add deterministic effort range-selection tests
- [x] Persist the selected effort-trend range in AppState
- [x] Add localized 7-day, 30-day, and one-year range labels
- [x] Restore the saved range when Progress mounts
- [x] Add deterministic range-preference persistence tests
- [x] Complete full-screen translation coverage for Progress, Profile, and subscription copy
- [x] Localize remaining Progress labels and activity metadata
- [x] Localize Profile settings and personalization summaries
- [x] Localize subscription plan comparison and billing feedback
- [x] Add deterministic full-screen localization and RTL assertions
- [x] Add persisted coach tone, session duration, and difficulty preferences
- [x] Build editable Profile personalization controls
- [x] Feed saved preferences into recommendation generation
- [x] Add deterministic personalization preference tests
- [x] Add a pure difficulty-aware workout adaptation helper
- [x] Apply persisted difficulty to workout generation
- [x] Add a confirmed local personalization reset action
- [x] Add deterministic workout adaptation and reset tests
- [x] Add intermediate exercise definitions to the local catalog
- [x] Add advanced exercise definitions to the local catalog
- [x] Use a shared expanded catalog in Fitness quick-start planning
- [x] Add deterministic exact-match catalog and planner tests
- [x] Add persisted available-equipment preferences
- [x] Add equipment-aware catalog filtering with safe no-equipment fallback
- [x] Connect equipment preferences to Fitness quick-start planning
- [x] Add deterministic equipment selection and planner tests
- [x] Add pure AppState normalization for legacy persisted records
- [x] Validate and repair invalid personalization and equipment values during hydration
- [x] Use the migration helper in AsyncStorage hydration
- [x] Add deterministic legacy-state migration tests
- [x] Add explicit AppState schema version metadata
- [x] Add an idempotent migration pipeline for legacy local state
- [x] Persist the current schema version with hydrated state
- [x] Add deterministic version and idempotence migration tests
- [x] Expose typed local persistence readiness status from AppState
- [x] Add accessible Profile storage readiness card
- [x] Add deterministic persistence status tests
- [x] Restart the development service and verify validation health
- [x] Add dismissible local-state migration notice state
- [x] Add localized accessible repair notice UI to Profile
- [x] Add deterministic notice visibility and dismissal tests
- [x] Restore the development preview and verify service health
- [x] Extract a reusable LocalStorageNotice component
- [x] Preserve localized status messaging and dismiss behavior in Profile
- [x] Add deterministic notice helper tests
- [x] Validate the refactor and clean stale processes
- [x] Reuse LocalStorageNotice on Home
- [x] Reuse LocalStorageNotice on Progress
- [x] Preserve independent dismiss behavior and localized accessibility
- [x] Add deterministic cross-screen notice integration tests
- [x] Add persisted dismissed migration-notice version to AppState
- [x] Show migration notices only when the current version has not been dismissed
- [x] Persist dismissal from Home, Progress, and Profile
- [x] Add deterministic version-aware dismissal tests
- [x] Add a privacy-safe migration change summary helper
- [x] Add localized “Review what changed” notice action
- [x] Add an accessible details surface without sensitive data
- [x] Add deterministic migration-summary tests
- [x] Add a reusable local-privacy detail model
- [x] Add localized privacy-boundary copy
- [x] Connect “Learn about local privacy” to LocalStorageNotice
- [x] Add deterministic privacy-copy tests
- [x] Audit primary navigation and interactive handlers for dead ends
- [x] Repair broken or incomplete core-flow navigation
- [x] Harden scan, workout, recovery, profile, and subscription boundaries
- [x] Add deterministic core-flow behavior tests
- [x] Add typed Workout route-parameter parsing
- [x] Select the intended template or quick plan safely
- [x] Render selected plan details and exercises in Workout
- [x] Add deterministic route-plan selection tests
- [x] Add exercise-position metadata to interrupted workout state
- [x] Drive workout progression from every selected exercise
- [x] Restore the selected exercise position after interruption
- [x] Add deterministic multi-exercise recovery tests
- [x] Add pure exercise-prescription and progress helpers
- [x] Show catalog sets, reps, and rest in the Workout session
- [x] Use prescription rest values between exercises
- [x] Add deterministic prescription tests
- [x] Add typed visual frames and landmark data models
- [x] Add deterministic visual quality, normalization, and filtering helpers
- [x] Connect privacy-safe visual feedback to Scan
- [x] Add deterministic multimodal visual tests
- [ ] Inspect recent development-service logs and process state
- [ ] Restart Expo and API services safely under memory pressure
- [ ] Verify Scan and core routes after the multimodal changes
- [ ] Fix any runtime issues and add regression coverage
- [x] Add a platform-neutral supported-language normalizer
- [x] Detect device language safely with English fallback
- [x] Use device language only when no persisted user language exists
- [x] Add deterministic language-detection tests
- [x] Add pure foreground language-refresh decision logic
- [x] Refresh detected language when the app returns to foreground
- [x] Preserve explicit persisted language choices
- [x] Add deterministic foreground-refresh tests
- [x] Add Profile control to resume automatic device-language synchronization
- [x] Persist and migrate the device-language synchronization preference
- [x] Add localized copy and deterministic coverage for the synchronization preference
- [x] Resolve Scan hook dependency warning without changing lifecycle behavior
- [x] Remove unused Coach import
- [x] Stabilize Workout timer effect dependencies
- [x] Convert analytics Array<T> annotations to T[]
- [x] Extract deterministic workout timer transition logic
- [x] Prevent stale workout completion or recovery writes after unmount
- [x] Add regression coverage for workout timer transitions and interruption cleanup
- [x] Pause the workout timer when the app leaves the foreground
- [x] Persist the active workout position on lifecycle pause
- [x] Resume safely without losing the saved workout context
- [x] Add deterministic lifecycle pause/resume coverage
- [x] Add localized copy for automatic workout pause feedback
- [x] Show an accessible automatic-pause status indicator in Workout
- [x] Add deterministic coverage for automatic-pause feedback state
- [x] Localize Workout phase, exercise, timer, and privacy copy
- [x] Localize Workout completion summary and navigation actions
- [x] Add deterministic coverage for localized Workout copy
- [x] Add localized workout template-name helpers
- [x] Localize adaptive planner rationale strings
- [x] Render localized plan titles and rationale in Workout
- [x] Add deterministic coverage for localized planner presentation
- [x] Add locale-aware exercise name and instruction helpers
- [x] Render localized exercise guidance in Workout
- [x] Add deterministic coverage for catalog localization and fallback safety
- [x] Add locale-aware prescription summary helpers
- [x] Localize reps, timed targets, sets, and rest labels in Workout
- [x] Add deterministic coverage for localized prescription formatting
- [x] Add locale-aware adaptive coaching cue presentation
- [x] Localize adaptive cue accessibility labels in Workout
- [x] Add deterministic coverage for localized coaching cues
- [x] Add localized accessibility labels for Workout timer and phase
- [x] Add localized accessibility label for the prescription summary
- [x] Add deterministic coverage for Workout accessibility labels
- [x] Add localized accessibility labels for Scan quality and landmarks
- [x] Add localized accessibility labels for Progress trend and history summaries
- [x] Add deterministic Scan and Progress accessibility coverage
- [x] Add localized accessibility labels for Scan permission and privacy controls
- [x] Add localized accessibility labels for Scan capture and navigation controls
- [x] Add deterministic coverage for Scan control accessibility
- [x] Localize visible Scan permission and privacy guidance
- [x] Localize visible Scan setup, capture, and processing guidance
- [x] Add deterministic coverage for visible Scan guidance copy
- [x] Localize Scan result title, status, and measurement labels
- [x] Localize Scan result explanation and privacy note
- [x] Add deterministic coverage for localized Scan result copy
- [x] Localize Profile preference and personalization copy
- [x] Localize Profile privacy and local-storage copy
- [x] Add deterministic coverage for localized Profile copy
- [x] Add localized Profile action-name helpers
- [x] Localize the adaptive next-action recommendation sentence
- [x] Add deterministic coverage for localized Profile recommendations
- [ ] Add reduced-motion-safe shared animation primitives
- [ ] Animate Home, Progress, Profile, Scan, and Workout state transitions
- [ ] Add press feedback to primary interactive controls
- [ ] Add deterministic animation preference coverage

# Onboarding enhancement

- [x] Audit the current first-run entry points, persisted onboarding state, and navigation flow
- [x] Design a concise privacy-first onboarding sequence for scan setup and personalization
- [x] Implement localized, accessible, reduced-motion-safe onboarding interactions
- [x] Add deterministic onboarding state and localization tests
- [x] Verify onboarding buttons, back navigation, and persistence behavior

# Dynamic UI enhancement
- [x] Audit remaining static screens and interaction surfaces
- [x] Extend reduced-motion-safe transitions to remaining screens
- [x] Add native-feel press feedback to remaining interactive cards and controls
- [x] Add deterministic animation preference and interaction tests
- [x] Verify the animated app in the live preview

# Dynamic UI enhancement — interaction pass
- [x] Audit shared navigation and metric surfaces for motion opportunities
- [x] Design reusable press and metric motion behavior
- [x] Implement shared interaction feedback and high-value metric transitions
- [x] Run deterministic tests and verify dynamic interactions

# Dynamic UI enhancement — navigation pass
- [x] Audit remaining static navigation and metric surfaces
- [x] Design the next motion layer for navigation and changing values
- [x] Implement the new animated navigation and metric behaviors
- [x] Run tests and verify visual and interactive behavior

# Dynamic UI enhancement — route and result pass
- [x] Audit route transitions and result-state changes
- [x] Design a restrained transition and state-feedback pattern
- [x] Implement route and result-state motion improvements
- [x] Test motion behavior and verify key journeys

# Dynamic UI enhancement — route transition pass
- [x] Audit route transitions and result-state changes
- [x] Design a restrained transition and state-feedback pattern
- [x] Implement route and result-state motion improvements
- [x] Test motion behavior and verify key journeys

# Dynamic UI enhancement — animated feedback pass
- [x] Audit changing metrics and live feedback surfaces
- [x] Design accessible value and feedback motion behavior
- [x] Implement animated values and live activity feedback
- [x] Run tests and verify key motion journeys

# Dynamic UI enhancement — numeric result pass
- [x] Animate scan readiness and live quality values
- [x] Preserve standalone accessible value rendering
- [x] Validate animated feedback after runtime warning fix

# Error handling and fallback data
- [x] Audit current errors and data-loading boundaries
- [x] Define privacy-safe fallback mock data and degraded-state behavior
- [x] Implement defensive error handling and fallback data paths
- [x] Add deterministic failure-path tests and validate key routes

# Error handling and fallback data — follow-up
- [x] Audit latest runtime errors and remaining data boundaries
- [x] Define additional fallback records and recovery states
- [x] Implement remaining error handling and fallback paths
- [x] Add regression tests and verify critical routes

# Error handling and fallback data — final pass
- [x] Audit latest errors and unguarded data paths
- [x] Define targeted fallback and recovery behavior
- [x] Implement fixes, guards, and fallback mock data
- [x] Run regression tests and verify affected screens

# Hosted access
- [x] Generate a durable QR code for the hosted FitScan AI web app
- [x] Verify the QR asset encodes the stable hosted URL

# Code quality improvement pass — runtime warnings
- [x] Audit remaining runtime warnings and quality gaps

# Code quality improvement pass — resilient Progress history
- [x] Audit remaining hard-coded copy and interaction gaps
- [x] Prioritize localization and accessibility improvements
- [x] Implement the next code-quality improvements
- [x] Add regression tests and verify the preview

# Code quality improvement pass — unfinished items
- [x] Audit unfinished items and current quality signals
- [x] Prioritize the next safe high-value improvements
- [x] Implement the selected functional and quality fixes
- [x] Add regression tests and validate critical routes

# Code quality improvement pass — Scan Detail localization
- [x] Audit remaining hard-coded copy and interaction gaps
- [x] Prioritize localization and accessibility improvements
- [x] Implement the next code-quality improvements
- [x] Add regression tests and verify the preview

# Code quality improvement pass — next iteration
- [x] Audit unfinished items and validation signals
- [x] Prioritize the next safe high-value improvements
- [x] Implement the selected reliability and UX improvements
- [x] Add regression tests and verify critical routes

# Code quality improvement pass — flow coverage
- [x] Audit remaining unfinished flows and test gaps
- [x] Prioritize safe high-value improvements
- [x] Implement the selected functional and quality fixes
- [x] Add regression tests and verify critical routes

# Code quality improvement pass — functional completeness
- [x] Audit remaining functional and test-coverage gaps
- [x] Prioritize low-risk high-value improvements
- [x] Implement the selected code improvements
- [x] Add regression tests and validate critical routes

# Code quality improvement pass — localization and flow coverage
- [x] Audit hard-coded user-facing copy and missing Coach, Scan, and Workout flow tests
- [x] Prioritize safe localization and deterministic test refinements
- [x] Implement the selected improvements
- [x] Add regression tests and validate critical routes

# Code quality improvement pass — localized overlays and workout feedback
- [x] Audit missing non-English overlays and workout phase feedback opportunities
- [x] Prioritize focused low-risk refinements
- [x] Implement localization and phase-feedback improvements
- [x] Add regression tests and validate the critical flows

# Code quality improvement pass — lint configuration
- [x] Audit the ESLint module configuration warning
- [x] Choose the safest Expo-compatible correction
- [x] Implement and validate the configuration improvement

# Code quality improvement pass — motion preference and interaction coverage
- [x] Audit app-state preference persistence and interaction-test seams
- [x] Prioritize a safe motion-preference design
- [x] Implement persisted motion preference and interaction seams
- [x] Add regression tests and validate the app

# Code quality improvement pass — interaction-state coverage
- [x] Audit remaining interaction-test seams and current runtime status
- [x] Prioritize pure helper coverage over brittle UI tests
- [x] Implement deterministic interaction-state helpers and tests
- [x] Validate the app and save the next checkpoint

# Code quality improvement pass — Coach copy and Scan recovery coverage
- [x] Audit remaining Coach copy and Scan recovery state seams
- [x] Prioritize safe localized and pure-state refinements
- [x] Implement Coach localization and Scan recovery helpers
- [x] Add regression tests and validate the app

# Code quality improvement pass — Coach copy and Scan discard feedback
- [x] Audit remaining hard-coded Coach copy and Scan discard interaction
- [x] Prioritize localized and deterministic changes
- [x] Implement Coach copy and Scan feedback improvements
- [x] Add regression tests and validate the app

# Code quality improvement pass — localization regression coverage
- [x] Audit new Coach localization and Scan discard-feedback seams
- [x] Prioritize pure i18n and interaction assertions
- [x] Implement regression coverage and small hardening fixes
- [x] Validate the app and save the next checkpoint

# Code quality improvement pass — Home and Scan privacy copy
- [x] Audit remaining hard-coded Home and Scan copy
- [x] Prioritize focused translation and accessibility refinements
- [x] Implement localized Home and Scan copy
- [x] Add regression coverage and validate the app

# Code quality improvement pass — Home and Scan locale overlays
- [x] Audit the new Home and ScanSheet key set
- [x] Prioritize high-value translations and fallback safety
- [x] Implement non-English Home and ScanSheet overlays
- [x] Add locale regression coverage and validate

# Code quality improvement pass — Home status and fallback metadata
- [x] Audit Home status and fallback metadata seams
- [x] Prioritize copy changes with safe fallback behavior
- [x] Implement localized Home status and metadata copy
- [x] Add regression assertions and validate the app

# Code quality improvement pass — Home demo metrics
- [x] Audit Home demo metric literals and translation keys
- [x] Prioritize data-driven localized metric copy
- [x] Implement localized Home metric labels and notes
- [x] Add regression assertions and validate the app

# Code quality improvement pass — remaining Home metric locales
- [x] Audit remaining Home metric locale coverage
- [x] Prioritize consistent translations and fallback safety
- [x] Implement remaining Home metric overlays
- [x] Add all-locale regression coverage and validate

# Code quality improvement pass — Home values and lifecycle copy
- [x] Audit remaining Home value and lifecycle literals
- [x] Prioritize localized display formatting without changing data
- [x] Implement localized Home values and lifecycle copy
- [x] Add regression assertions and validate the app

# Code quality improvement pass — Home profile-aware display
- [x] Audit Home date and profile display sources
- [x] Prioritize local-first and privacy-safe display logic
- [x] Implement localized profile-aware Home display data
- [x] Add regression assertions and validate the app

# Code quality improvement pass — Home scan-history metadata
- [x] Audit Home scan-history metadata and demo labels
- [x] Prioritize privacy-safe date and label formatting
- [x] Implement localized scan-history metadata
- [x] Add regression assertions and validate the app

# Code quality improvement pass — shared activity metadata
- [x] Audit shared activity metadata helpers and route usage
- [x] Prioritize a privacy-safe shared formatting boundary
- [x] Implement shared localized activity metadata
- [x] Add deterministic tests and validate the app

# Code quality improvement pass — shared history coverage
- [x] Audit shared activity metadata consumers and tests
- [x] Prioritize low-risk shared formatting changes
- [x] Implement shared metadata formatting and route wiring
- [x] Add deterministic tests and validate the app

# Code quality improvement pass — Fitness localization and accessibility
- [x] Audit Fitness literals and activity metadata
- [x] Prioritize localized and accessible Fitness refinements
- [x] Implement localized Fitness labels and metadata
- [x] Add regression assertions and validate the app

# Code quality improvement pass — Fitness template localization
- [x] Audit Fitness template metadata and existing translation keys
- [x] Prioritize registry-backed template presentation
- [x] Implement localized Fitness templates and accessibility labels
- [x] Add deterministic regression coverage and validate

# Code quality improvement pass — Fitness template routing coverage
- [x] Audit Fitness template routing and subtitle coverage
- [x] Prioritize stable identifiers and safe locale overlays
- [x] Implement subtitle overlays and routing helper coverage
- [x] Validate the app and save the next checkpoint

# Code quality improvement pass — Fitness subtitle overlays
- [x] Audit Fitness template keys and route-ID seams
- [x] Prioritize complete locale coverage and stable navigation
- [x] Implement subtitle overlays and route-ID helper coverage
- [x] Validate the app and save the next checkpoint

# Code quality improvement pass — Fitness history and rationale
- [x] Audit Fitness history and rationale copy
- [x] Prioritize localized metadata with transparent fallback states
- [x] Implement localized Fitness history and rationale copy
- [x] Add regression assertions and validate the app

# Code quality improvement pass — adaptive copy and activity-card accessibility
- [x] Audit adaptive copy and activity-card accessibility seams
- [x] Prioritize reusable localized presentation helpers
- [x] Implement adaptive-copy and accessibility refinements
- [x] Add regression tests and validate the app

# Code quality improvement pass — equipment-aware template filtering
- [x] Audit equipment data and Fitness template eligibility seams
- [x] Prioritize transparent filtering with safe empty states
- [x] Implement equipment-aware Fitness filtering
- [x] Add deterministic tests and validate the app

# Code quality improvement pass — equipment-filter regression coverage
- [x] Audit equipment-filter helper and existing test conventions
- [x] Prioritize edge cases for equipment filtering
- [x] Implement deterministic equipment-filter tests and hardening
- [x] Validate the app and save the next checkpoint

# Code quality improvement pass — Fitness equipment filter control
- [x] Audit equipment preferences and filter UI seams
- [x] Prioritize explicit local-only filter semantics
- [x] Implement compact equipment filter controls
- [x] Add regression tests and validate the app
- [x] Prioritize safe compatibility improvements
- [x] Implement warning fixes and defensive refinements
- [x] Run regression validation and verify the preview

# Code quality improvement pass — follow-up
- [x] Audit remaining quality and functional gaps
- [x] Prioritize safe high-value improvements
- [x] Implement the next code-quality and UX fixes
- [x] Add regression tests and verify the preview

# Code quality improvement pass — localization and accessibility
- [ ] Audit remaining hard-coded copy and interaction gaps
- [ ] Prioritize localization and accessibility improvements
- [ ] Implement the next code-quality improvements
- [ ] Add regression tests and verify the preview

# Code quality improvement pass
- [ ] Audit current quality, accessibility, reliability, and functional gaps
- [ ] Prioritize safe high-value improvements
- [ ] Implement code and UX fixes
- [ ] Add regression coverage and validate the app


# Error handling hardening
- [x] Audit current build, runtime, and test errors
- [x] Trace affected error paths and define safe recovery behavior
- [x] Implement fixes and defensive error handling
- [x] Add deterministic regression tests and validate runtime behavior


# Code quality improvement pass — Scan cancellation Undo
- [x] Audit Scan cancellation and recovery state flow
- [x] Define bounded local Undo semantics
- [x] Implement localized Scan cancellation Undo
- [x] Add deterministic recovery tests and validate the app


# Code quality improvement pass — Scan localization completion
- [x] Audit Scan fallback strings and dictionary coverage
- [x] Define consistent localized Scan copy
- [x] Implement complete Scan localization coverage
- [x] Add localization regression tests and validate the app


# Code quality improvement pass — Scan and Fitness accessibility/RTL refinement
- [x] Audit Scan and Fitness accessibility and RTL seams
- [x] Define consistent selection and direction behavior
- [x] Implement accessibility and RTL refinements
- [x] Add deterministic accessibility tests and validate the app


# Code quality improvement pass — Scan Undo lifecycle hardening
- [x] Audit Scan Undo lifecycle and repeated-cancel behavior
- [x] Define safe cancellation notice semantics
- [x] Implement robust Scan Undo lifecycle handling
- [x] Add deterministic cleanup tests and validate the app


# Code quality improvement pass — Scan pointer-events cleanup
- [x] Audit deprecated Scan prop usage and test seams
- [x] Define safe pointer-events and accessibility behavior
- [x] Implement the Scan cleanup
- [x] Add regression coverage and validate the app


# Code quality improvement pass — Scan handler maintainability
- [x] Audit dense Scan handlers and dependencies
- [x] Define callback boundaries and state invariants
- [x] Refactor Scan cancellation and recovery handlers
- [x] Validate behavior and regression coverage


# Code quality improvement pass — Scan recovery hook
- [x] Audit Scan recovery state and effect dependencies
- [x] Define hook API and recovery invariants
- [x] Implement the focused Scan recovery hook
- [x] Add hook regression coverage and validate the app


# Code quality improvement pass — Scan Undo hook tests
- [x] Audit hook behavior and test harness conventions
- [x] Define deterministic timer assertions
- [x] Implement hook-level regression coverage
- [x] Validate and save the next checkpoint


# Code quality improvement pass — Fitness named styles
- [x] Audit Fitness inline styles and layout seams
- [x] Define stable named-style boundaries
- [x] Refactor Fitness control layout styles
- [x] Validate and save the next checkpoint


# Code quality improvement pass — shared press feedback
- [x] Audit shared animation primitives and Fitness pressed states
- [x] Define consistent reduced-motion-safe press feedback
- [x] Implement shared interaction feedback and Fitness adoption
- [x] Validate and save the next checkpoint


# Code quality improvement pass — Fitness selection accessibility
- [x] Audit Fitness selection labels and localization helpers
- [x] Define selected-state announcement semantics
- [x] Implement localized Fitness selection accessibility copy
- [x] Add regression assertions and validate the app


# Code quality improvement pass — pointerEvents compatibility
- [x] Trace remaining pointerEvents warning source
- [x] Define cross-platform non-interactive overlay behavior
- [x] Implement the pointerEvents compatibility cleanup
- [x] Validate and save the next checkpoint


# Code quality improvement pass — deprecated prop regression guard
- [x] Audit test setup and source-scan conventions
- [x] Define precise deprecated-prop guard semantics
- [x] Implement the source regression guard
- [x] Validate and save the next checkpoint


# Code quality improvement pass — Profile selection accessibility
- [x] Audit Profile preference controls and accessibility seams
- [x] Define consistent localized selection semantics
- [x] Implement Profile preference accessibility labels
- [x] Add regression assertions and validate the app


# Code quality improvement pass — Profile language and reminder accessibility
- [x] Audit Profile language and reminder accessibility seams
- [x] Define localized selection and switch semantics
- [x] Implement Profile language and reminder accessibility
- [x] Add regression assertions and validate the app


# Code quality improvement pass — Profile accessibility helper reuse
- [x] Audit repeated Profile accessibility props
- [x] Define reusable Profile control helpers
- [x] Implement Profile accessibility helper reuse
- [x] Add regression assertions and validate the app


# Code quality improvement pass — preview warning ownership
- [x] Trace the warning through source and logs
- [x] Determine safe ownership and remediation
- [x] Implement warning cleanup if app-owned
- [x] Validate and save the next checkpoint


# Code quality improvement pass — Profile preference components
- [x] Audit Profile preference rendering patterns
- [x] Define reusable preference option component boundaries
- [x] Implement reusable Profile preference components
- [x] Add regression assertions and validate the app


# Code quality improvement pass — Profile switch rows
- [x] Audit Profile switch-row patterns and dependencies
- [x] Define reusable switch-row component boundaries
- [x] Implement reusable Profile switch rows
- [x] Add regression assertions and validate the app


# Code quality improvement pass — Profile navigation rows
- [x] Audit Profile navigation-row patterns
- [x] Define reusable navigation-row boundaries
- [x] Implement reusable Profile navigation rows
- [x] Add regression assertions and validate the app


# Code quality improvement pass — Profile cards
- [x] Audit Profile storage and insight card rendering
- [x] Define focused card component boundaries
- [x] Implement reusable Profile card components
- [x] Add regression assertions and validate the app


# Code quality improvement pass — Profile hero card
- [x] Audit the remaining Profile hero card
- [x] Define the hero component contract
- [x] Implement the reusable Profile hero card
- [x] Validate and save the next checkpoint


# Code quality improvement pass — Profile commitments card
- [x] Audit the Profile commitments card
- [x] Define the commitments component contract
- [x] Implement the reusable commitments card
- [x] Validate and save the next checkpoint


# Code quality improvement pass — Profile feature directory
- [x] Audit extracted Profile component boundaries
- [x] Define feature-directory exports and dependency boundaries
- [x] Move Profile components and update screen imports
- [x] Validate and save the next checkpoint


# Code quality improvement pass — Profile modules
- [x] Audit Profile module boundaries and dependencies
- [x] Define focused Profile module interfaces
- [x] Split Profile cards controls and navigation modules
- [x] Validate and save the next checkpoint

