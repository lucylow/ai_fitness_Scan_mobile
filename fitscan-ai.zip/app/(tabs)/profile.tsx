export { default } from "@/components/profile/profile-screen";

export { default as ProfileScreen } from "@/components/profile/profile-screen";

