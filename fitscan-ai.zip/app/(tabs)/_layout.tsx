import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { translate } from "@/src/i18n";
import { useAppState } from "@/src/state/app-state";

export default function TabLayout() {
  const colors = useColors();
  const { state } = useAppState();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  return (
    <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: colors.tint, tabBarButton: HapticTab, tabBarStyle: { paddingTop: 8, paddingBottom: bottomPadding, height: 56 + bottomPadding, backgroundColor: colors.background, borderTopColor: colors.border, borderTopWidth: 0.5 } }}>
      <Tabs.Screen name="index" options={{ title: translate(state.language, "navigation.home"), tabBarIcon: ({ color }) => <IconSymbol size={25} name="house.fill" color={color} /> }} />
      <Tabs.Screen name="scan" options={{ title: translate(state.language, "navigation.scan"), tabBarIcon: ({ color }) => <IconSymbol size={25} name="camera.fill" color={color} /> }} />
      <Tabs.Screen name="fitness" options={{ title: translate(state.language, "navigation.fitness"), tabBarIcon: ({ color }) => <IconSymbol size={25} name="figure.walk" color={color} /> }} />
      <Tabs.Screen name="progress" options={{ title: translate(state.language, "navigation.progress"), tabBarIcon: ({ color }) => <IconSymbol size={25} name="chart.bar.fill" color={color} /> }} />
      <Tabs.Screen name="profile" options={{ title: translate(state.language, "navigation.profile"), tabBarIcon: ({ color }) => <IconSymbol size={25} name="person.crop.circle" color={color} /> }} />
    </Tabs>
  );
}
