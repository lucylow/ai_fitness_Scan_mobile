import { useMemo, useState } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { router } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { LocalStorageNotice } from "@/components/local-storage-notice";
import { APP_STATE_SCHEMA_VERSION, useAppState } from "@/src/state/app-state";
import { deriveAppStatus, statusLabel, useAppLifecycleStatus } from "@/src/app-status";
import { RecoveryBanner, StatusBanner } from "@/src/mobile/ui";
import { formatDate, formatNumber, formatRecoveryProgress, translate } from "@/src/i18n";
import { AnimatedProgress, AnimatedReveal } from "@/src/mobile/animations";
import { shouldUseFallbackData } from "@/src/fallback-data";

const colors = {
  background: "#F7F8FA",
  surface: "#FFFFFF",
  foreground: "#101114",
  muted: "#6B7280",
  border: "#E6E8EC",
  accent: "#5B5CE2",
  accentSoft: "#ECECFF",
  success: "#22A06B",
  warning: "#D98A00",
};

type ScanStage = "idle" | "setup" | "calibrating" | "capturing" | "processing" | "result";

const demoMetrics = [
  { labelKey: "home.metricScanQuality", value: 94, valueKind: "percent" as const, noteKey: "home.metricConfidence", tone: colors.success },
  { labelKey: "home.metricMovement", value: "home.metricGood", valueKind: "translation" as const, noteKey: "home.metricConsistency", tone: colors.accent },
  { labelKey: "home.metricProgress", value: 8, valueKind: "signedPercent" as const, noteKey: "home.metricMobility", tone: colors.success },
];

function Pill({ children, tone = colors.accentSoft }: { children: string; tone?: string }) {
  return <View style={[styles.pill, { backgroundColor: tone }]}><Text style={styles.pillText}>{children}</Text></View>;
}

function ActionButton({ label, onPress, secondary = false }: { label: string; onPress: () => void; secondary?: boolean }) {
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={({ pressed }) => [styles.actionButton, secondary && styles.secondaryButton, pressed && styles.pressed]}>
      <Text style={[styles.actionText, secondary && styles.secondaryActionText]}>{label}</Text>
      {!secondary && <Text style={styles.actionArrow}>↗</Text>}
    </Pressable>
  );
}

function MetricCard({ label, value, note, tone }: { label: string; value: string; note: string; tone: string }) {
  return (
    <View style={styles.metricCard}>
      <View style={[styles.metricDot, { backgroundColor: tone }]} />
      <Text style={styles.metricLabel}>{label}</Text>
      <Text style={styles.metricValue}>{value}</Text>
      <Text style={styles.metricNote}>{note}</Text>
    </View>
  );
}

function ScanSheet({ stage, language, onClose, onNext }: { stage: ScanStage; language: Parameters<typeof translate>[0]; onClose: () => void; onNext: () => void }) {
  const copy = useMemo(() => {
    if (stage === "setup") return { eyebrow: translate(language, "scan.setup.eyebrow"), title: translate(language, "scan.setup.title"), body: translate(language, "scan.setup.body"), button: translate(language, "scan.setup.button") };
    if (stage === "calibrating") return { eyebrow: translate(language, "scan.calibration.eyebrow"), title: translate(language, "scan.calibration.title"), body: translate(language, "scan.calibration.body"), button: translate(language, "scan.calibration.button") };
    if (stage === "capturing") return { eyebrow: translate(language, "scan.capture.eyebrow"), title: translate(language, "scan.capture.title"), body: translate(language, "scan.capture.body"), button: translate(language, "scan.capture.button") };
    if (stage === "processing") return { eyebrow: translate(language, "scan.processing.eyebrow"), title: translate(language, "scan.processing.title"), body: translate(language, "scan.processing.body"), button: translate(language, "scan.processing.button") };
    return { eyebrow: translate(language, "scan.result.eyebrow"), title: translate(language, "scan.result.sheetTitle"), body: translate(language, "scan.result.sheetBody"), button: translate(language, "scan.result.sheetButton") };
  }, [language, stage]);

  const progress = stage === "setup" ? 0.2 : stage === "calibrating" ? 0.4 : stage === "capturing" ? 0.65 : stage === "processing" ? 0.85 : 1;
  return (
    <View style={styles.sheetBackdrop}>
      <AnimatedReveal style={styles.scanSheet}>
        <View style={styles.sheetHandle} />
        <View style={styles.sheetTop}><Pill>{copy.eyebrow}</Pill><Pressable accessibilityRole="button" accessibilityLabel={translate(language, "home.closeScan")} onPress={onClose} style={({ pressed }) => [styles.closeButton, pressed && styles.pressed]}><Text style={styles.close}>{translate(language, "home.closeScan")}</Text></Pressable></View>
        <View style={styles.scanVisual}>
          <View style={styles.scanArc} /><View style={styles.scanPerson}><View style={styles.head} /><View style={styles.bodyShape} /></View>
          <View style={[styles.scanLine, { top: `${Math.max(15, progress * 78)}%` }]} />
        </View>
        <Text style={styles.sheetTitle}>{copy.title}</Text>
        <Text style={styles.sheetBody}>{copy.body}</Text>
        <View style={styles.progressTrack}><AnimatedProgress progress={progress} style={styles.progressFill} /></View>
        <ActionButton label={copy.button} onPress={onNext} />
        <Text style={styles.privacyNote}>{translate(language, "home.privateNote")}</Text>
      </AnimatedReveal>
    </View>
  );
}

export default function HomeScreen() {
  const [scanStage, setScanStage] = useState<ScanStage>("idle");
  const { state, updateState, addScan, clearInterruptedActivity, persistenceStatus } = useAppState();
  const [showStorageNotice, setShowStorageNotice] = useState(true);
  const usingFallback = shouldUseFallbackData(persistenceStatus, state.scans.length > 0 || state.workouts.length > 0);
  const demo = state.demoMode || usingFallback;
  const appStatus = deriveAppStatus(state);
  const lifecycleStatus = useAppLifecycleStatus();
  const isEmpty = !demo && state.scans.length === 0 && scanStage === "idle";
  const displayName = state.displayName.trim() || translate(state.language, "home.defaultName", "Alex");
  const avatarInitial = Array.from(displayName)[0]?.toUpperCase() ?? "A";
  const latestScan = state.scans[0];
  const latestScanMetadata = latestScan
    ? `${formatDate(latestScan.createdAt, state.language)} · ${translate(state.language, "home.guidedScan")}`
    : translate(state.language, "home.demoMetadata");

  const startScan = () => setScanStage("setup");
  const advanceScan = () => {
    setScanStage((current) => {
      if (current === "processing") {
        addScan({ id: `scan_${Date.now()}`, createdAt: Date.now(), quality: 94, status: "complete", label: translate(state.language, "home.guidedScan") });
        return "result";
      }
      return current === "setup" ? "calibrating" : current === "calibrating" ? "capturing" : current === "capturing" ? "processing" : "idle";
    });
  };

  return (
    <ScreenContainer containerClassName="bg-background" className="px-5">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}><View><Text style={styles.kicker}>{translate(state.language, "home.dateLabel", "FRIDAY, AUGUST 21")}</Text><Text style={styles.greeting}>{translate(state.language, "home.welcome")}, {displayName}</Text></View><Pressable accessibilityRole="button" accessibilityLabel={translate(state.language, "profile.title", "Open Profile")} style={({ pressed }) => [styles.avatar, pressed && styles.pressed]} onPress={() => router.push("/(tabs)/profile" as never)}><Text style={styles.avatarText}>{avatarInitial}</Text></Pressable></View>
        {showStorageNotice && <LocalStorageNotice language={state.language} status={persistenceStatus} noticeVersion={APP_STATE_SCHEMA_VERSION} dismissedVersion={state.dismissedMigrationNoticeVersion} onDismiss={() => { setShowStorageNotice(false); updateState({ dismissedMigrationNoticeVersion: APP_STATE_SCHEMA_VERSION }); }} />}
        {(lifecycleStatus.scanActive || lifecycleStatus.workoutActive) && <StatusBanner title={lifecycleStatus.scanActive ? translate(state.language, "home.scanInProgress") : translate(state.language, "home.workoutInProgress")} detail={translate(state.language, "home.activityForeground")} tone="accent" />}
        {state.interruptedActivity && <RecoveryBanner kind={state.interruptedActivity.kind} progress={state.interruptedActivity.kind === "scan" ? formatRecoveryProgress(state.language, "scan", (state.interruptedActivity.scanView ?? 0) + 1, state.interruptedActivity.totalSteps ?? 3) : formatRecoveryProgress(state.language, "workout", state.interruptedActivity.workoutRound ?? 1, state.interruptedActivity.totalSteps ?? 3)} onResume={() => router.push(state.interruptedActivity?.kind === "scan" ? "/(tabs)/scan" as never : "/workout" as never)} onDiscard={clearInterruptedActivity} />}
        <AnimatedReveal delay={40}><View style={styles.heroCard}>
          <View style={styles.heroCopy}><Pill>{demo ? translate(state.language, "home.demoMode", "DEMO MODE") : translate(state.language, "home.nextStep", "YOUR NEXT STEP")}</Pill><Text style={styles.heroTitle}>{isEmpty ? translate(state.language, "home.nextStepTitle") : translate(state.language, "home.heroProgressTitle")}</Text><Text style={styles.heroBody}>{isEmpty ? translate(state.language, "home.nextStepBody") : translate(state.language, "home.heroProgressBody")}</Text></View>
          <View style={styles.heroOrb}><View style={styles.orbRing} /><View style={styles.orbDot} /></View>
        </View></AnimatedReveal>
        <AnimatedReveal delay={100}><ActionButton label={isEmpty ? translate(state.language, "home.startScan") : translate(state.language, "scan.start")} onPress={startScan} /></AnimatedReveal>
        {isEmpty ? <><Pressable accessibilityRole="button" accessibilityLabel={translate(state.language, "home.demoLink")} onPress={() => updateState({ demoMode: true })} style={({ pressed }) => [styles.demoLink, pressed && styles.pressed]}><Text style={styles.demoLinkText}>{translate(state.language, "home.demoLink")}</Text><Text style={styles.demoChevron}>›</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel={translate(state.language, "home.personalize")} onPress={() => router.push("/onboarding" as never)} style={({ pressed }) => [styles.setupLink, pressed && styles.pressed]}><Text style={styles.setupLinkText}>{translate(state.language, "home.personalize")}</Text></Pressable></> : <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>{translate(state.language, "home.snapshot")}</Text><Pressable onPress={() => router.push("/(tabs)/progress" as never)} accessibilityRole="button" accessibilityLabel={translate(state.language, "progress.title", "See all progress")} style={({ pressed }) => [pressed && styles.pressed]}><Text style={styles.sectionLink}>{translate(state.language, "home.seeAll")}</Text></Pressable></View>}
        {!isEmpty && <AnimatedReveal delay={160}><View style={styles.metricsRow}>{demoMetrics.map((metric) => <MetricCard key={metric.labelKey} label={translate(state.language, metric.labelKey)} value={metric.valueKind === "translation" ? translate(state.language, metric.value) : `${metric.valueKind === "signedPercent" ? "+" : ""}${formatNumber(metric.value, state.language)}%`} note={translate(state.language, metric.noteKey)} tone={metric.tone} />)}</View></AnimatedReveal>}
        <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>{isEmpty ? translate(state.language, "home.why") : translate(state.language, "home.latestScan")}</Text>{!isEmpty && <Text style={styles.meta}>{usingFallback ? translate(state.language, "home.sampleRecovery") : latestScanMetadata}</Text>}</View>
        <AnimatedReveal delay={220}><View style={styles.insightCard}><View style={styles.insightIcon}><Text style={styles.insightIconText}>✦</Text></View><View style={styles.insightCopy}><Text style={styles.insightTitle}>{isEmpty ? translate(state.language, "home.progressNotPerfection") : translate(state.language, "home.movementSteady")}</Text><Text style={styles.insightBody}>{isEmpty ? translate(state.language, "home.progressNotPerfectionBody") : translate(state.language, "home.movementSteadyBody")}</Text></View><Text style={styles.cardChevron}>›</Text></View></AnimatedReveal>
        <AnimatedReveal delay={280}><View style={styles.trustRow}><Text style={styles.trustIcon}>◉</Text><Text style={styles.trustText}>{translate(state.language, "scan.private")} · {statusLabel(appStatus)} · {translate(state.language, "home.estimatesNote")}</Text></View></AnimatedReveal>
      </ScrollView>
      {scanStage !== "idle" && <ScanSheet stage={scanStage} language={state.language} onClose={() => setScanStage("idle")} onNext={advanceScan} />}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 14, paddingBottom: 32, gap: 18 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  kicker: { color: colors.muted, fontSize: 11, fontWeight: "700", letterSpacing: 1.3 },
  greeting: { color: colors.foreground, fontSize: 25, fontWeight: "800", marginTop: 6 },
  avatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center" },
  avatarText: { color: "#FFF", fontSize: 16, fontWeight: "800" },
  heroCard: { backgroundColor: colors.foreground, borderRadius: 28, padding: 22, minHeight: 232, overflow: "hidden", flexDirection: "row" },
  heroCopy: { flex: 1, zIndex: 2 },
  pill: { alignSelf: "flex-start", borderRadius: 99, paddingHorizontal: 10, paddingVertical: 6 },
  pillText: { color: colors.accent, fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  heroTitle: { color: "#FFF", fontSize: 28, lineHeight: 34, fontWeight: "800", marginTop: 18, maxWidth: 230 },
  heroBody: { color: "#B8BAC6", fontSize: 14, lineHeight: 21, marginTop: 12, maxWidth: 240 },
  heroOrb: { position: "absolute", right: -34, bottom: -38, width: 190, height: 190, borderRadius: 95, backgroundColor: "#26274B", alignItems: "center", justifyContent: "center" },
  orbRing: { width: 112, height: 112, borderRadius: 56, borderWidth: 2, borderColor: colors.accent, opacity: 0.9 },
  orbDot: { position: "absolute", width: 16, height: 16, borderRadius: 8, backgroundColor: "#A5A6FF", top: 36, left: 55 },
  actionButton: { minHeight: 56, borderRadius: 18, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center", flexDirection: "row", paddingHorizontal: 18 },
  secondaryButton: { backgroundColor: colors.accentSoft },
  pressed: { opacity: 0.82, transform: [{ scale: 0.985 }] },
  actionText: { color: "#FFF", fontSize: 16, fontWeight: "800", textTransform: "capitalize" },
  secondaryActionText: { color: colors.accent },
  actionArrow: { color: "#FFF", fontSize: 20, marginLeft: 10, marginTop: -2 },
  demoLink: { alignItems: "center", flexDirection: "row", justifyContent: "center", gap: 6, marginTop: -6 },
  demoLinkText: { color: colors.accent, fontSize: 14, fontWeight: "700" },
  demoChevron: { color: colors.accent, fontSize: 20 },
  setupLink: { alignItems: "center", marginTop: -8 },
  setupLinkText: { color: colors.muted, fontSize: 12, fontWeight: "700" },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 4 },
  sectionTitle: { color: colors.foreground, fontSize: 19, fontWeight: "800" },
  sectionLink: { color: colors.accent, fontSize: 13, fontWeight: "700" },
  meta: { color: colors.muted, fontSize: 12 },
  metricsRow: { flexDirection: "row", gap: 10 },
  metricCard: { flex: 1, backgroundColor: colors.surface, borderRadius: 18, padding: 14, borderWidth: 1, borderColor: colors.border, minHeight: 128 },
  metricDot: { width: 8, height: 8, borderRadius: 4, marginBottom: 11 },
  metricLabel: { color: colors.muted, fontSize: 11, lineHeight: 14 },
  metricValue: { color: colors.foreground, fontSize: 21, fontWeight: "800", marginTop: 8 },
  metricNote: { color: colors.muted, fontSize: 10, lineHeight: 14, marginTop: 4 },
  insightCard: { backgroundColor: colors.surface, borderRadius: 20, borderWidth: 1, borderColor: colors.border, padding: 16, flexDirection: "row", alignItems: "center" },
  insightIcon: { width: 40, height: 40, borderRadius: 14, backgroundColor: colors.accentSoft, alignItems: "center", justifyContent: "center" },
  insightIconText: { color: colors.accent, fontSize: 20 },
  insightCopy: { flex: 1, marginLeft: 12 },
  insightTitle: { color: colors.foreground, fontSize: 15, fontWeight: "800" },
  insightBody: { color: colors.muted, fontSize: 13, lineHeight: 18, marginTop: 4 },
  cardChevron: { color: colors.muted, fontSize: 24, marginLeft: 8 },
  trustRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", marginTop: 2 },
  trustIcon: { color: colors.success, fontSize: 13, marginRight: 6 },
  trustText: { color: colors.muted, fontSize: 11 },
  sheetBackdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(16,17,20,0.52)", justifyContent: "flex-end", zIndex: 10 },
  scanSheet: { backgroundColor: colors.background, borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 22, paddingBottom: 30, minHeight: 530 },
  sheetHandle: { width: 42, height: 5, borderRadius: 3, backgroundColor: colors.border, alignSelf: "center", marginBottom: 20 },
  sheetTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  closeButton: { paddingVertical: 6, paddingHorizontal: 4 },
  close: { color: colors.muted, fontSize: 13, fontWeight: "700" },
  scanVisual: { height: 220, backgroundColor: colors.foreground, borderRadius: 24, marginTop: 18, overflow: "hidden", alignItems: "center", justifyContent: "center" },
  scanArc: { position: "absolute", width: 180, height: 180, borderRadius: 90, borderWidth: 1, borderColor: "#7778E8", opacity: 0.5 },
  scanPerson: { alignItems: "center" },
  head: { width: 38, height: 38, borderRadius: 19, backgroundColor: "#D9DAFF", marginBottom: 8 },
  bodyShape: { width: 74, height: 104, borderRadius: 36, backgroundColor: "#7778E8" },
  scanLine: { position: "absolute", left: 20, right: 20, height: 2, backgroundColor: "#C0C1FF", boxShadow: "0px 0px 10px #C0C1FF" },
  sheetTitle: { color: colors.foreground, fontSize: 25, fontWeight: "800", marginTop: 20 },
  sheetBody: { color: colors.muted, fontSize: 15, lineHeight: 22, marginTop: 8 },
  progressTrack: { height: 5, borderRadius: 3, backgroundColor: colors.border, marginVertical: 18, overflow: "hidden" },
  progressFill: { height: 5, borderRadius: 3, backgroundColor: colors.accent },
  privacyNote: { color: colors.muted, fontSize: 11, textAlign: "center", marginTop: 14 },
});
