import { useEffect, useRef, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { AppState as NativeAppState, Pressable, StyleSheet, Text, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { PrimaryButton, SecondaryButton } from "@/src/mobile/ui";
import { useAppState } from "@/src/state/app-state";
import { appEvents } from "@/src/app-platform";
import { planWorkout } from "@/src/workouts/v6";
import { localExerciseCatalog } from "@/src/workout-catalog";
import { difficultyAwareCatalog, equipmentAwareCatalog, clampSessionDuration } from "@/src/workout-adaptation";
import { normalizeWorkoutTemplate } from "@/src/workout-route";
import { localizedPrescriptionSummary, prescriptionForExercise } from "@/src/workout-prescription";
import { translate } from "@/src/i18n";
import { advanceWorkoutTimer, shouldCommitWorkoutCompletion, shouldPauseWorkoutForAppState, shouldPersistWorkoutRecovery } from "@/src/workout-timer";
import { localizedWorkoutLaunchTitle, localizedWorkoutPlanRationale, localizedWorkoutPlanTitle } from "@/src/workout-presentation";
import { localizedExerciseInstruction, localizedExerciseName } from "@/src/exercise-presentation";
import { localizedAdaptiveCue, localizedAdaptiveCueAccessibilityLabel } from "@/src/adaptive-cue-presentation";
import { localizedWorkoutPrescriptionAccessibilityLabel, localizedWorkoutTimerAccessibilityLabel } from "@/src/workout-accessibility";
import { AnimatedProgress, AnimatedReveal } from "@/src/mobile/animations";

const c = { ink: "#101114", muted: "#6B7280", accent: "#5B5CE2", soft: "#ECECFF", green: "#E8F7F0", border: "#E6E8EC" };

export default function WorkoutScreen() {
  const { state, addWorkout, setInterruptedActivity, clearInterruptedActivity } = useAppState();
  const params = useLocalSearchParams<{ template?: string | string[] }>();
  const template = normalizeWorkoutTemplate(params.template);
  const objective = template === "Mobility" || template === "Recovery" ? "mobility" : "mixed";
  const plan = planWorkout(difficultyAwareCatalog(equipmentAwareCatalog(localExerciseCatalog, state.availableEquipment), state.preferredDifficulty), { userId: "local-user", durationMinutes: clampSessionDuration(state.preferredDurationMinutes), objective, difficulty: state.preferredDifficulty, equipment: state.availableEquipment, constraints: { maximumExercises: 3 } });
  const recoveredWorkout = state.interruptedActivity?.kind === "workout" ? state.interruptedActivity : undefined;
  const localizedLaunchTitle = localizedWorkoutLaunchTitle(state.language, template);
  const localizedPlanTitle = localizedWorkoutPlanTitle(state.language, plan);
  const localizedPlanRationale = localizedWorkoutPlanRationale(state.language, plan);
  const totalExercises = Math.max(1, plan.exerciseIds.length);
  const recoveredExerciseIndex = recoveredWorkout?.exerciseIndex ?? Math.max(0, (recoveredWorkout?.workoutRound ?? 1) - 1);
  const [exerciseIndex, setExerciseIndex] = useState(Math.max(0, Math.min(totalExercises - 1, recoveredExerciseIndex)));
  const activeExercise = localExerciseCatalog.find((exercise) => exercise.id === plan.exerciseIds[exerciseIndex]) ?? localExerciseCatalog[0];
  const prescription = prescriptionForExercise(activeExercise);
  const workoutId = useRef(recoveredWorkout?.id ?? `workout_${Date.now()}`);
  const [seconds, setSeconds] = useState(recoveredWorkout?.secondsRemaining ?? (recoveredWorkout?.step === "rest" ? 20 : 30));
  const [recorded, setRecorded] = useState(false);
  const [phase, setPhase] = useState<"work" | "rest" | "complete">(recoveredWorkout?.step === "rest" ? "rest" : "work");
  const [paused, setPaused] = useState(recoveredWorkout?.pausedByLifecycle ?? false);
  const [round, setRound] = useState(Math.max(1, Math.min(totalExercises, recoveredWorkout?.workoutRound ?? recoveredExerciseIndex + 1)));
  const [effort, setEffort] = useState(6);
  const [feedbackSaveFailed, setFeedbackSaveFailed] = useState(false);
  const mountedRef = useRef(true);
  const completionCommittedRef = useRef(false);
  const lifecyclePausedRef = useRef(recoveredWorkout?.pausedByLifecycle ?? false);
  const sessionRef = useRef({ phase, seconds, exerciseIndex, totalExercises });
  sessionRef.current = { phase, seconds, exerciseIndex, totalExercises };
  const instruction = localizedAdaptiveCue(state.language, exerciseIndex, totalExercises, effort);
  const instructionAccessibilityLabel = localizedAdaptiveCueAccessibilityLabel(state.language, exerciseIndex, totalExercises, effort);
  const currentExerciseLabel = phase === "work" ? localizedExerciseName(state.language, activeExercise) : translate(state.language, "workout.breathe");
  const timerAccessibilityLabel = localizedWorkoutTimerAccessibilityLabel(state.language, currentExerciseLabel, phase === "complete" ? "work" : phase, seconds);
  const prescriptionAccessibilityLabel = localizedWorkoutPrescriptionAccessibilityLabel(state.language, prescription);

  useEffect(() => () => { mountedRef.current = false; }, []);

  useEffect(() => {
    if (!shouldPersistWorkoutRecovery(mountedRef.current, phase)) return;
    setInterruptedActivity({ kind: "workout", id: workoutId.current, step: phase, workoutRound: exerciseIndex + 1, exerciseIndex, totalSteps: totalExercises, secondsRemaining: sessionRef.current.seconds, pausedByLifecycle: lifecyclePausedRef.current, updatedAt: Date.now() });
    appEvents.emit({ type: "WORKOUT_STARTED", workoutId: workoutId.current });
  }, [exerciseIndex, phase, round, setInterruptedActivity, totalExercises]);

  useEffect(() => {
    const subscription = NativeAppState.addEventListener("change", (nextState) => {
      if (!shouldPauseWorkoutForAppState(nextState) || !shouldPersistWorkoutRecovery(mountedRef.current, sessionRef.current.phase)) return;
      lifecyclePausedRef.current = true;
      setPaused(true);
      const current = sessionRef.current;
      setInterruptedActivity({ kind: "workout", id: workoutId.current, step: current.phase, workoutRound: current.exerciseIndex + 1, exerciseIndex: current.exerciseIndex, totalSteps: current.totalExercises, secondsRemaining: current.seconds, pausedByLifecycle: true, updatedAt: Date.now() });
    });
    return () => subscription.remove();
  }, [setInterruptedActivity]);

  useEffect(() => {
    if (!mountedRef.current) return;
    if (shouldCommitWorkoutCompletion(mountedRef.current, phase, recorded || completionCommittedRef.current)) {
      completionCommittedRef.current = true;
      addWorkout({ id: workoutId.current, completedAt: Date.now(), durationMinutes: plan.durationMinutes, label: localizedLaunchTitle, effort: Math.max(1, Math.min(10, effort)) });
      void AsyncStorage.setItem(`fitscan:workout-feedback:${workoutId.current}`, JSON.stringify({ effort, rounds: totalExercises, savedAt: Date.now() })).catch(() => setFeedbackSaveFailed(true));
      clearInterruptedActivity();
      appEvents.emit({ type: "WORKOUT_COMPLETED", workoutId: workoutId.current });
      setRecorded(true);
      return;
    }
    if (paused || phase === "complete") return;
    const timer = setInterval(() => setSeconds((current) => {
      if (!mountedRef.current) return current;
      const transition = advanceWorkoutTimer({ phase, seconds: current, exerciseIndex, totalExercises, restSeconds: prescription.restSeconds });
      if (transition.advancedExercise) {
        setExerciseIndex(transition.exerciseIndex);
        setRound((currentRound) => currentRound + 1);
      }
      if (transition.phase !== phase) setPhase(transition.phase);
      return transition.seconds;
    }), 1000);
    return () => clearInterval(timer);
  }, [addWorkout, clearInterruptedActivity, effort, exerciseIndex, paused, phase, plan.durationMinutes, prescription.restSeconds, recorded, round, template, totalExercises, localizedLaunchTitle]);

  const togglePaused = () => {
    const nextPaused = !paused;
    lifecyclePausedRef.current = false;
    if (shouldPersistWorkoutRecovery(mountedRef.current, sessionRef.current.phase)) {
      const current = sessionRef.current;
      setInterruptedActivity({ kind: "workout", id: workoutId.current, step: current.phase, workoutRound: current.exerciseIndex + 1, exerciseIndex: current.exerciseIndex, totalSteps: current.totalExercises, secondsRemaining: current.seconds, pausedByLifecycle: false, updatedAt: Date.now() });
    }
    setPaused(nextPaused);
  };

  if (phase === "complete") return <ScreenContainer className="px-5" containerClassName="bg-background"><View style={styles.complete}><AnimatedReveal><View style={styles.completeIcon}><Text style={styles.completeIconText}>✓</Text></View></AnimatedReveal><Text style={styles.title}>{translate(state.language, "workout.completed.title")}</Text><Text style={styles.subtitle}>{feedbackSaveFailed ? translate(state.language, "workout.completed.feedbackSaveFailed") : translate(state.language, "workout.completed.body", "You completed your session in {minutes} minutes. Your effort feedback was saved locally for future recommendations.", { minutes: plan.durationMinutes })}</Text><View style={styles.summary}><Text style={styles.summaryTitle}>{translate(state.language, "workout.completed.summary")}</Text><View style={styles.summaryRow}><Text style={styles.summaryLabel}>{translate(state.language, "workout.completed.rounds")}</Text><Text style={styles.summaryValue}>{totalExercises}</Text></View><View style={styles.summaryRow}><Text style={styles.summaryLabel}>{translate(state.language, "workout.completed.effort")}</Text><Text style={styles.summaryValue}>{effort}/10</Text></View><View style={styles.summaryRow}><Text style={styles.summaryLabel}>{translate(state.language, "workout.completed.nextTime")}</Text><Text style={styles.summaryValue}>{translate(state.language, effort >= 9 ? "workout.completed.easeBack" : effort <= 4 ? "workout.completed.progressSlowly" : "workout.completed.repeatRhythm")}</Text></View></View><PrimaryButton title={translate(state.language, "navigation.fitness")} onPress={() => router.back()} /></View></ScreenContainer>;

  return <ScreenContainer className="px-5" containerClassName="bg-background"><View style={styles.session}><Pressable onPress={() => { clearInterruptedActivity(); router.back(); }} accessibilityRole="button"><Text style={styles.back}>‹ {translate(state.language, "workout.back")}</Text></Pressable><Text style={styles.kicker}>{localizedPlanTitle.toUpperCase()} · {translate(state.language, "workout.exerciseProgress", "Exercise {current} of {total}", { current: exerciseIndex + 1, total: totalExercises }).toUpperCase()}</Text><AnimatedReveal delay={40}><Text style={styles.exercise}>{phase === "work" ? localizedExerciseName(state.language, activeExercise) : translate(state.language, "workout.breathe")}</Text></AnimatedReveal><Text style={styles.instruction}>{phase === "work" ? localizedExerciseInstruction(state.language, activeExercise) : translate(state.language, "workout.takeAMoment")}</Text><Text style={styles.prescription} accessibilityRole="text" accessibilityLabel={prescriptionAccessibilityLabel}>{localizedPrescriptionSummary(state.language, prescription)}</Text><AnimatedReveal delay={100} key={`${phase}-${exerciseIndex}`}><View style={styles.timer} accessible accessibilityRole="text" accessibilityLabel={timerAccessibilityLabel}><Text style={styles.phase}>{translate(state.language, phase === "work" ? "workout.phase.work" : "workout.phase.rest").toUpperCase()}</Text><AnimatedReveal key={`phase-cue-${phase}-${exerciseIndex}`} delay={0}><Text style={styles.phaseCue}>{translate(state.language, phase === "work" ? "workout.phaseCue.work" : "workout.phaseCue.rest")}</Text></AnimatedReveal><Text style={styles.seconds}>{seconds}</Text><Text style={styles.secondsLabel}>{translate(state.language, "workout.seconds")}</Text></View></AnimatedReveal><View style={styles.progressTrack}><AnimatedProgress progress={(exerciseIndex / totalExercises) + (phase === "rest" ? 0.12 : 0.28 / totalExercises)} style={styles.progressFill} /></View><AnimatedReveal delay={180}><View style={styles.feedback}><Text style={styles.feedbackTitle}>{translate(state.language, "workout.effort")}</Text><Text style={styles.feedbackBody}>{translate(state.language, "workout.feedbackBody")}</Text><View style={styles.effortRow}>{[3, 6, 9].map((value) => <Pressable key={value} onPress={() => setEffort(value)} accessibilityRole="button" accessibilityLabel={translate(state.language, "workout.effortOption", `Effort ${value} out of 10`, { value })} style={[styles.effort, effort === value && styles.effortSelected]}><Text style={[styles.effortText, effort === value && styles.effortTextSelected]}>{value}</Text></Pressable>)}</View><Text style={styles.adaptive} accessibilityRole="text" accessibilityLabel={instructionAccessibilityLabel}>{instruction}</Text></View></AnimatedReveal>{paused && lifecyclePausedRef.current && <AnimatedReveal delay={220}><View style={styles.autoPauseCard} accessible accessibilityRole="alert" accessibilityLabel={`${translate(state.language, "workout.pausedBySystem")} ${translate(state.language, "workout.pausedBySystemDetail")}`}><Text style={styles.autoPauseTitle}>{translate(state.language, "workout.pausedBySystem")}</Text><Text style={styles.autoPauseDetail}>{translate(state.language, "workout.pausedBySystemDetail")}</Text></View></AnimatedReveal>}<PrimaryButton title={paused ? translate(state.language, "workout.resume") : translate(state.language, "workout.pause")} onPress={togglePaused} /><SecondaryButton title={translate(state.language, "workout.skip")} onPress={() => { setPhase("rest"); setSeconds(prescription.restSeconds); }} /><Text style={styles.note}>{localizedPlanRationale} {translate(state.language, "workout.cameraOptional")}</Text></View></ScreenContainer>;
}

const styles = StyleSheet.create({ session: { flex: 1, paddingTop: 16, gap: 16 }, back: { color: c.accent, fontSize: 15, fontWeight: "800", marginBottom: 12 }, kicker: { color: c.muted, fontSize: 11, fontWeight: "800", letterSpacing: 1.3 }, exercise: { color: c.ink, fontSize: 32, fontWeight: "900", marginTop: -6 }, instruction: { color: c.muted, fontSize: 15, lineHeight: 21, marginTop: -8 }, prescription: { color: c.accent, fontSize: 13, fontWeight: "800", marginTop: -8 }, timer: { flex: 1, minHeight: 240, borderRadius: 145, backgroundColor: c.ink, alignItems: "center", justifyContent: "center", marginVertical: 2 }, phase: { color: "#BFC0FF", fontSize: 11, fontWeight: "800", letterSpacing: 1.5 }, phaseCue: { color: "#FFFFFF", fontSize: 13, fontWeight: "700", marginTop: 5, marginBottom: 1 }, seconds: { color: "#FFF", fontSize: 76, fontWeight: "900", lineHeight: 86 }, secondsLabel: { color: "#B8BAC6", fontSize: 14 }, progressTrack: { height: 5, borderRadius: 4, backgroundColor: c.border, overflow: "hidden" }, progressFill: { height: 5, borderRadius: 4, backgroundColor: c.accent }, feedback: { backgroundColor: c.soft, borderRadius: 18, padding: 14, gap: 5 }, autoPauseCard: { backgroundColor: "#FFF6E5", borderRadius: 14, borderWidth: 1, borderColor: "#F2D39A", padding: 13, gap: 4 }, autoPauseTitle: { color: "#7A4E00", fontSize: 13, fontWeight: "800" }, autoPauseDetail: { color: "#8A6A2F", fontSize: 11, lineHeight: 16 }, feedbackTitle: { color: c.ink, fontSize: 14, fontWeight: "800" }, feedbackBody: { color: c.muted, fontSize: 11 }, effortRow: { flexDirection: "row", gap: 8, marginTop: 6 }, effort: { flex: 1, minHeight: 36, borderRadius: 10, backgroundColor: "#FFF", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: c.border }, effortSelected: { backgroundColor: c.accent, borderColor: c.accent }, effortText: { color: c.ink, fontWeight: "800" }, effortTextSelected: { color: "#FFF" }, adaptive: { color: c.accent, fontSize: 11, fontWeight: "700", marginTop: 3 }, note: { color: c.muted, textAlign: "center", fontSize: 11 }, complete: { flex: 1, justifyContent: "center", gap: 16 }, completeIcon: { width: 68, height: 68, borderRadius: 24, backgroundColor: c.green, alignItems: "center", justifyContent: "center" }, completeIconText: { color: "#21875B", fontSize: 36, fontWeight: "900" }, title: { color: c.ink, fontSize: 32, lineHeight: 38, fontWeight: "900" }, subtitle: { color: c.muted, fontSize: 16, lineHeight: 23 }, summary: { backgroundColor: c.soft, borderRadius: 20, padding: 17, gap: 13, marginVertical: 8 }, summaryTitle: { color: c.ink, fontSize: 15, fontWeight: "800" }, summaryRow: { flexDirection: "row", justifyContent: "space-between" }, summaryLabel: { color: c.muted, fontSize: 13 }, summaryValue: { color: c.ink, fontSize: 13, fontWeight: "800" } });
