import { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { PrimaryButton } from "@/src/mobile/ui";
import { MockBillingAdapter, products, type Product } from "@/src/monetization";
import { useAppState } from "@/src/state/app-state";
import { translate } from "@/src/i18n";
import { AnimatedReveal } from "@/src/mobile/animations";

const c = { ink: "#101114", muted: "#6B7280", border: "#E6E8EC", accent: "#5B5CE2", soft: "#ECECFF", green: "#E8F7F0", white: "#FFF" };
const benefitKeys = ["subscription.benefitInsights", "subscription.benefitHistory", "subscription.benefitCoach", "subscription.benefitReports"] as const;

export default function SubscriptionScreen() {
  const { state } = useAppState();
  const [selected, setSelected] = useState<Product>(products[1]);
  const [status, setStatus] = useState(translate(state.language, "subscription.statusFree"));
  const [busy, setBusy] = useState(false);
  const purchase = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const result = await new MockBillingAdapter().purchase(selected.id);
      setStatus(`${translate(state.language, "subscription.purchaseReady", "Purchase ready for review")} · ${result.transactionId}`);
    } catch {
      setStatus(translate(state.language, "subscription.statusError", "We couldn’t complete that request. Please try again."));
    } finally {
      setBusy(false);
    }
  };
  const restore = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const restored = await new MockBillingAdapter().restorePurchases();
      setStatus(restored.length ? translate(state.language, "subscription.statusRestored") : translate(state.language, "subscription.statusNone"));
    } catch {
      setStatus(translate(state.language, "subscription.statusError", "We couldn’t complete that request. Please try again."));
    } finally {
      setBusy(false);
    }
  };
  return <ScreenContainer className="px-5" containerClassName="bg-background"><ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}><AnimatedReveal delay={40}><Pressable onPress={() => router.back()}><Text style={styles.back}>‹ {translate(state.language, "common.back")}</Text></Pressable><Text style={styles.kicker}>{translate(state.language, "subscription.kicker")}</Text><Text style={styles.title}>{translate(state.language, "subscription.heading")}</Text><Text style={styles.subtitle}>{translate(state.language, "subscription.subtitle")}</Text></AnimatedReveal><AnimatedReveal delay={110}><View style={styles.freeCard}><Text style={styles.cardTitle}>{translate(state.language, "subscription.freeTitle")}</Text><Text style={styles.cardBody}>{translate(state.language, "subscription.freeBody")}</Text></View></AnimatedReveal><AnimatedReveal delay={170}><Text style={styles.section}>{translate(state.language, "subscription.choosePlan")}</Text><View style={styles.plans}>{products.map((product) => <Pressable key={product.id} onPress={() => setSelected(product)} accessibilityRole="radio" accessibilityLabel={translate(state.language, product.billingPeriod === "yearly" ? "subscription.yearly" : "subscription.monthly")} accessibilityState={{ selected: selected.id === product.id }} style={({ pressed }) => [styles.plan, selected.id === product.id && styles.planSelected, pressed && { opacity: 0.82, transform: [{ scale: 0.985 }] }]}><View style={styles.planTop}><Text style={styles.planTitle}>{translate(state.language, product.billingPeriod === "yearly" ? "subscription.yearly" : "subscription.monthly")}</Text>{product.billingPeriod === "yearly" && <Text style={styles.save}>{translate(state.language, "subscription.bestValue")}</Text>}</View><Text style={styles.price}>${product.price.toFixed(2)} <Text style={styles.period}>/ {translate(state.language, product.billingPeriod === "yearly" ? "subscription.year" : "subscription.month")}</Text></Text><Text style={styles.planBody}>{translate(state.language, product.billingPeriod === "yearly" ? "subscription.productYearly" : "subscription.productMonthly", product.description)}</Text></Pressable>)}</View></AnimatedReveal><AnimatedReveal delay={240}><View style={styles.benefits}>{benefitKeys.map((key) => <Text key={key} style={styles.benefit}>✓  {translate(state.language, key)}</Text>)}</View></AnimatedReveal><AnimatedReveal delay={310}><PrimaryButton title={busy ? "Working…" : translate(state.language, "subscription.continue", "Continue with {plan} plan", { plan: translate(state.language, selected.billingPeriod === "yearly" ? "subscription.yearly" : "subscription.monthly") })} onPress={() => void purchase()} disabled={busy} /><Pressable onPress={() => void restore()} disabled={busy} style={({ pressed }) => [styles.restore, busy && { opacity: 0.5 }, pressed && !busy && { opacity: 0.7 }]}><Text style={styles.restoreText}>{translate(state.language, "subscription.restore")}</Text></Pressable><Text style={styles.status}>{status}</Text><Text style={styles.legal}>{translate(state.language, "subscription.legal")}</Text></AnimatedReveal></ScrollView></ScreenContainer>;
}
const styles = StyleSheet.create({ content: { paddingTop: 16, paddingBottom: 48, gap: 16 }, back: { color: c.accent, fontSize: 15, fontWeight: "800", marginBottom: 8 }, kicker: { color: c.muted, fontSize: 11, fontWeight: "800", letterSpacing: 1.4 }, title: { color: c.ink, fontSize: 32, lineHeight: 37, fontWeight: "900", marginTop: -8 }, subtitle: { color: c.muted, fontSize: 14, lineHeight: 20, marginTop: -8 }, freeCard: { backgroundColor: c.green, borderRadius: 20, padding: 16 }, cardTitle: { color: c.ink, fontSize: 15, fontWeight: "800" }, cardBody: { color: c.muted, fontSize: 12, lineHeight: 18, marginTop: 5 }, section: { color: c.ink, fontSize: 18, fontWeight: "800", marginTop: 6 }, plans: { gap: 10 }, plan: { backgroundColor: c.white, borderRadius: 20, borderWidth: 1, borderColor: c.border, padding: 16 }, planSelected: { borderColor: c.accent, borderWidth: 2, backgroundColor: c.soft }, planTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, planTitle: { color: c.ink, fontSize: 15, fontWeight: "800" }, save: { color: c.accent, fontSize: 10, fontWeight: "900", letterSpacing: 1 }, price: { color: c.ink, fontSize: 24, fontWeight: "900", marginTop: 10 }, period: { color: c.muted, fontSize: 12, fontWeight: "600" }, planBody: { color: c.muted, fontSize: 12, marginTop: 5 }, benefits: { backgroundColor: c.white, borderRadius: 18, borderWidth: 1, borderColor: c.border, padding: 16, gap: 10 }, benefit: { color: c.ink, fontSize: 13 }, restore: { alignItems: "center", padding: 8 }, restoreText: { color: c.accent, fontWeight: "800", fontSize: 13 }, status: { color: c.muted, fontSize: 12, textAlign: "center", lineHeight: 18 }, legal: { color: c.muted, fontSize: 10, textAlign: "center", lineHeight: 15, marginTop: 6 } });
