import { useEffect, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { router } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { PrimaryButton, SecondaryButton } from "@/src/mobile/ui";
import { AnimatedProgress, AnimatedReveal } from "@/src/mobile/animations";
import { useAppState } from "@/src/state/app-state";
import type { SupportedLanguage } from "@/src/i18n";
import { translate } from "@/src/i18n";
import { normalizeOnboardingName, onboardingProgress, ONBOARDING_STEP_COUNT, toggleOnboardingGoal } from "@/src/onboarding";

const c = { bg: "#F7F8FA", surface: "#FFF", ink: "#101114", muted: "#6B7280", border: "#E6E8EC", accent: "#5B5CE2", soft: "#ECECFF", green: "#E8F7F0", greenInk: "#21875B" };
const goalOptions = [
  { id: "generalFitness", fallback: "General fitness" },
  { id: "strength", fallback: "Strength" },
  { id: "mobility", fallback: "Mobility" },
  { id: "athleticPerformance", fallback: "Athletic performance" },
  { id: "movementAwareness", fallback: "Movement awareness" },
  { id: "consistencyTracking", fallback: "Consistency tracking" },
] as const;
type PreferredUnit = "metric" | "imperial";

function onboardingGoal(language: SupportedLanguage, id: (typeof goalOptions)[number]["id"], fallback: string) {
  return translate(language, `onboarding.goal.${id}`, fallback);
}

export default function OnboardingScreen() {
  const { state, hydrated, updateState } = useAppState();
  const [step, setStep] = useState(0);
  const [finished, setFinished] = useState(false);
  const [selected, setSelected] = useState<string[]>(state.interests.length ? state.interests : ["movement awareness"]);
  const [name, setName] = useState(state.displayName);
  const [unit, setUnit] = useState<PreferredUnit>(state.preferredUnit);

  useEffect(() => {
    if (!hydrated) return;
    setName(state.displayName);
    setUnit(state.preferredUnit);
    if (state.interests.length) setSelected(state.interests);
  }, [hydrated, state.displayName, state.interests, state.preferredUnit]);

  const language = state.language;
  const finish = () => {
    updateState({ hasCompletedOnboarding: true, displayName: normalizeOnboardingName(name), preferredUnit: unit, interests: selected });
    setFinished(true);
  };
  const next = () => setStep((current) => Math.min(ONBOARDING_STEP_COUNT - 1, current + 1));
  const previous = () => setStep((current) => Math.max(0, current - 1));

  if (!hydrated) {
    return <ScreenContainer className="px-5" containerClassName="bg-background"><View style={styles.loading}><ActivityIndicator color={c.accent} /><Text style={styles.loadingTitle}>{translate(language, "onboarding.loading", "Preparing your private setup…")}</Text><Text style={styles.loadingBody}>{translate(language, "onboarding.loadingBody", "Your choices stay on this device.")}</Text></View></ScreenContainer>;
  }

  if (finished) {
    return <ScreenContainer className="px-5" containerClassName="bg-background"><AnimatedReveal style={styles.success}><View style={styles.successIcon} accessibilityRole="image" accessibilityLabel={translate(language, "onboarding.completeIcon", "Setup complete")}><Text style={styles.successIconText}>✓</Text></View><Text style={styles.kicker}>{translate(language, "onboarding.completeKicker", "READY WHEN YOU ARE")}</Text><Text style={styles.title}>{translate(language, "onboarding.completeTitle", "You’re all set.")}</Text><Text style={styles.body}>{translate(language, "onboarding.completeBody", "Your preferences are saved on this device. FitScan is ready to help you build a clearer, more consistent baseline.")}</Text><View style={styles.note}><Text style={styles.noteText}>{translate(language, "onboarding.completeNote", "You can update these choices any time from Profile.")}</Text></View><PrimaryButton title={translate(language, "onboarding.goHome", "Go to Home")} accessibilityLabel={translate(language, "onboarding.goHome", "Go to Home")} onPress={() => router.replace("/(tabs)" as never)} /></AnimatedReveal></ScreenContainer>;
  }

  const progress = onboardingProgress(step);
  const stepLabel = translate(language, "onboarding.step", "STEP {current} OF {total}", { current: step + 1, total: ONBOARDING_STEP_COUNT });
  const content = step === 0 ? <>
    <Text style={styles.eyebrow}>{translate(language, "onboarding.eyebrow", "START WITH TRUST")}</Text>
    <Text style={styles.title}>{translate(language, "onboarding.privacyTitle", "Your scan is private.")}</Text>
    <Text style={styles.body}>{translate(language, "onboarding.privacyBody", "FitScan uses camera data only when you start a scan. We explain what is processed, what is stored, and how to delete it.")}</Text>
    <View style={styles.trustStrip} accessibilityRole="summary" accessibilityLabel={translate(language, "onboarding.trustSummary", "Private by default. Local-first. Estimates clearly labeled.")}><View style={styles.trustItem}><Text style={styles.trustIcon}>◉</Text><Text style={styles.trustText}>{translate(language, "onboarding.trustPrivate", "Private by default")}</Text></View><View style={styles.trustDivider} /><View style={styles.trustItem}><Text style={styles.trustIcon}>⌂</Text><Text style={styles.trustText}>{translate(language, "onboarding.trustLocal", "Useful offline")}</Text></View></View>
    <Text style={styles.sectionLabel}>{translate(language, "onboarding.whatToExpect", "WHAT TO EXPECT")}</Text>
    <View style={styles.expectCard}><View style={styles.expectRow}><View style={styles.stepDot}><Text style={styles.stepDotText}>1</Text></View><View style={styles.expectCopy}><Text style={styles.cardTitle}>{translate(language, "onboarding.expectScanTitle", "Create a baseline")}</Text><Text style={styles.cardBody}>{translate(language, "onboarding.expectScanBody", "A guided camera scan creates clearly labeled fitness estimates.")}</Text></View></View><View style={styles.expectLine} /><View style={styles.expectRow}><View style={styles.stepDot}><Text style={styles.stepDotText}>2</Text></View><View style={styles.expectCopy}><Text style={styles.cardTitle}>{translate(language, "onboarding.expectPlanTitle", "Get a plan that adapts")}</Text><Text style={styles.cardBody}>{translate(language, "onboarding.expectPlanBody", "Your preferences shape short, practical workouts for today.")}</Text></View></View><View style={styles.expectLine} /><View style={styles.expectRow}><View style={styles.stepDot}><Text style={styles.stepDotText}>3</Text></View><View style={styles.expectCopy}><Text style={styles.cardTitle}>{translate(language, "onboarding.expectProgressTitle", "Notice progress over time")}</Text><Text style={styles.cardBody}>{translate(language, "onboarding.expectProgressBody", "Your history stays on this device so you can compare consistently.")}</Text></View></View></View>
  </> : step === 1 ? <>
    <Text style={styles.eyebrow}>{translate(language, "onboarding.eyebrowGoals", "MAKE IT USEFUL")}</Text>
    <Text style={styles.title}>{translate(language, "onboarding.goalsTitle", "What are you building?")}</Text>
    <Text style={styles.body}>{translate(language, "onboarding.goalsBody", "Choose what you want FitScan to support. You can change this later, and nothing leaves this device.")}</Text>
    <View style={styles.choiceGrid} accessibilityRole="radiogroup" accessibilityLabel={translate(language, "onboarding.goalsGroup", "Fitness goals")}>{goalOptions.map((goal) => { const label = onboardingGoal(language, goal.id, goal.fallback); const active = selected.includes(goal.fallback) || selected.includes(goal.id); return <Pressable key={goal.id} onPress={() => setSelected((current) => toggleOnboardingGoal(current, active ? (current.includes(goal.fallback) ? goal.fallback : goal.id) : goal.fallback))} accessibilityRole="checkbox" accessibilityLabel={label} accessibilityState={{ checked: active }} style={({ pressed }) => [styles.choice, active && styles.choiceActive, pressed && styles.pressed]}><Text style={[styles.choiceText, active && styles.choiceTextActive]}>{label}</Text><View style={[styles.checkCircle, active && styles.checkCircleActive]}>{active && <Text style={styles.check}>✓</Text>}</View></Pressable>; })}</View>
    <View style={styles.note}><Text style={styles.noteText}>{translate(language, "onboarding.goalsNote", "Start with one goal or choose several. FitScan uses this as a gentle signal, not a label.")}</Text></View>
  </> : <>
    <Text style={styles.eyebrow}>{translate(language, "onboarding.eyebrowDetails", "A LIGHT TOUCH")}</Text>
    <Text style={styles.title}>{translate(language, "onboarding.detailsTitle", "Make it yours.")}</Text>
    <Text style={styles.body}>{translate(language, "onboarding.detailsBody", "A few optional details help us frame your progress in a useful way. Skip anything you don’t want to share.")}</Text>
    <Text style={styles.inputLabel}>{translate(language, "onboarding.firstName", "FIRST NAME")}</Text>
    <TextInput value={name} onChangeText={setName} autoCapitalize="words" autoCorrect={false} returnKeyType="done" placeholder={translate(language, "onboarding.namePlaceholder", "Your first name")} placeholderTextColor={c.muted} accessibilityLabel={translate(language, "onboarding.nameAccessibility", "First name, optional")} style={styles.input} />
    <Text style={styles.inputLabel}>{translate(language, "onboarding.preferredUnit", "PREFERRED UNIT")}</Text>
    <View style={styles.unitRow} accessibilityRole="radiogroup" accessibilityLabel={translate(language, "onboarding.unitGroup", "Preferred measurement unit")}>{(["metric", "imperial"] as PreferredUnit[]).map((option) => { const active = unit === option; return <Pressable key={option} onPress={() => { setUnit(option); updateState({ preferredUnit: option }); }} accessibilityRole="radio" accessibilityLabel={translate(language, option === "metric" ? "onboarding.metric" : "onboarding.imperial", option === "metric" ? "Metric, centimeters" : "Imperial, inches")} accessibilityState={{ selected: active }} style={({ pressed }) => [styles.unit, active && styles.unitActive, pressed && styles.pressed]}><Text style={[styles.unitText, active && styles.unitTextActive]}>{translate(language, option === "metric" ? "onboarding.metric" : "onboarding.imperial", option === "metric" ? "Metric · cm" : "Imperial · in")}</Text>{active && <Text style={styles.unitCheck}>✓</Text>}</Pressable>; })}</View>
    <View style={styles.note}><Text style={styles.noteText}>{translate(language, "onboarding.detailsNote", "This setup is optional. You can skip it and explore the labeled demo at any time.")}</Text></View>
  </>;

  const primaryTitle = step === 0 ? translate(language, "common.continue", "Continue") : step === 1 ? translate(language, "onboarding.saveGoals", "Save goals") : translate(language, "onboarding.finish", "Finish setup");
  return <ScreenContainer className="px-5" containerClassName="bg-background"><ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}><View style={styles.progressHeader}><Text style={styles.step}>{stepLabel}</Text><Text style={styles.progressPercent}>{Math.round(progress * 100)}%</Text></View><View style={styles.progressTrack} accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: ONBOARDING_STEP_COUNT, now: step + 1, text: stepLabel }}><AnimatedProgress progress={progress} style={styles.progressFill} /></View><AnimatedReveal key={`onboarding-step-${step}`} delay={60} style={styles.stepContent}>{content}</AnimatedReveal><View style={styles.actions}><PrimaryButton title={primaryTitle} accessibilityLabel={primaryTitle} onPress={step < ONBOARDING_STEP_COUNT - 1 ? next : finish} /><View style={styles.secondaryActions}>{step > 0 && <SecondaryButton title={translate(language, "common.back", "Back")} accessibilityLabel={translate(language, "onboarding.backAccessibility", "Go back to the previous setup step")} onPress={previous} />}<Pressable onPress={finish} accessibilityRole="button" accessibilityLabel={translate(language, "onboarding.skipAccessibility", "Skip setup and go to Home")} style={({ pressed }) => [styles.skipButton, pressed && styles.pressed]}><Text style={styles.skip}>{translate(language, "onboarding.skip", "Skip setup")}</Text></Pressable></View></View></ScrollView></ScreenContainer>;
}

const styles = StyleSheet.create({ content: { paddingTop: 18, paddingBottom: 44, gap: 16 }, loading: { flex: 1, justifyContent: "center", alignItems: "center", gap: 10, paddingHorizontal: 28 }, loadingTitle: { color: c.ink, fontSize: 17, fontWeight: "800", textAlign: "center" }, loadingBody: { color: c.muted, fontSize: 13, lineHeight: 19, textAlign: "center" }, progressHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, progressTrack: { height: 6, backgroundColor: c.border, borderRadius: 5, overflow: "hidden" }, progressFill: { height: 6, backgroundColor: c.accent, borderRadius: 5 }, step: { color: c.accent, fontSize: 11, fontWeight: "900", letterSpacing: 1.3 }, progressPercent: { color: c.muted, fontSize: 12, fontWeight: "800" }, stepContent: { gap: 16 }, eyebrow: { color: c.muted, fontSize: 11, fontWeight: "900", letterSpacing: 1.5, marginTop: 10 }, kicker: { color: c.accent, fontSize: 11, fontWeight: "900", letterSpacing: 1.5 }, title: { color: c.ink, fontSize: 32, lineHeight: 37, fontWeight: "900", marginTop: -7 }, body: { color: c.muted, fontSize: 16, lineHeight: 23 }, trustStrip: { backgroundColor: c.soft, borderRadius: 18, padding: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-around" }, trustItem: { flex: 1, alignItems: "center", gap: 6 }, trustIcon: { color: c.accent, fontSize: 18, fontWeight: "900" }, trustText: { color: c.ink, fontSize: 12, fontWeight: "800", textAlign: "center" }, trustDivider: { width: 1, height: 30, backgroundColor: "#D5D5F4" }, sectionLabel: { color: c.muted, fontSize: 11, fontWeight: "900", letterSpacing: 1.3, marginTop: 3 }, expectCard: { backgroundColor: c.surface, borderRadius: 20, borderWidth: 1, borderColor: c.border, padding: 16 }, expectRow: { flexDirection: "row", alignItems: "flex-start", gap: 12 }, stepDot: { width: 30, height: 30, borderRadius: 11, backgroundColor: c.soft, alignItems: "center", justifyContent: "center" }, stepDotText: { color: c.accent, fontSize: 13, fontWeight: "900" }, expectCopy: { flex: 1, gap: 3 }, cardTitle: { color: c.ink, fontSize: 15, fontWeight: "800" }, cardBody: { color: c.muted, fontSize: 13, lineHeight: 19 }, expectLine: { width: 1, height: 18, backgroundColor: c.border, marginLeft: 14, marginVertical: 3 }, choiceGrid: { gap: 10 }, choice: { minHeight: 58, backgroundColor: c.surface, borderRadius: 17, borderWidth: 1, borderColor: c.border, paddingHorizontal: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, choiceActive: { backgroundColor: c.soft, borderColor: c.accent }, choiceText: { color: c.ink, fontSize: 15, fontWeight: "700", flex: 1 }, choiceTextActive: { color: c.accent }, checkCircle: { width: 24, height: 24, borderRadius: 12, borderWidth: 1.5, borderColor: c.border, alignItems: "center", justifyContent: "center" }, checkCircleActive: { backgroundColor: c.accent, borderColor: c.accent }, check: { color: "#FFF", fontSize: 14, fontWeight: "900" }, inputLabel: { color: c.muted, fontSize: 11, fontWeight: "900", letterSpacing: 1.2, marginTop: 4 }, input: { height: 54, borderRadius: 16, borderWidth: 1, borderColor: c.border, backgroundColor: c.surface, paddingHorizontal: 16, fontSize: 16, color: c.ink }, unitRow: { flexDirection: "row", gap: 10 }, unit: { flex: 1, minHeight: 56, borderRadius: 16, backgroundColor: c.surface, borderWidth: 1, borderColor: c.border, alignItems: "center", justifyContent: "center", paddingHorizontal: 8, gap: 5 }, unitActive: { backgroundColor: c.soft, borderColor: c.accent }, unitText: { color: c.ink, fontWeight: "800", fontSize: 13 }, unitTextActive: { color: c.accent }, unitCheck: { color: c.accent, fontSize: 14, fontWeight: "900" }, note: { backgroundColor: c.green, padding: 15, borderRadius: 16 }, noteText: { color: c.ink, fontSize: 13, lineHeight: 19 }, actions: { gap: 8 }, secondaryActions: { minHeight: 50, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 12 }, skipButton: { minHeight: 48, paddingHorizontal: 12, alignItems: "center", justifyContent: "center" }, skip: { textAlign: "center", color: c.muted, fontWeight: "800", fontSize: 13 }, pressed: { opacity: 0.72, transform: [{ scale: 0.985 }] }, success: { flex: 1, justifyContent: "center", gap: 16 }, successIcon: { width: 68, height: 68, borderRadius: 24, backgroundColor: c.green, alignItems: "center", justifyContent: "center" }, successIconText: { color: c.greenInk, fontSize: 36, fontWeight: "900" },
});
