/** @type {const} */
const themeColors = {
  primary: { light: '#5B5CE2', dark: '#A5A6FF' },
  background: { light: '#F7F8FA', dark: '#0F1115' },
  surface: { light: '#FFFFFF', dark: '#171A20' },
  foreground: { light: '#111318', dark: '#F7F8FA' },
  muted: { light: '#6C727C', dark: '#A9AFB8' },
  border: { light: '#E5E7EB', dark: '#2A2F37' },
  success: { light: '#2C9B69', dark: '#63C794' },
  warning: { light: '#C98A16', dark: '#E4B34D' },
  error: { light: '#C84A4A', dark: '#F08080' },
};
module.exports = { themeColors };
