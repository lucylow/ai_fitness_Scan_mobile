import { Pressable, StyleSheet, Switch, Text, View } from "react-native";
import type { CoachTone, PersistenceStatus, PreferredDifficulty, SessionDuration } from "@/src/state/app-state";
import { translate, type SupportedLanguage } from "@/src/i18n";
import { localizedProfileOptionAccessibilityLabel } from "@/src/accessibility-presentation";

const palette = { bg: "#F7F8FA", surface: "#FFF", ink: "#101114", muted: "#6B7280", border: "#E6E8EC", accent: "#5B5CE2", soft: "#ECECFF" };

const profileOptionAccessibility = (language: SupportedLanguage, label: string, selected: boolean) => ({ accessibilityRole: "button" as const, accessibilityLabel: localizedProfileOptionAccessibilityLabel(language, label, selected), accessibilityState: { selected } });
const profileSwitchAccessibility = (language: SupportedLanguage, label: string, checked: boolean) => ({ accessibilityRole: "switch" as const, accessibilityLabel: label, accessibilityState: { checked } });

export function ProfilePreferenceOption({ label, selected, onPress, language }: { label: string; selected: boolean; onPress: () => void; language: SupportedLanguage }) {
  return <Pressable {...profileOptionAccessibility(language, label, selected)} onPress={onPress} style={[styles.option, selected && styles.optionSelected]}><Text style={[styles.optionText, selected && styles.optionTextSelected]}>{label}</Text></Pressable>;
}

export function ProfilePreferenceSwitch({ label, detail, value, onValueChange, language }: { label: string; detail: string; value: boolean; onValueChange: (value: boolean) => void; language: SupportedLanguage }) {
  return <View style={styles.row}><View style={styles.rowCopy}><Text style={styles.rowTitle}>{label}</Text><Text style={styles.rowSub}>{detail}</Text></View><Switch value={value} onValueChange={onValueChange} {...profileSwitchAccessibility(language, label, value)} trackColor={{ false: palette.border, true: palette.accent }} thumbColor="#FFF" /></View>;
}

export function ProfileNavigationRow({ title, detail, accessibilityLabel, onPress }: { title: string; detail: string; accessibilityLabel: string; onPress: () => void }) {
  return <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={accessibilityLabel} style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}><View><Text style={styles.rowTitle}>{title}</Text><Text style={styles.rowSub}>{detail}</Text></View><Text style={styles.chevron}>›</Text></Pressable>;
}

export function ProfileHeroCard({ language, name, subtitle }: { language: SupportedLanguage; name: string; subtitle: string }) {
  return <View style={styles.profileCard}><View style={styles.avatar}><Text style={styles.avatarText}>{name.trim().charAt(0).toUpperCase() || "A"}</Text></View><View style={styles.profileCopy}><Text style={styles.name}>{name}</Text><Text style={styles.sub}>{subtitle}</Text></View><Text style={styles.edit}>{translate(language, "profile.edit")}</Text></View>;
}

export function ProfileStorageCard({ language, status }: { language: SupportedLanguage; status: PersistenceStatus }) {
  const statusKey = status === "migrated" ? "profile.localStorageMigrated" : status === "recovered" ? "profile.localStorageRecovered" : status === "hydrating" ? "profile.localStorageHydrating" : "profile.localStorageReady";
  return <View style={styles.storageCard} accessibilityRole="summary"><Text style={styles.storageTitle}>{translate(language, "profile.localStorageTitle", "Private local storage")}</Text><Text style={styles.storageBody}>{translate(language, statusKey, "Your preferences and history stay on this device.")}</Text></View>;
}

export function ProfileInsightCard({ language, tone, duration, difficulty, recommendation, confidence }: { language: SupportedLanguage; tone: CoachTone; duration: SessionDuration; difficulty: PreferredDifficulty; recommendation: string; confidence: number }) {
  return <View style={styles.insightCard}><Text style={styles.insightEyebrow}>{translate(language, "profile.personalizedLocally")}</Text><Text style={styles.insightTitle}>{translate(language, `profile.tone.${tone}`)} {translate(language, "profile.coaching", "coaching")} · {translate(language, "profile.minutes", "{count} min", { count: duration })} · {translate(language, `profile.difficulty.${difficulty}`)}</Text><Text style={styles.insightBody}>{recommendation}</Text><Text style={styles.insightConfidence}>{translate(language, "profile.confidence", "Personalization confidence: {value}%", { value: Math.round(confidence * 100) })}</Text></View>;
}

export function ProfileCommitmentsCard({ language }: { language: SupportedLanguage }) {
  return <View style={styles.goalCard} accessibilityRole="summary"><View style={styles.goalIcon}><Text style={styles.goalIconText}>✦</Text></View><View style={styles.goalCopy}><Text style={styles.rowTitle}>{translate(language, "profile.commitmentTitle")}</Text><Text style={styles.rowSub}>{translate(language, "profile.commitmentBody")}</Text></View></View>;
}

const styles = StyleSheet.create({
  storageCard: { backgroundColor: "#E8F7F0", borderRadius: 16, padding: 14, borderWidth: 1, borderColor: "#CFEBDD" }, storageTitle: { color: palette.ink, fontSize: 13, fontWeight: "800" }, storageBody: { color: palette.muted, fontSize: 11, lineHeight: 16, marginTop: 3 }, profileCard: { backgroundColor: palette.ink, borderRadius: 24, padding: 18, flexDirection: "row", alignItems: "center" }, avatar: { width: 52, height: 52, borderRadius: 26, backgroundColor: palette.accent, alignItems: "center", justifyContent: "center" }, avatarText: { color: "#FFF", fontSize: 20, fontWeight: "800" }, profileCopy: { flex: 1, marginLeft: 14 }, name: { color: "#FFF", fontSize: 18, fontWeight: "800" }, sub: { color: "#B8BAC6", fontSize: 12, marginTop: 5 }, edit: { color: "#C2C3FF", fontSize: 13, fontWeight: "800" }, row: { minHeight: 72, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, rowPressed: { opacity: 0.72 }, rowCopy: { flex: 1, paddingRight: 12 }, rowTitle: { color: palette.ink, fontSize: 15, fontWeight: "800" }, rowSub: { color: palette.muted, fontSize: 12, lineHeight: 18, marginTop: 4 }, chevron: { color: palette.muted, fontSize: 26 }, option: { borderWidth: 1, borderColor: palette.border, borderRadius: 10, paddingHorizontal: 11, paddingVertical: 8, backgroundColor: palette.bg }, optionSelected: { backgroundColor: palette.accent, borderColor: palette.accent }, optionText: { color: palette.ink, fontSize: 12, fontWeight: "700" }, optionTextSelected: { color: "#FFF" }, insightCard: { backgroundColor: palette.soft, borderRadius: 20, padding: 16 }, insightEyebrow: { color: palette.accent, fontSize: 10, fontWeight: "800", letterSpacing: 1.2 }, insightTitle: { color: palette.ink, fontSize: 15, fontWeight: "800", marginTop: 8 }, insightBody: { color: palette.muted, fontSize: 12, lineHeight: 18, marginTop: 5 }, insightConfidence: { color: palette.accent, fontSize: 11, fontWeight: "800", marginTop: 9 }, goalCard: { backgroundColor: palette.soft, borderRadius: 20, padding: 16, flexDirection: "row", alignItems: "center" }, goalCopy: { flex: 1 }, goalIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#FFF", alignItems: "center", justifyContent: "center", marginRight: 12 }, goalIconText: { color: palette.accent, fontSize: 21 }
});

