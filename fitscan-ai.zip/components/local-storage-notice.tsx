import { Pressable, StyleSheet, Text, View } from "react-native";
import { useState } from "react";
import { translate, type SupportedLanguage } from "@/src/i18n";
import type { PersistenceStatus } from "@/src/state/app-state";
import { migrationSummaryKeys, privacyDetailKeys, shouldShowLocalStorageNotice } from "./local-storage-notice-logic";

export { shouldShowLocalStorageNotice } from "./local-storage-notice-logic";

interface LocalStorageNoticeProps {
  language: SupportedLanguage;
  status: PersistenceStatus;
  noticeVersion: number;
  dismissedVersion?: number;
  onDismiss: () => void;
}

export function LocalStorageNotice({ language, status, noticeVersion, dismissedVersion, onDismiss }: LocalStorageNoticeProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);

  if (!shouldShowLocalStorageNotice(status, noticeVersion, dismissedVersion)) return null;

  const messageKey = status === "migrated" ? "profile.localNoticeMigrated" : "profile.localNoticeRecovered";
  return (
    <View style={styles.card} accessibilityRole="alert">
      <View style={styles.copy}>
        <Text style={styles.title}>{translate(language, "profile.localNoticeTitle", "Local data updated")}</Text>
        <Text style={styles.body}>{translate(language, messageKey, "Your private data remains on this device.")}</Text>
        <Pressable onPress={() => setShowDetails((visible) => !visible)} accessibilityRole="button" accessibilityState={{ expanded: showDetails }} accessibilityLabel={translate(language, "profile.localNoticeReview", "Review what changed")} style={styles.review}>
          <Text style={styles.reviewText}>{translate(language, showDetails ? "profile.localNoticeHideDetails" : "profile.localNoticeReview", showDetails ? "Hide details" : "Review what changed")}</Text>
        </Pressable>
        {showDetails && <View style={styles.details} accessibilityRole="text"><Text style={styles.detailsTitle}>{translate(language, "profile.localNoticeDetailsTitle", "What changed")}</Text>{migrationSummaryKeys(status).map((key) => <Text key={key} style={styles.detailItem}>• {translate(language, key, "Your local data remains private.")}</Text>)}</View>}
        <Pressable onPress={() => setShowPrivacy((visible) => !visible)} accessibilityRole="button" accessibilityState={{ expanded: showPrivacy }} accessibilityLabel={translate(language, "profile.localPrivacyReview", "Learn about local privacy")} style={styles.review}>
          <Text style={styles.reviewText}>{translate(language, showPrivacy ? "profile.localPrivacyHide" : "profile.localPrivacyReview", showPrivacy ? "Hide local privacy details" : "Learn about local privacy")}</Text>
        </Pressable>
        {showPrivacy && <View style={styles.details} accessibilityRole="text"><Text style={styles.detailsTitle}>{translate(language, "profile.localPrivacyTitle", "Your privacy boundary")}</Text>{privacyDetailKeys().map((key) => <Text key={key} style={styles.detailItem}>• {translate(language, key, "Your data stays under your control.")}</Text>)}</View>}
      </View>
      <Pressable onPress={onDismiss} accessibilityRole="button" accessibilityLabel={translate(language, "profile.dismissNotice", "Dismiss notice")} style={styles.dismiss}><Text style={styles.dismissText}>×</Text></Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: "#FFF7E6", borderRadius: 16, padding: 14, borderWidth: 1, borderColor: "#F2D39A", flexDirection: "row", alignItems: "center" },
  copy: { flex: 1 },
  title: { color: "#101114", fontSize: 13, fontWeight: "800" },
  body: { color: "#6B7280", fontSize: 11, lineHeight: 16, marginTop: 3 },
  review: { alignSelf: "flex-start", marginTop: 8 },
  reviewText: { color: "#5B5CE2", fontSize: 11, fontWeight: "800" },
  details: { marginTop: 8, gap: 4 },
  detailsTitle: { color: "#101114", fontSize: 11, fontWeight: "800" },
  detailItem: { color: "#6B7280", fontSize: 11, lineHeight: 16 },
  dismiss: { width: 28, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  dismissText: { color: "#6B7280", fontSize: 20, lineHeight: 22 },
});
