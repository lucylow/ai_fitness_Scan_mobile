import type { PersistenceStatus } from "@/src/state/app-state";

export function shouldShowLocalStorageNotice(status: PersistenceStatus, currentVersion = 0, dismissedVersion?: number) {
  return (status === "migrated" || status === "recovered") && dismissedVersion !== currentVersion;
}

export function privacyDetailKeys() {
  return ["profile.localPrivacyDetailStorage", "profile.localPrivacyDetailProcessing", "profile.localPrivacyDetailControl"];
}

export function migrationSummaryKeys(status: PersistenceStatus) {
  return status === "migrated"
    ? ["profile.localNoticeDetailsPreferences", "profile.localNoticeDetailsHistory", "profile.localNoticeDetailsPrivacy"]
    : ["profile.localNoticeDetailsRecovery", "profile.localNoticeDetailsPrivacy"];
}
