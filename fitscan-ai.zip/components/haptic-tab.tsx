import { useRef } from "react";
import { Animated } from "react-native";
import { BottomTabBarButtonProps } from "@react-navigation/bottom-tabs";
import { PlatformPressable } from "@react-navigation/elements";
import * as Haptics from "expo-haptics";
import { animationDuration } from "@/src/mobile/animation-core";
import { useReducedMotionPreference } from "@/src/mobile/animations";

export function HapticTab({ onPressIn, onPressOut, ...props }: BottomTabBarButtonProps) {
  const reduceMotion = useReducedMotionPreference();
  const scale = useRef(new Animated.Value(1)).current;
  const animateScale = (toValue: number) => {
    if (reduceMotion) {
      scale.setValue(1);
      return;
    }
    Animated.timing(scale, { toValue, duration: animationDuration(reduceMotion, 90), useNativeDriver: true }).start();
  };

  return (
    <Animated.View style={{ flex: 1, transform: [{ scale }] }}><PlatformPressable
        {...props}
      onPressIn={(ev) => {
        animateScale(0.96);
        if (process.env.EXPO_OS === "ios") {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        }
        onPressIn?.(ev);
      }}
      onPressOut={(ev) => {
        animateScale(1);
        onPressOut?.(ev);
      }}
      /></Animated.View>
  );
}
