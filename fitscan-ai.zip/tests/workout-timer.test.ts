import { describe, expect, it } from "vitest";
import { advanceWorkoutTimer, shouldCommitWorkoutCompletion, shouldPauseWorkoutForAppState, shouldPersistWorkoutRecovery } from "../src/workout-timer";

describe("workout timer transitions", () => {
  it("pauses only when the app is no longer active", () => {
    expect(shouldPauseWorkoutForAppState("active")).toBe(false);
    expect(shouldPauseWorkoutForAppState("inactive")).toBe(true);
    expect(shouldPauseWorkoutForAppState("background")).toBe(true);
  });
  it("allows recovery only for mounted non-terminal sessions", () => {
    expect(shouldPersistWorkoutRecovery(true, "work")).toBe(true);
    expect(shouldPersistWorkoutRecovery(true, "complete")).toBe(false);
    expect(shouldPersistWorkoutRecovery(false, "work")).toBe(false);
  });

  it("commits completion only once while mounted", () => {
    expect(shouldCommitWorkoutCompletion(true, "complete", false)).toBe(true);
    expect(shouldCommitWorkoutCompletion(true, "complete", true)).toBe(false);
    expect(shouldCommitWorkoutCompletion(false, "complete", false)).toBe(false);
    expect(shouldCommitWorkoutCompletion(true, "work", false)).toBe(false);
  });
  it("counts down active work without changing phase", () => {
    expect(advanceWorkoutTimer({ phase: "work", seconds: 8, exerciseIndex: 0, totalExercises: 2, restSeconds: 12 })).toEqual({ phase: "work", seconds: 7, exerciseIndex: 0, advancedExercise: false, completed: false });
  });

  it("moves from work into the prescribed rest period", () => {
    expect(advanceWorkoutTimer({ phase: "work", seconds: 1, exerciseIndex: 0, totalExercises: 2, restSeconds: 12 })).toEqual({ phase: "rest", seconds: 12, exerciseIndex: 0, advancedExercise: false, completed: false });
  });

  it("advances to the next exercise after rest", () => {
    expect(advanceWorkoutTimer({ phase: "rest", seconds: 1, exerciseIndex: 0, totalExercises: 2, restSeconds: 12 })).toEqual({ phase: "work", seconds: 30, exerciseIndex: 1, advancedExercise: true, completed: false });
  });

  it("completes after the final rest period", () => {
    expect(advanceWorkoutTimer({ phase: "rest", seconds: 1, exerciseIndex: 1, totalExercises: 2, restSeconds: 12 })).toEqual({ phase: "complete", seconds: 0, exerciseIndex: 1, advancedExercise: false, completed: true });
  });

  it("normalizes unsafe timer inputs and keeps completion terminal", () => {
    expect(advanceWorkoutTimer({ phase: "complete", seconds: 20, exerciseIndex: 99, totalExercises: 0, restSeconds: 0 })).toEqual({ phase: "complete", seconds: 0, exerciseIndex: 0, advancedExercise: false, completed: true });
  });
});
