import { describe, expect, it } from "vitest";
import { migrationSummaryKeys, shouldShowLocalStorageNotice } from "../components/local-storage-notice-logic";

describe("LocalStorageNotice", () => {
  it("returns only generic, privacy-safe change summaries", () => {
    expect(migrationSummaryKeys("migrated")).toEqual(["profile.localNoticeDetailsPreferences", "profile.localNoticeDetailsHistory", "profile.localNoticeDetailsPrivacy"]);
    expect(migrationSummaryKeys("recovered")).toEqual(["profile.localNoticeDetailsRecovery", "profile.localNoticeDetailsPrivacy"]);
  });
  it("shows only when local data was migrated or recovered", () => {
    expect(shouldShowLocalStorageNotice("migrated")).toBe(true);
    expect(shouldShowLocalStorageNotice("recovered")).toBe(true);
    expect(shouldShowLocalStorageNotice("ready")).toBe(false);
    expect(shouldShowLocalStorageNotice("hydrating")).toBe(false);
  });
});
