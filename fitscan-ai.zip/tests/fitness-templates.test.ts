import { describe, expect, it } from "vitest";
import { filterFitnessTemplates, hasVisibleFitnessTemplates, type FitnessTemplateDefinition } from "../src/fitness-templates";

const templates: FitnessTemplateDefinition[] = [
  { id: "bodyweight", requiredEquipment: ["none"] },
  { id: "mobility", requiredEquipment: ["mat"] },
  { id: "strength", requiredEquipment: ["dumbbells"] },
];

describe("Fitness template eligibility", () => {
  it("keeps bodyweight templates available without equipment", () => {
    expect(filterFitnessTemplates(templates, ["none"]).map((template) => template.id)).toEqual(["bodyweight"]);
  });

  it("shows templates when their required equipment is available", () => {
    expect(filterFitnessTemplates(templates, ["none", "mat", "dumbbells"]).map((template) => template.id)).toEqual([
      "bodyweight",
      "mobility",
      "strength",
    ]);
  });

  it("returns an empty result when every template requires unavailable equipment", () => {
    const equipmentOnlyTemplates: FitnessTemplateDefinition[] = [
      { id: "mat-only", requiredEquipment: ["mat"] },
      { id: "weights-only", requiredEquipment: ["dumbbells"] },
    ];
    expect(filterFitnessTemplates(equipmentOnlyTemplates, ["none"])).toEqual([]);
    expect(hasVisibleFitnessTemplates(equipmentOnlyTemplates, ["none"])).toBe(false);
  });

  it("does not mutate the template catalog", () => {
    const original = [...templates];
    filterFitnessTemplates(templates, ["mat"]);
    expect(templates).toEqual(original);
  });
});
