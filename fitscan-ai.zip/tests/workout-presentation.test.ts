import { describe, expect, it } from "vitest";
import { languages } from "../src/i18n";
import { localizedWorkoutLaunchTitle, localizedWorkoutPlanRationale, localizedWorkoutPlanTitle } from "../src/workout-presentation";
import type { WorkoutPlanSummary } from "../src/workouts/v6";

const selectedPlan: WorkoutPlanSummary = { title: "Balanced 30-minute session", type: "mixed", difficulty: "beginner", durationMinutes: 30, exerciseIds: ["squat"], rationale: "Selected around your available time, equipment, and preferred difficulty." };
const emptyPlan: WorkoutPlanSummary = { ...selectedPlan, exerciseIds: [], rationale: "No matching exercises were found; try adding equipment or choosing a shorter session." };

describe("localized workout presentation", () => {
  it("localizes a supported launch template and plan title", () => {
    expect(localizedWorkoutLaunchTitle("en", "Full body")).toBe("Full body session");
    expect(localizedWorkoutLaunchTitle("en")).toBe("Quick reset session");
    expect(localizedWorkoutPlanTitle("en", selectedPlan)).toBe("Balanced 30-minute session");
  });

  it("selects the appropriate rationale for matched and empty plans", () => {
    expect(localizedWorkoutPlanRationale("en", selectedPlan)).toContain("available time");
    expect(localizedWorkoutPlanRationale("en", emptyPlan)).toContain("No matching exercises");
  });

  it("resolves plan copy without leaking interpolation tokens", () => {
    for (const language of languages) {
      expect(localizedWorkoutLaunchTitle(language.code, "Mobility")).not.toContain("{template}");
      expect(localizedWorkoutPlanTitle(language.code, selectedPlan)).not.toContain("{minutes}");
      expect(localizedWorkoutPlanRationale(language.code, selectedPlan)).not.toContain("{minutes}");
    }
  });
});
