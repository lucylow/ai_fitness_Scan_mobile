import { describe, expect, it } from "vitest";
import { animationDuration, normalizeAnimationProgress } from "../src/mobile/animation-core";

describe("mobile animations", () => {
  it("disables timing when reduced motion is requested", () => {
    expect(animationDuration(true, 260)).toBe(0);
    expect(animationDuration(false, 260)).toBe(260);
  });

  it("keeps durations non-negative", () => {
    expect(animationDuration(false, -20)).toBe(0);
  });

  it("clamps progress to the animatable range", () => {
    expect(normalizeAnimationProgress(-0.2)).toBe(0);
    expect(normalizeAnimationProgress(0.65)).toBe(0.65);
    expect(normalizeAnimationProgress(1.4)).toBe(1);
  });
});
