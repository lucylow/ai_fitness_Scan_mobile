import { describe, expect, it } from "vitest";
import { languages } from "../src/i18n";
import { localizedAdaptiveCue, localizedAdaptiveCueAccessibilityLabel } from "../src/adaptive-cue-presentation";
import { adaptNextInstruction } from "../src/workouts/v6";

describe("localized adaptive coaching cues", () => {
  it("preserves the existing coaching decision in English", () => {
    const scenarios = [[0, 3, 9], [3, 3, 4], [1, 3, 6]] as const;
    for (const [completedSets, targetSets, effort] of scenarios) {
      expect(localizedAdaptiveCue("en", completedSets, targetSets, effort)).toBe(adaptNextInstruction(completedSets, targetSets, effort));
    }
  });

  it("localizes cue content and the accessibility label", () => {
    expect(localizedAdaptiveCue("fr", 0, 3, 9)).toContain("Réduisez");
    expect(localizedAdaptiveCue("fr", 3, 3, 4)).toContain("progresser");
    expect(localizedAdaptiveCueAccessibilityLabel("ar", 1, 3, 6)).toContain("إرشاد");
  });

  it("resolves cues for every supported language without interpolation placeholders", () => {
    for (const language of languages) {
      const cue = localizedAdaptiveCue(language.code, 1, 3, 6);
      const label = localizedAdaptiveCueAccessibilityLabel(language.code, 1, 3, 6);
      expect(cue).not.toContain("{");
      expect(label).not.toContain("{cue}");
    }
  });
});
