import { describe, expect, it } from "vitest";
import { detectDeviceLanguage, normalizeLanguage, shouldRefreshDeviceLanguage } from "../src/i18n-device";

describe("device language fallback", () => {
  it("normalizes regional and underscored locale tags", () => {
    expect(normalizeLanguage("fr-FR")).toBe("fr");
    expect(normalizeLanguage("pt_BR")).toBe("pt");
    expect(normalizeLanguage(["ja-JP", "en-US"])).toBe("ja");
  });

  it("refreshes only when no explicit preference exists", () => {
    expect(shouldRefreshDeviceLanguage(false, "en", "fr")).toBe(true);
    expect(shouldRefreshDeviceLanguage(true, "en", "fr")).toBe(false);
    expect(shouldRefreshDeviceLanguage(false, "en", "en")).toBe(false);
  });

  it("falls back safely for unsupported or malformed values", () => {
    expect(normalizeLanguage("xx-XX")).toBe("en");
    expect(normalizeLanguage(undefined)).toBe("en");
    expect(detectDeviceLanguage(() => "ar-SA")).toBe("ar");
    expect(detectDeviceLanguage(() => { throw new Error("locale unavailable"); })).toBe("en");
  });
});
