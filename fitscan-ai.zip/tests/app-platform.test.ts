import { describe, expect, it, vi } from "vitest";
import { appEvents, HomeCache, buildPrivacyExport, calculateUserReadiness, createAppOrchestrator } from "../src/app-platform";

describe("application platform", () => {
  it("publishes cohesive app events", () => { const events: string[] = []; const unsubscribe = appEvents.subscribe((event) => events.push(event.type)); const orchestrator = createAppOrchestrator(); orchestrator.startScan("scan_1"); expect(events).toEqual(["SCAN_STARTED"]); unsubscribe(); });
  it("calculates readiness from profile inputs", () => { expect(calculateUserReadiness({ goals: ["strength"], experience: "beginner", preferredDuration: 20 }).ready).toBe(true); expect(calculateUserReadiness({ goals: [], experience: "beginner", preferredDuration: 0 }).ready).toBe(false); });
  it("caches home data and exports privacy records", () => { const cache = new HomeCache(); const data = { greeting: "Welcome", weeklySummary: { scans: 1, workouts: 2 }, activeGoals: [], recentActivity: [] }; cache.set(data); expect(cache.get()).toEqual(data); expect(buildPrivacyExport({ scans: [{ id: "s1" }], workouts: [], profile: { displayName: "Alex" } }).includes).toEqual(["scans", "workouts", "profile"]); vi.useFakeTimers(); vi.advanceTimersByTime(1); expect(cache.get(0)).toBeNull(); vi.useRealTimers(); });
});
