import { describe, expect, it } from "vitest";
import { generateQuickWorkout, validateWorkout } from "../src/fitness/services/workouts";
import { MockAIProvider } from "../src/ai/providers";

describe("fitness services", () => {
  it("generates a valid no-equipment quick workout", () => {
    const workout = generateQuickWorkout({ experience: "beginner", equipment: ["none"], interests: ["strength"], sessionDurationMinutes: 10 }, 10);
    expect(workout.exercises.length).toBeGreaterThan(0);
    expect(validateWorkout(workout)).toBe(true);
    expect(workout.exercises.every((exercise) => exercise.sets > 0)).toBe(true);
  });

  it("returns structured, safety-aware mock scan output", async () => {
    const provider = new MockAIProvider();
    const response = await provider.analyzeScan({ context: { sessionId: "test", timestamp: 1, provider: "mock", mode: "local" }, input: { frames: [] } });
    expect(response.output.modelVersion).toBe("mock-1.0");
    expect(response.output.warnings[0]).toContain("not clinical");
    expect(response.confidence?.level).toBe("high");
  });
});
