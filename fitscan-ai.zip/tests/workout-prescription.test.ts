import { describe, expect, it } from "vitest";
import { languages } from "../src/i18n";
import { localizedPrescriptionSummary, prescriptionForExercise, prescriptionSummary } from "../src/workout-prescription";

describe("workout prescriptions", () => {
  it("formats rep-based catalog prescriptions", () => {
    const prescription = prescriptionForExercise({ id: "squat", name: "Squat", category: "strength", movementPattern: "squat", equipment: ["none"], difficulty: "beginner", defaultReps: 10, defaultSets: 3, defaultRestSeconds: 20, instructions: [] });
    expect(prescription).toEqual({ sets: 3, targetLabel: "10 reps", restSeconds: 20 });
    expect(prescriptionSummary(prescription)).toBe("3 sets × 10 reps · 20s rest");
    expect(localizedPrescriptionSummary("en", prescription)).toBe("3 sets × 10 reps · 20s rest");
    expect(localizedPrescriptionSummary("fr", prescription)).toBe("3 séries × 10 répétitions · 20 s de repos");
  });

  it("formats timed prescriptions and clamps unsafe rest values", () => {
    const prescription = prescriptionForExercise({ id: "plank", name: "Plank", category: "mobility", movementPattern: "core", equipment: ["mat"], difficulty: "intermediate", defaultSeconds: 5, defaultSets: 0, defaultRestSeconds: 0, instructions: [] });
    expect(prescription).toEqual({ sets: 1, targetLabel: "10 sec", restSeconds: 10 });
    expect(localizedPrescriptionSummary("ar", prescription)).toContain("10");
    expect(localizedPrescriptionSummary("ar", prescription)).toContain("راحة");
    for (const language of languages) {
      const summary = localizedPrescriptionSummary(language.code, prescription);
      expect(summary).not.toContain("{sets}");
      expect(summary).not.toContain("{target}");
      expect(summary).not.toContain("{rest}");
    }
  });
});
