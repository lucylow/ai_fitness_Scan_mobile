import { describe, expect, it } from "vitest";
import { normalizeAppState, persistenceStatusFor } from "../src/state/app-state-migration";
import type { AppState } from "../src/state/app-state";

const defaults: AppState = { schemaVersion: 4, hasCompletedOnboarding: false, demoMode: false, displayName: "Alex", preferredUnit: "metric", language: "en", languageFollowsDevice: false, reduceMotion: false, effortRangeDays: 30, coachTone: "encouraging", preferredDurationMinutes: 30, preferredDifficulty: "beginner", availableEquipment: ["none"], previewEquipment: ["none"], scanRemindersEnabled: false, interests: ["movement awareness"], scans: [], workouts: [] };

describe("AppState migration", () => {
  it("classifies persistence readiness by schema version", () => {
    expect(persistenceStatusFor({ schemaVersion: 4 }, 4)).toBe("ready");
    expect(persistenceStatusFor({ schemaVersion: 3 }, 4)).toBe("migrated");
    expect(persistenceStatusFor(null, 4)).toBe("recovered");
  });
  it("fills new defaults for legacy records", () => {
    const migrated = normalizeAppState({ displayName: "Sam", scans: [{ id: "s1" }] }, defaults);
    expect(migrated.displayName).toBe("Sam");
    expect(migrated.schemaVersion).toBe(4);
    expect(migrated.availableEquipment).toEqual(["none"]);
    expect(migrated.preferredDurationMinutes).toBe(30);
    expect(migrated.languageFollowsDevice).toBe(true);
    expect(migrated.reduceMotion).toBe(false);
  });
  it("preserves an explicit reduced-motion choice", () => {
    expect(normalizeAppState({ reduceMotion: true }, defaults).reduceMotion).toBe(true);
    expect(normalizeAppState({ reduceMotion: "yes" }, defaults).reduceMotion).toBe(false);
  });
  it("keeps explicit legacy language choices fixed", () => {
    expect(normalizeAppState({ language: "fr" }, defaults).languageFollowsDevice).toBe(false);
  });
  it("repairs invalid personalization and equipment values", () => {
    const migrated = normalizeAppState({ coachTone: "loud", preferredDifficulty: "expert", preferredDurationMinutes: 99, availableEquipment: ["none", "invalid"] }, defaults);
    expect(migrated.coachTone).toBe("encouraging");
    expect(migrated.preferredDifficulty).toBe("beginner");
    expect(migrated.preferredDurationMinutes).toBe(30);
    expect(migrated.availableEquipment).toEqual(["none"]);
  });
  it("is idempotent for already migrated state", () => {
    const migrated = normalizeAppState({ schemaVersion: 4, coachTone: "direct", preferredDurationMinutes: 45, availableEquipment: ["mat"] }, defaults);
    expect(normalizeAppState(migrated, defaults)).toEqual(migrated);
  });
  it("preserves a valid interrupted workout exercise position", () => {
    const migrated = normalizeAppState({ interruptedActivity: { kind: "workout", id: "w1", step: "rest", workoutRound: 2, exerciseIndex: 1, totalSteps: 3, updatedAt: 10 } }, defaults);
    expect(migrated.interruptedActivity?.exerciseIndex).toBe(1);
  });
  it("restores lifecycle-paused workout timing metadata", () => {
    const migrated = normalizeAppState({ interruptedActivity: { kind: "workout", id: "w1", step: "rest", workoutRound: 2, exerciseIndex: 1, totalSteps: 3, secondsRemaining: 14, pausedByLifecycle: true, updatedAt: 10 } }, defaults);
    expect(migrated.interruptedActivity?.secondsRemaining).toBe(14);
    expect(migrated.interruptedActivity?.pausedByLifecycle).toBe(true);
  });
  it("drops malformed interrupted workout exercise positions", () => {
    const migrated = normalizeAppState({ interruptedActivity: { kind: "workout", id: "w1", step: "rest", exerciseIndex: -2, updatedAt: 10 } }, defaults);
    expect(migrated.interruptedActivity?.id).toBe("w1");
    expect(migrated.interruptedActivity?.exerciseIndex).toBeUndefined();
  });
  it("drops invalid lifecycle timer metadata", () => {
    const migrated = normalizeAppState({ interruptedActivity: { kind: "workout", id: "w1", step: "work", secondsRemaining: -1, pausedByLifecycle: "yes", updatedAt: 10 } }, defaults);
    expect(migrated.interruptedActivity?.secondsRemaining).toBeUndefined();
    expect(migrated.interruptedActivity?.pausedByLifecycle).toBeUndefined();
  });
  it("removes the none sentinel when real equipment is selected", () => {
    expect(normalizeAppState({ availableEquipment: ["none", "mat", "mat"] }, defaults).availableEquipment).toEqual(["mat"]);
  });
  it("normalizes the local template preview equipment", () => {
    expect(normalizeAppState({}, defaults).previewEquipment).toEqual(["none"]);
    expect(normalizeAppState({ previewEquipment: ["none", "mat", "mat"] }, defaults).previewEquipment).toEqual(["mat"]);
    expect(normalizeAppState({ previewEquipment: ["invalid"] }, defaults).previewEquipment).toEqual(["none"]);
  });
});
