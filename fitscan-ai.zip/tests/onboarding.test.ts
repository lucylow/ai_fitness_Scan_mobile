import { describe, expect, it } from "vitest";
import { normalizeOnboardingName, onboardingProgress, toggleOnboardingGoal } from "../src/onboarding";

describe("onboarding helpers", () => {
  it("reports bounded progress for each setup step", () => {
    expect(onboardingProgress(0)).toBeCloseTo(1 / 3);
    expect(onboardingProgress(1)).toBeCloseTo(2 / 3);
    expect(onboardingProgress(2)).toBe(1);
    expect(onboardingProgress(-1)).toBeCloseTo(1 / 3);
    expect(onboardingProgress(99)).toBe(1);
  });

  it("toggles a goal without mutating the selected list", () => {
    const selected = ["strength", "mobility"];
    expect(toggleOnboardingGoal(selected, "strength")).toEqual(["mobility"]);
    expect(toggleOnboardingGoal(selected, "consistency")).toEqual(["strength", "mobility", "consistency"]);
    expect(selected).toEqual(["strength", "mobility"]);
  });

  it("normalizes optional display names with a safe fallback", () => {
    expect(normalizeOnboardingName("  Sam  ")).toBe("Sam");
    expect(normalizeOnboardingName("   ")).toBe("Alex");
    expect(normalizeOnboardingName("   ", "Vous")).toBe("Vous");
  });
});
