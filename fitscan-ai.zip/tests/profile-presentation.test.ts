import { describe, expect, it } from "vitest";
import { languages } from "../src/i18n";
import { localizedProfileAction, localizedProfileRecommendation } from "../src/profile-presentation";

describe("Profile presentation", () => {
  it("maps stable recommendation actions to localized names", () => {
    expect(localizedProfileAction("fr", "start_workout")).toBe("commencer une séance");
    expect(localizedProfileAction("ar", "review_progress")).toContain("تقدمك");
    expect(localizedProfileAction("ja", "complete_scan")).toContain("スキャン");
  });

  it("localizes recommendation sentences without leaking placeholders", () => {
    for (const language of languages) {
      const result = localizedProfileRecommendation(language.code, "start_workout");
      expect(result).not.toContain("{action}");
      expect(result).not.toContain("profile.nextAction");
    }
  });

  it("preserves recommendation action identity independently of language", () => {
    const actions = ["start_workout", "review_progress", "complete_scan"] as const;
    for (const action of actions) {
      expect(localizedProfileRecommendation("en", action)).toContain(localizedProfileAction("en", action));
    }
  });
});
