import { describe, expect, it } from "vitest";
import { clampProgress, recoveryLabel, resumeScanView, resumeWorkoutRound } from "../src/recovery";

describe("precise recovery progress", () => {
  it("bounds scan views and workout rounds to safe ranges", () => {
    expect(resumeScanView(-2)).toBe(0);
    expect(resumeScanView(9)).toBe(2);
    expect(resumeWorkoutRound(0)).toBe(1);
    expect(resumeWorkoutRound(8)).toBe(3);
    expect(clampProgress(undefined, 3)).toBe(0);
  });

  it("creates clear recovery copy", () => {
    expect(recoveryLabel("scan", 1, 3)).toBe("Scan view 2 of 3");
    expect(recoveryLabel("workout", 2, 3)).toBe("Workout round 2 of 3");
    expect(recoveryLabel("scan", 0, 3)).toBe("Scan view 1 of 3");
  });
});
