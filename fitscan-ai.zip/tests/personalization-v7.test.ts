import { describe, expect, it } from "vitest";
import { aggregateSignals, defaultPersonalizationV7, normalizeSignal, recommendNextAction, recencyWeight, signalScore } from "../src/personalization-v7";

describe("personalization v7", () => {
  it("creates stable local-first defaults", () => {
    const profile = defaultPersonalizationV7("u1", 1000);
    expect(profile.preferredDurationMinutes).toBe(20);
    expect(profile.recommendationConfidence).toBe(0.35);
    expect(profile.updatedAt).toBe(1000);
  });
  it("bounds signals and applies predictable recency decay", () => {
    expect(normalizeSignal(-1)).toBe(0);
    expect(normalizeSignal(2)).toBe(1);
    expect(recencyWeight(0, 30 * 86400000)).toBeCloseTo(0.5, 5);
    expect(signalScore({ id: "s", userId: "u1", type: "feedback", feature: "x", value: 2, confidence: 2, timestamp: 1000 }, 1000)).toBe(1.9);
  });
  it("aggregates signals by feature with confidence weighting", () => {
    const signals = [
      { id: "a", userId: "u1", type: "preference" as const, feature: "mobility", value: 1, confidence: 1, timestamp: 1000 },
      { id: "b", userId: "u1", type: "workout" as const, feature: "mobility", value: 0.5, confidence: 0.5, timestamp: 1000 },
    ];
    expect(aggregateSignals(signals, 1000).mobility).toBeCloseTo((1 + 0.5 * 0.5 * 0.85) / 1.5, 5);
  });
  it("uses explicit duration preferences in workout rationale", () => {
    const profile = { ...defaultPersonalizationV7("u1", 1000), preferredDurationMinutes: 45 };
    const recommendation = recommendNextAction(profile, [{ id: "scan", userId: "u1", type: "scan", feature: "scan_completed", value: 1, confidence: 1, timestamp: 1000 }], 1000);
    expect(recommendation.action).toBe("start_workout");
    expect(recommendation.reasons[0]).toContain("45-minute");
  });
  it("chooses an explainable baseline recommendation", () => {
    const profile = defaultPersonalizationV7("u1", 1000);
    const recommendation = recommendNextAction(profile, [], 1000);
    expect(recommendation.action).toBe("complete_scan");
    expect(recommendation.reasons[0]).toContain("baseline scan");
  });
});
