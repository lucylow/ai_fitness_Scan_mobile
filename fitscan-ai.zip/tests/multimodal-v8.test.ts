import { describe, expect, it } from "vitest";
import { calculateVisualQuality, filterLandmarks, normalizeLandmarks, shouldAcceptVisualFrame, visualGuidanceLabel, visualQualityPercent } from "../src/multimodal/v8";

describe("multimodal visual primitives", () => {
  it("clamps quality inputs and produces transparent readiness states", () => {
    const quality = calculateVisualQuality({ brightness: 2, sharpness: .8, contrast: .8, stability: .8, subjectVisibility: .9 });
    expect(quality.brightness).toBe(1);
    expect(visualQualityPercent(quality)).toBe(87);
    expect(shouldAcceptVisualFrame(quality)).toBe(true);
    expect(visualGuidanceLabel(quality)).toBe("ready");
  });

  it("filters low-confidence landmarks and normalizes coordinates", () => {
    const landmarks = filterLandmarks([{ name: "head", x: 50, y: 100, confidence: .9 }, { name: "wrist", x: 10, y: 20, confidence: .4 }]);
    expect(landmarks).toHaveLength(1);
    expect(normalizeLandmarks(landmarks, 100, 200)[0]).toMatchObject({ x: .5, y: .5 });
  });

  it("rejects poor framing while keeping a recoverable adjust state", () => {
    const quality = calculateVisualQuality({ brightness: .8, sharpness: .8, contrast: .8, stability: .8, subjectVisibility: .55 });
    expect(shouldAcceptVisualFrame(quality)).toBe(false);
    expect(visualGuidanceLabel(quality)).toBe("reframe");
  });
});
