import { describe, expect, it } from "vitest";
import { languages } from "../src/i18n";
import { localizedEffortAccessibilityLabel, localizedFitnessPreviewSelectionLabel, localizedMobilityAccessibilityLabel, localizedProfileOptionAccessibilityLabel, localizedScanHistoryAccessibilityLabel, localizedScanLandmarksAccessibilityLabel, localizedScanQualityAccessibilityLabel, localizedScanResultAccessibilityLabel } from "../src/accessibility-presentation";

describe("Scan and Progress accessibility presentation", () => {
  it("describes Scan quality, landmarks, and confidence in localized text", () => {
    expect(localizedScanQualityAccessibilityLabel("fr", 94, "Bonne qualité")).toContain("Qualité du scan");
    expect(localizedScanLandmarksAccessibilityLabel("ar", 5)).toContain("5");
    expect(localizedScanResultAccessibilityLabel("en", 94)).toBe("Scan result, 94 percent confidence");
  });

  it("describes Progress trends and scan history as grouped summaries", () => {
    expect(localizedMobilityAccessibilityLabel("en", "increasing", 8)).toBe("Mobility trend: Trending steadily. 8 points across your last 2 scans.");
    expect(localizedEffortAccessibilityLabel("fr", 7.5, "steady")).toContain("Effort de la séance");
    expect(localizedScanHistoryAccessibilityLabel("en", "Baseline", "Today", "94%", "Stored locally")).toBe("Baseline, Today, 94%, Stored locally");
  });

  it("describes Fitness preview selection state in localized text", () => {
    expect(localizedFitnessPreviewSelectionLabel("en", "Mat", true)).toBe("Equipment preview: Mat, selected");
    expect(localizedFitnessPreviewSelectionLabel("ar", "Mat", false)).toContain("معاينة المعدات");
  });

  it("describes Profile selected options in localized text", () => {
    expect(localizedProfileOptionAccessibilityLabel("en", "Encouraging", true)).toBe("Encouraging, selected");
    expect(localizedProfileOptionAccessibilityLabel("fr", "Calme", false)).toBe("Calme");
  });

  it("resolves complete labels in every supported language", () => {
    for (const language of languages) {
      const labels = [
        localizedScanQualityAccessibilityLabel(language.code, 94, "Good"),
        localizedScanLandmarksAccessibilityLabel(language.code, 5),
        localizedScanResultAccessibilityLabel(language.code, 94),
        localizedMobilityAccessibilityLabel(language.code, "steady", 0),
        localizedEffortAccessibilityLabel(language.code, null, null),
        localizedScanHistoryAccessibilityLabel(language.code, "Baseline", "Today", "94%", "Stored locally"),
        localizedFitnessPreviewSelectionLabel(language.code, "Mat", true),
        localizedProfileOptionAccessibilityLabel(language.code, "Encouraging", true),
      ];
      for (const label of labels) expect(label).not.toMatch(/\{[^}]+\}/);
    }
  });
});
