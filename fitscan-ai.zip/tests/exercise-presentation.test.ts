import { describe, expect, it } from "vitest";
import { languages } from "../src/i18n";
import { localizedExerciseInstruction, localizedExerciseName } from "../src/exercise-presentation";
import { localExerciseCatalog } from "../src/workout-catalog";
import type { ExerciseDefinition } from "../src/workouts/v6";

const airSquat = localExerciseCatalog.find((exercise) => exercise.id === "air-squat")!;
const unknownExercise: ExerciseDefinition = { ...airSquat, id: "unknown", name: "Custom movement", instructions: ["Use a comfortable range."] };

describe("localized exercise presentation", () => {
  it("returns localized names and instructions without changing catalog data", () => {
    expect(localizedExerciseName("fr", airSquat)).toBe("Squats au poids du corps");
    expect(localizedExerciseInstruction("ja", airSquat)).toBe("一定のテンポで動きます。");
    expect(airSquat.name).toBe("Air squats");
    expect(airSquat.instructions[0]).toBe("Move at a steady tempo.");
  });

  it("covers every supported language with resolved presentation copy", () => {
    for (const language of languages) {
      expect(localizedExerciseName(language.code, airSquat)).not.toBe("exercise.airSquat.name");
      expect(localizedExerciseInstruction(language.code, airSquat)).not.toBe("exercise.airSquat.instruction");
    }
  });

  it("falls back to the catalog values for an unknown exercise ID", () => {
    expect(localizedExerciseName("en", unknownExercise)).toBe("Custom movement");
    expect(localizedExerciseInstruction("en", unknownExercise)).toBe("Use a comfortable range.");
  });
});
