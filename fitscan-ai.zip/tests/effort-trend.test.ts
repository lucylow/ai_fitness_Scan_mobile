import { describe, expect, it } from "vitest";
import { effortAccessibilityLabels, recentEffortSeries, summarizeEffort, workoutsInEffortRange } from "../src/personalization-adapter";

describe("effort trend", () => {
  it("summarizes recent effort and detects rising intensity", () => {
    const trend = summarizeEffort([
      { id: "w2", completedAt: 2000, durationMinutes: 10, label: "Reset", effort: 8 },
      { id: "w1", completedAt: 1000, durationMinutes: 10, label: "Reset", effort: 5 },
    ]);
    expect(trend).toEqual({ average: 6.5, latest: 8, direction: "increasing", count: 2 });
  });
  it("clamps stored values and exposes recent values oldest to newest", () => {
    const workouts = [
      { id: "w3", completedAt: 3000, durationMinutes: 10, label: "Reset", effort: 14 },
      { id: "w2", completedAt: 2000, durationMinutes: 10, label: "Reset", effort: 6 },
      { id: "w1", completedAt: 1000, durationMinutes: 10, label: "Reset", effort: -2 },
    ];
    expect(recentEffortSeries(workouts, 2)).toEqual([6, 10]);
    expect(effortAccessibilityLabels([6, 10])).toEqual(["Workout 1: effort 6 out of 10", "Workout 2: effort 10 out of 10"]);
  });
  it("filters workouts by a deterministic local date range", () => {
    const now = 10 * 24 * 60 * 60 * 1000;
    const workouts = [
      { id: "recent", completedAt: now - 6 * 24 * 60 * 60 * 1000, durationMinutes: 10, label: "Reset", effort: 6 },
      { id: "older", completedAt: now - 8 * 24 * 60 * 60 * 1000, durationMinutes: 10, label: "Reset", effort: 8 },
    ];
    expect(workoutsInEffortRange(workouts, 7, now).map((workout) => workout.id)).toEqual(["recent"]);
    expect(workoutsInEffortRange(workouts, 365, now)).toHaveLength(2);
  });
  it("handles an empty local effort history", () => {
    expect(summarizeEffort([])).toEqual({ average: 0, direction: "steady", count: 0 });
    expect(recentEffortSeries([])).toEqual([]);
  });
});
