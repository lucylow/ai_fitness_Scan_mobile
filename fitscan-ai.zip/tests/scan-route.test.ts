import { describe, expect, it } from "vitest";
import { advanceScanStage, cancelScan, canUndoScanCancellation, restoreScanCancellation, scanCaptureLabel } from "../src/scan-route";

describe("scan route progression", () => {
  it("cancels an in-progress scan back to a clean idle state", () => {
    expect(cancelScan("permission", 0)).toEqual({ stage: "idle", view: 0 });
    expect(cancelScan("capture", 2)).toEqual({ stage: "idle", view: 0 });
    expect(cancelScan("processing", 3)).toEqual({ stage: "idle", view: 0 });
  });

  it("keeps terminal stages stable when cancellation is requested", () => {
    expect(cancelScan("idle", 9)).toEqual({ stage: "idle", view: 2 });
    expect(cancelScan("result", -1)).toEqual({ stage: "result", view: 0 });
  });

  it("moves through permission, setup, and the three capture views", () => {
    expect(advanceScanStage("permission", 0)).toEqual({ stage: "setup", view: 0 });
    expect(advanceScanStage("setup", 0)).toEqual({ stage: "capture", view: 0 });
    expect(advanceScanStage("capture", 0)).toEqual({ stage: "capture", view: 1 });
    expect(advanceScanStage("capture", 1)).toEqual({ stage: "capture", view: 2 });
    expect(advanceScanStage("capture", 2)).toEqual({ stage: "processing", view: 3 });
  });

  it("does not advance terminal or idle stages", () => {
    expect(advanceScanStage("idle", 0)).toEqual({ stage: "idle", view: 0 });
    expect(advanceScanStage("processing", 3)).toEqual({ stage: "processing", view: 2 });
    expect(advanceScanStage("result", 2)).toEqual({ stage: "result", view: 2 });
  });

  it("clamps malformed view indexes before advancing", () => {
    expect(advanceScanStage("capture", -10)).toEqual({ stage: "capture", view: 1 });
    expect(advanceScanStage("capture", 99)).toEqual({ stage: "processing", view: 3 });
    expect(scanCaptureLabel(-1)).toBe("front");
    expect(scanCaptureLabel(1.8)).toBe("side");
    expect(scanCaptureLabel(100)).toBe("back");
  });

  it("allows Undo only before the bounded cancellation window expires", () => {
    const undo = { id: "scan-1", stage: "capture" as const, view: 8, expiresAt: 5_000 };
    expect(canUndoScanCancellation(undo, 4_999)).toBe(true);
    expect(canUndoScanCancellation(undo, 5_000)).toBe(false);
    expect(restoreScanCancellation(undo, 4_999)).toEqual({ stage: "capture", view: 2 });
    expect(restoreScanCancellation(undo, 5_000)).toBeUndefined();
  });

  it("rejects invalid current times for Undo", () => {
    const undo = { id: "scan-1", stage: "setup" as const, view: 0, expiresAt: 5_000 };
    expect(canUndoScanCancellation(undo, Number.NaN)).toBe(false);
    expect(restoreScanCancellation(undefined, 1)).toBeUndefined();
    expect(restoreScanCancellation(undo, Number.NaN)).toBeUndefined();
  });
});
