import { describe, expect, it } from "vitest";
import { clampSessionDuration, difficultyAwareCatalog } from "../src/workout-adaptation";
import type { ExerciseDefinition } from "../src/workouts/v6";

const catalog: ExerciseDefinition[] = [
  { id: "easy", name: "Easy", category: "strength", movementPattern: "squat", equipment: ["none"], difficulty: "beginner", defaultReps: 8, defaultSets: 2, defaultRestSeconds: 20, instructions: [] },
  { id: "hard", name: "Hard", category: "strength", movementPattern: "squat", equipment: ["none"], difficulty: "advanced", defaultReps: 8, defaultSets: 2, defaultRestSeconds: 20, instructions: [] },
];

describe("workout adaptation", () => {
  it("selects exercises matching the requested difficulty", () => {
    expect(difficultyAwareCatalog(catalog, "advanced").map((item) => item.id)).toEqual(["hard"]);
  });
  it("falls back to the full catalog when no exact difficulty exists", () => {
    expect(difficultyAwareCatalog(catalog, "intermediate")).toHaveLength(2);
  });
  it("clamps session duration to planner bounds", () => {
    expect(clampSessionDuration(-2)).toBe(5);
    expect(clampSessionDuration(42.4)).toBe(42);
    expect(clampSessionDuration(240)).toBe(180);
  });
});
