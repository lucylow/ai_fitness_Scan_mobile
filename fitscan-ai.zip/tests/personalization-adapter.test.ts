import { describe, expect, it } from "vitest";
import { persistedHistorySignals, persistedWorkoutSignals } from "../src/personalization-adapter";

describe("persisted personalization adapters", () => {
  it("converts completed scans into bounded scan signals", () => {
    const signals = persistedHistorySignals("u1", [{ id: "s1", createdAt: 1000, quality: 120, status: "complete", label: "Baseline" }], []);
    expect(signals[0]).toMatchObject({ feature: "scan_completed", value: 1, type: "scan" });
  });
  it("clamps stored effort and emits a feedback signal", () => {
    const signals = persistedWorkoutSignals("u1", [{ id: "w1", completedAt: 2000, durationMinutes: 10, label: "Reset", effort: 14 }]);
    const effort = signals.find((signal) => signal.feature === "workout_effort");
    expect(effort).toMatchObject({ value: 1, confidence: 0.95 });
    expect(effort?.metadata).toMatchObject({ effort: 10 });
  });
  it("preserves legacy workouts without adding synthetic effort feedback", () => {
    const signals = persistedWorkoutSignals("u1", [{ id: "w1", completedAt: 2000, durationMinutes: 10, label: "Reset" }]);
    expect(signals.some((signal) => signal.feature === "workout_effort")).toBe(false);
  });
});
