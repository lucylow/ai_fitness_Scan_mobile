import { describe, expect, it } from "vitest";
import { calculateTrend, compareScans, dataQuality, detectOutliers, normalizeNumber, summarizeWorkouts } from "../src/analytics";

describe("analytics utilities", () => {
  it("normalizes invalid values safely", () => { expect(normalizeNumber("42")).toBe(42); expect(normalizeNumber("nope", 7)).toBe(7); });
  it("detects a meaningful increasing trend", () => { const result = calculateTrend("Mobility", [{ id: "1", metric: "Mobility", value: 60, timestamp: 1 }, { id: "2", metric: "Mobility", value: 72, timestamp: 2 }]); expect(result.direction).toBe("increasing"); expect(result.change).toBe(12); });
  it("compares scan measurements with relative change", () => { const result = compareScans({ scanId: "a", timestamp: 1, quality: .9, completeness: .9, consistency: .9, measurements: [{ region: "waist", value: 80, unit: "cm", confidence: .8 }] }, { scanId: "b", timestamp: 2, quality: .95, completeness: .95, consistency: .92, measurements: [{ region: "waist", value: 78, unit: "cm", confidence: .9 }] }); expect(result.changes[0].absoluteChange).toBe(-2); expect(result.changes[0].relativeChange).toBe(-0.025); });
  it("summarizes workouts and flags quality", () => { expect(summarizeWorkouts([{ workoutId: "w", timestamp: 1, durationMinutes: 10, completed: true, exercises: [] }]).completionRate).toBe(1); expect(dataQuality(.94)).toBe("excellent"); expect(detectOutliers([1, 1, 1, 10], 1.5).length).toBe(1); });
});
