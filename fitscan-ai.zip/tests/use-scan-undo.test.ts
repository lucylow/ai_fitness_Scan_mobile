import { describe, expect, it } from "vitest";

import { scanUndoRemainingMs } from "../src/use-scan-undo";

describe("Scan Undo lifecycle timing", () => {
  it("returns the remaining bounded window", () => {
    expect(scanUndoRemainingMs(5_000, 1_250)).toBe(3_750);
  });

  it("returns zero at and after expiry", () => {
    expect(scanUndoRemainingMs(5_000, 5_000)).toBe(0);
    expect(scanUndoRemainingMs(5_000, 6_000)).toBe(0);
  });

  it("fails closed for invalid timestamps", () => {
    expect(scanUndoRemainingMs(Number.NaN, 1_000)).toBe(0);
    expect(scanUndoRemainingMs(5_000, Number.POSITIVE_INFINITY)).toBe(0);
  });
});
