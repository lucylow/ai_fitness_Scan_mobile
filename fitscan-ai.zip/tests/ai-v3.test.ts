import { describe, expect, it } from "vitest";
import { FallbackChain, ModelRegistry, ModelRouter, adaptiveCameraGuidance, calibrateConfidence, confidenceLevel, safetyGate } from "../src/ai/v3";

describe("ai v3", () => {
  it("routes supported models and falls back after failure", async () => {
    const registry = new ModelRegistry();
    registry.register({ id: "broken", version: "1", supports: () => true, predict: async () => { throw new Error("offline"); } });
    registry.register({ id: "safe", version: "1", supports: () => true, predict: async () => "ok" });
    expect(ModelRouter && registry.get("safe")?.id).toBe("safe");
    await expect(new FallbackChain([registry.get("broken")!, registry.get("safe")!]).predict({})).resolves.toBe("ok");
  });
  it("calibrates confidence and blocks low-confidence actions", () => {
    expect(calibrateConfidence(0.8, 10, 1)).toBeCloseTo(0.9);
    expect(confidenceLevel(0.9)).toBe("very-high");
    expect(safetyGate(0.4, "Use this plan").allowed).toBe(false);
    expect(safetyGate(0.9, "Use this plan").allowed).toBe(true);
  });
  it("returns actionable camera guidance", () => {
    expect(adaptiveCameraGuidance({ bodyDetected: false, bodyConfidence: .3, silhouetteConfidence: .4, lightingScore: .9, framingScore: .9, blurScore: .9, poseConfidence: .8 })).toContain("Step into");
  });
});
