import { describe, expect, it } from "vitest";
import { EntitlementService, MockBillingAdapter, UsageService, UsageTracker, freePlan, transparentPaywallCopy, withinUsageLimit } from "../src/monetization";

describe("monetization", () => {
  it("keeps basic scans available while gating premium features", () => {
    const free = new EntitlementService({ userId: "u1", plan: "free", state: "active" });
    expect(free.has("basic_scan")).toBe(true);
    expect(free.has("advanced_AI")).toBe(false);
  });
  it("tracks usage without allowing a free limit overrun", () => {
    const tracker = new UsageTracker();
    const usage = new UsageService(tracker);
    usage.consume("u1", "scan");
    usage.consume("u1", "scan");
    expect(usage.check("u1", "scan", freePlan.scansPerMonth).allowed).toBe(false);
    expect(withinUsageLimit(2, Infinity)).toBe(true);
  });
  it("returns mock billing products and transparent copy", async () => {
    const billing = new MockBillingAdapter();
    const result = await billing.purchase("fitscan_premium_monthly");
    expect(result.state).toBe("active");
    expect(transparentPaywallCopy("AI_coach").body).toContain("basic scan remains available");
  });
});
