import { describe, expect, it } from "vitest";
import { buildPersonalizationSignals, calculatePreferenceConfidence, createDefaultPersonalization, findAvoidedExercises, nextBestAction, scoreExercisePreferences, scoreWorkoutPreference, updatePreference } from "../src/personalization";

describe("personalization", () => {
  it("creates valid defaults and validates explicit updates", () => {
    const profile = createDefaultPersonalization("u1", 1000);
    expect(profile.preferredDurationMinutes).toBe(20);
    expect(updatePreference(profile, "preferredDurationMinutes", 30, 2000).updatedAt).toBe(2000);
  });
  it("scores behavior while preserving explicit safety boundaries", () => {
    const actions = [
      { id: "1", userId: "u1", type: "workout_completed" as const, metadata: { workoutType: "mobility" }, timestamp: 1 },
      { id: "2", userId: "u1", type: "exercise_skipped" as const, targetId: "jump", timestamp: 2 },
      { id: "3", userId: "u1", type: "exercise_skipped" as const, targetId: "jump", timestamp: 3 },
    ];
    expect(scoreWorkoutPreference(actions).mobility).toBe(2);
    expect(scoreExercisePreferences(actions).jump).toBe(-4);
    expect(findAvoidedExercises(scoreExercisePreferences(actions))).toEqual(["jump"]);
  });
  it("derives confidence and a next best action from evidence", () => {
    expect(calculatePreferenceConfidence(10, 1)).toBe(1);
    const signals = buildPersonalizationSignals([
      { id: "1", userId: "u1", type: "workout_started", timestamp: Date.now() },
      { id: "2", userId: "u1", type: "workout_completed", timestamp: Date.now() },
    ], [20]);
    expect(signals.workoutCompletionRate).toBe(1);
    expect(nextBestAction(signals)).toBe("start_workout");
  });
});
