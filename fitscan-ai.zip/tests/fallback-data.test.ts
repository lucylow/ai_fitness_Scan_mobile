import { describe, expect, it } from "vitest";
import { displayScanHistory, displayWorkoutHistory, FALLBACK_SCAN, FALLBACK_WORKOUT, shouldUseFallbackData } from "../src/fallback-data";

describe("fallback data", () => {
  it("uses fallback data only after persistence recovery with no local records", () => {
    expect(shouldUseFallbackData("recovered", false)).toBe(true);
    expect(shouldUseFallbackData("ready", false)).toBe(false);
    expect(shouldUseFallbackData("recovered", true)).toBe(false);
  });

  it("keeps real scan and workout history ahead of fallback records", () => {
    const scan = { ...FALLBACK_SCAN, id: "real_scan", label: "Real scan" };
    const workout = { ...FALLBACK_WORKOUT, id: "real_workout", label: "Real workout" };
    expect(displayScanHistory([scan], "recovered")).toEqual([scan]);
    expect(displayWorkoutHistory([workout], "recovered")).toEqual([workout]);
  });

  it("returns labeled fallback records for recovered empty state", () => {
    expect(displayScanHistory([], "recovered")[0].label).toBe("Sample baseline");
    expect(displayWorkoutHistory([], "recovered")[0].label).toBe("Sample full-body session");
  });
});
