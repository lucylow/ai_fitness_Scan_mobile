import { describe, expect, it } from "vitest";
import { canTransitionScan, evaluateCamera, frameQuality, scanQualityGuidance } from "../src/scan/v4";
import { createCoachRequest, groundedConfidence, safetyLimitations, validateCoachRequest } from "../src/coach/v5";

describe("scan-v4 contracts", () => {
  it("scores quality deterministically and gives actionable guidance", () => {
    const quality = frameQuality({ brightness: 0.8, sharpness: 0.8, framing: 0.8, body: 0.9, pose: 0.8 });
    expect(quality.total).toBe(0.83);
    expect(scanQualityGuidance(quality)).toBe("Frame quality looks good.");
  });
  it("separates camera readiness problems from the ready state", () => {
    expect(evaluateCamera({ hasCamera: true, rearCamera: true, autofocus: false, stableOrientation: true, frameRate: 30, width: 1920, height: 1080 })).toEqual({ ready: false, problems: ["Autofocus unavailable."] });
    expect(canTransitionScan("capturing", "processing")).toBe(true);
    expect(canTransitionScan("complete", "capturing")).toBe(false);
  });
});

describe("Coach-v5 contracts", () => {
  it("trims and validates grounded requests", () => {
    const request = createCoachRequest("local-user", "coach-1", "  Help me plan a short session.  ", "planning");
    expect(request.message).toBe("Help me plan a short session.");
    expect(validateCoachRequest(request)).toBe(true);
  });
  it("adds safety limitations and calibrates confidence from evidence", () => {
    expect(safetyLimitations("I feel pain in my knee")).toHaveLength(2);
    expect(groundedConfidence([{ source: "workout", statement: "Completed two sessions", confidence: 0.8 }], "Keep building consistency.")).toBe(0.8);
    expect(groundedConfidence([], "A general suggestion.")).toBe(0.45);
  });
});
