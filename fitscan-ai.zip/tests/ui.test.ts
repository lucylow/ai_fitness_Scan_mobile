import { describe, expect, it } from "vitest";
import themeConfig from "../theme.config";

describe("FitScan visual system", () => {
  it("keeps the calm purple brand palette and accessible contrast anchors", () => {
    expect(themeConfig.themeColors.primary.light).toBe("#5B5CE2");
    expect(themeConfig.themeColors.foreground.light).toBe("#111318");
    expect(themeConfig.themeColors.background.light).toBe("#F7F8FA");
    expect(themeConfig.themeColors.success.light).toBe("#2C9B69");
  });

  it("provides distinct dark-mode surfaces and text", () => {
    expect(themeConfig.themeColors.background.dark).not.toBe(themeConfig.themeColors.background.light);
    expect(themeConfig.themeColors.foreground.dark).not.toBe(themeConfig.themeColors.foreground.light);
    expect(themeConfig.themeColors.border.dark).not.toBe(themeConfig.themeColors.border.light);
  });
});
