import { describe, expect, it } from "vitest";
import { languages } from "../src/i18n";
import { localizedWorkoutPrescriptionAccessibilityLabel, localizedWorkoutTimerAccessibilityLabel } from "../src/workout-accessibility";

const prescription = { sets: 3, targetLabel: "10 reps", restSeconds: 20 };

describe("Workout accessibility labels", () => {
  it("describes the current exercise, phase, and remaining time", () => {
    expect(localizedWorkoutTimerAccessibilityLabel("en", "Air squats", "work", 12)).toBe("Air squats, Work, 12 seconds remaining");
    expect(localizedWorkoutTimerAccessibilityLabel("fr", "Squats", "rest", 8)).toContain("8 secondes restantes");
  });

  it("localizes prescription labels and preserves nested summary formatting", () => {
    expect(localizedWorkoutPrescriptionAccessibilityLabel("fr", prescription)).toBe("Prescription : 3 séries × 10 répétitions · 20 s de repos");
    expect(localizedWorkoutTimerAccessibilityLabel("ar", "تمرين", "work", 12)).toContain("12");
  });

  it("resolves complete labels for every supported language", () => {
    for (const language of languages) {
      const timer = localizedWorkoutTimerAccessibilityLabel(language.code, "Exercise", "rest", 5);
      const summary = localizedWorkoutPrescriptionAccessibilityLabel(language.code, prescription);
      expect(timer).not.toContain("{exercise}");
      expect(timer).not.toContain("{phase}");
      expect(summary).not.toContain("{summary}");
    }
  });
});
