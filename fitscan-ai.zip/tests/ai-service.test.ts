import { describe, expect, it } from "vitest";
import { analyzeScan, askCoach } from "../src/ai/service";

describe("AI service boundaries", () => {
  it("returns normalized, displayable scan confidence", async () => { const result = await analyzeScan({ frames: [], heightCm: 175, deviceOrientation: "portrait" }, "session_1"); expect(result.response.confidence).toBeGreaterThanOrEqual(0); expect(result.displayable).toBe(true); });
  it("returns actionable coach metadata", async () => { const result = await askCoach({ message: "What should I do today?", conversation: [] }, "session_2"); expect(result.response.output.answer.length).toBeGreaterThan(0); expect(result.actionable).toBe(true); });
});
