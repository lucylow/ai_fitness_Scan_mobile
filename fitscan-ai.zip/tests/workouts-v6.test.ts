import { describe, expect, it } from "vitest";
import { adaptNextInstruction, difficultyMatch, equipmentMatch, planWorkout, type ExerciseDefinition } from "../src/workouts/v6";

const catalog: ExerciseDefinition[] = [
  { id: "squat", name: "Air squats", category: "strength", movementPattern: "squat", equipment: ["none"], difficulty: "beginner", defaultReps: 10, defaultSets: 3, defaultRestSeconds: 20, instructions: [] },
  { id: "band-row", name: "Band rows", category: "strength", movementPattern: "pull", equipment: ["band"], difficulty: "intermediate", defaultReps: 8, defaultSets: 3, defaultRestSeconds: 30, instructions: [] },
];

describe("workout-v6 planner", () => {
  it("matches available equipment and requested difficulty", () => {
    expect(equipmentMatch(["band"], ["none"])).toBe(0);
    expect(equipmentMatch(["band"], ["band"])).toBe(1);
    expect(difficultyMatch("beginner", "beginner")).toBe(1);
    expect(difficultyMatch("beginner", "advanced")).toBeCloseTo(0.3, 5);
  });
  it("creates a local-first plan from constraints", () => {
    const plan = planWorkout(catalog, { userId: "local-user", durationMinutes: 12, objective: "strength", difficulty: "beginner", equipment: ["none"], constraints: { maximumExercises: 2 } });
    expect(plan.durationMinutes).toBe(12);
    expect(plan.exerciseIds).toEqual(["squat"]);
    expect(plan.rationale).toContain("available time");
  });
  it("adapts the next instruction to perceived effort", () => {
    expect(adaptNextInstruction(2, 2, 9)).toContain("Reduce");
    expect(adaptNextInstruction(3, 3, 3)).toContain("progress");
    expect(adaptNextInstruction(1, 3, 6)).toContain("steady pace");
  });
});
