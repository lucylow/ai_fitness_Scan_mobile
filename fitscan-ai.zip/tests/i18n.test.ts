import { describe, expect, it } from "vitest";
import { accessibilityDirection, detectLanguage, formatEffortRange, formatNumber, formatRecoveryProgress, isRTL, languages, layoutDirection, translate, translationKeys } from "../src/i18n";

describe("FitScan localization", () => {
  it("detects supported languages and falls back to English", () => {
    expect(detectLanguage("fr-FR")).toBe("fr");
    expect(detectLanguage("xx-XX")).toBe("en");
    expect(translate("fr", "navigation.home")).toBe("Accueil");
    expect(translate("wo", "home.startScan")).toBe("Start scan");
    expect(translate("fr", "recovery.resume")).toBe("Reprendre");
    expect(translate("es", "recovery.discard")).toBe("Descartar");
    expect(translate("ar", "recovery.title")).toBe("استئناف");
    expect(translate("en", "workout.pausedBySystem")).toContain("Paused automatically");
    expect(translate("fr", "workout.pausedBySystemDetail")).toContain("appareil");
    expect(translate("ar", "workout.pausedBySystem")).toContain("تلقائيًا");
    expect(translate("pt", "workout.pausedBySystem")).toContain("Pausa automática");
    expect(translate("wo", "workout.pausedBySystem")).toContain("Nellu");
    for (const language of languages) {
      expect(translate(language.code, "workout.pausedBySystem")).not.toBe("workout.pausedBySystem");
      expect(translate(language.code, "workout.pausedBySystemDetail")).not.toBe("workout.pausedBySystemDetail");
      expect(translate(language.code, "workout.exerciseProgress", "fallback", { current: 1, total: 3 })).not.toContain("{current}");
      expect(translate(language.code, "workout.effortOption", "fallback", { value: 6 })).not.toContain("{value}");
      expect(translate(language.code, "workout.completed.body", "fallback", { minutes: 30 })).not.toContain("{minutes}");
    }
  });
  it("exposes RTL metadata and stable translation keys", () => {
    expect(isRTL("ar")).toBe(true);
    expect(isRTL("en")).toBe(false);
    expect(layoutDirection("ar")).toBe("rtl");
    expect(accessibilityDirection("ar")).toEqual({ writingDirection: "rtl", textAlign: "right" });
    expect(translationKeys).toContain("navigation.home");
  });
  it("localizes workout phase transition cues for every supported language", () => {
    expect(translate("fr", "workout.phaseCue.work")).toContain("contrôle");
    expect(translate("ar", "workout.phaseCue.rest")).toContain("تنفس");
    expect(translate("ja", "workout.phaseCue.work")).toContain("コントロール");
    for (const language of languages) {
      expect(translate(language.code, "workout.phaseCue.work")).not.toBe("workout.phaseCue.work");
      expect(translate(language.code, "workout.phaseCue.rest")).not.toBe("workout.phaseCue.rest");
    }
  });
  it("localizes Coach surface copy and Scan discard confirmation for every supported language", () => {
    expect(translate("fr", "coach.title")).toContain("Planifiez");
    expect(translate("es", "coach.nextAction", "fallback", { action: "move" })).toContain("move");
    expect(translate("ar", "scan.discarded")).toContain("حذف");
    expect(translate("fr", "scan.undo")).toBe("Annuler");
    expect(translate("ja", "scan.undoAccessibility")).toContain("スキャン");
    for (const language of languages) {
      expect(translate(language.code, "coach.kicker")).not.toBe("coach.kicker");
      expect(translate(language.code, "coach.placeholder")).not.toBe("coach.placeholder");
      expect(translate(language.code, "coach.nextAction", "fallback", { action: "move" })).not.toContain("{action}");
      expect(translate(language.code, "coach.recommendationConfidence", "fallback", { value: 80 })).not.toContain("{value}");
      expect(translate(language.code, "scan.discarded")).not.toBe("scan.discarded");
      expect(translate(language.code, "scan.estimatesLabeled")).not.toBe("scan.estimatesLabeled");
      expect(translate(language.code, "scan.frameQuality")).not.toBe("scan.frameQuality");
      expect(translate(language.code, "scan.undo")).not.toBe("scan.undo");
      expect(translate(language.code, "scan.undoAccessibility")).not.toBe("scan.undoAccessibility");
    }
  });
  it("localizes Fitness template subtitles for every supported language", () => {
    const subtitleKeys = ["fitness.template.fullBodySub", "fitness.template.mobilitySub", "fitness.template.lowerBodySub", "fitness.template.recoverySub"];
    for (const language of languages) {
      for (const key of subtitleKeys) {
        expect(translate(language.code, key)).not.toBe(key);
      }
    }
    expect(translate("fr", "fitness.template.mobilitySub")).toContain("équipement");
    expect(translate("ja", "fitness.template.recoverySub")).toContain("やさしく");
  });
  it("formats recovery progress for every supported language", () => {
    for (const language of languages) {
      expect(formatRecoveryProgress(language.code, "scan", 2, 3)).not.toContain("{current}");
      expect(formatRecoveryProgress(language.code, "workout", 1, 3)).not.toContain("{total}");
    }
  });
  it("localizes effort trend labels and interpolation", () => {
    expect(translate("fr", "progress.effortAverage", "fallback", { value: 6.5 })).toContain("6.5");
    expect(translate("ja", "progress.effortWorkout", "fallback", { index: 2, value: 7 })).toContain("7");
    expect(translate("ar", "progress.effortEmpty")).not.toBe(translate("en", "progress.effortEmpty"));
  });
  it("formats effort range labels for selected languages", () => {
    expect(formatEffortRange("fr", 7)).toContain("jours");
    expect(formatEffortRange("ar", 365)).toContain("سنة");
    expect(formatEffortRange("ja", 30)).toContain("日間");
  });
  it("formats numbers with the selected locale", () => {
    expect(formatNumber(1234.5, "en")).toContain("1,234");
    expect(formatNumber(1234.5, "de")).toContain("1.234");
  });
  it("localizes Profile preference, privacy, and reset copy", () => {
    expect(translate("fr", "profile.localStorageTitle")).toBe("Stockage local privé");
    expect(translate("ar", "profile.privacyControls")).toContain("الخصوصية");
    expect(translate("ja", "profile.resetTitle")).toContain("リセット");
    for (const language of languages) {
      expect(translate(language.code, "profile.localPrivacyDetail")).not.toBe("profile.localPrivacyDetail");
      expect(translate(language.code, "profile.resetBody")).not.toBe("profile.resetBody");
      expect(translate(language.code, "profile.minutes", "fallback", { count: 30 })).not.toContain("{count}");
    }
  });
  it("localizes the complete Subscription surface for every supported language", () => {
    expect(translate("fr", "subscription.heading")).toContain("profondeur");
    expect(translate("ar", "subscription.choosePlan")).toContain("خطة");
    expect(translate("ja", "subscription.freeTitle")).toContain("無料");
    expect(translate("ko", "subscription.benefitCoach")).toContain("AI");
    for (const language of languages) {
      expect(translate(language.code, "subscription.subtitle")).not.toBe("subscription.subtitle");
      expect(translate(language.code, "subscription.continue", "fallback", { plan: "Monthly" })).not.toContain("{plan}");
      expect(translate(language.code, "subscription.legal")).not.toBe("subscription.legal");
    }
  });
});
