import { describe, expect, it } from "vitest";
import { formatActivityDate, summarizeActivity } from "../src/activity";

describe("activity helpers", () => {
  it("formats persisted activity dates consistently", () => { expect(formatActivityDate(Date.UTC(2026, 7, 21))).toBe("Aug 21, 2026"); });
  it("summarizes empty and populated activity", () => { expect(summarizeActivity(0, 0)).toBe("No activity yet"); expect(summarizeActivity(1, 2)).toBe("1 scan · 2 workouts"); });
  it("localizes activity summaries and dates", () => { expect(summarizeActivity(2, 1, "fr")).toContain("scans"); expect(summarizeActivity(0, 0, "ar")).not.toBe("No activity yet"); expect(formatActivityDate(Date.UTC(2026, 7, 21), "de")).toContain("2026"); });
});
