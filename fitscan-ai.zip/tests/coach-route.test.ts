import { describe, expect, it } from "vitest";
import { buildCoachRequestInput, canSubmitCoachRequest, normalizeCoachQuestion } from "../src/coach-route";

describe("Coach request interaction state", () => {
  it("trims a question before sending it", () => {
    expect(normalizeCoachQuestion("  How should I train?  ")).toBe("How should I train?");
    expect(buildCoachRequestInput("  How should I train?  ")).toEqual({ message: "How should I train?", conversation: [] });
  });

  it("uses a safe default for empty or malformed input", () => {
    expect(normalizeCoachQuestion("   ")).toBe("How should I train today?");
    expect(normalizeCoachQuestion(null)).toBe("How should I train today?");
  });

  it("blocks duplicate requests while one request is active", () => {
    expect(canSubmitCoachRequest(false)).toBe(true);
    expect(canSubmitCoachRequest(true)).toBe(false);
  });
});
