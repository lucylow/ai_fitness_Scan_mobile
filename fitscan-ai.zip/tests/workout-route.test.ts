import { describe, expect, it } from "vitest";
import { normalizeWorkoutTemplate, workoutLaunchTitle } from "../src/workout-route";

describe("workout route parameters", () => {
  it("accepts supported templates and creates a readable title", () => {
    expect(normalizeWorkoutTemplate("Mobility")).toBe("Mobility");
    expect(workoutLaunchTitle("Full body")).toBe("Full body session");
  });

  it("rejects malformed or unsupported template values safely", () => {
    expect(normalizeWorkoutTemplate(["Recovery", "Unexpected"])).toBe("Recovery");
    expect(normalizeWorkoutTemplate("Unexpected")).toBeUndefined();
    expect(normalizeWorkoutTemplate(42)).toBeUndefined();
    expect(workoutLaunchTitle(undefined)).toBe("Quick reset");
  });
});
