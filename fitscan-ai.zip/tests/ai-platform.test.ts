import { describe, expect, it } from "vitest";
import { AIRouter, AIOrchestrator, buildAIRequest, calculateFramingScore, canRecommendAction, defaultConfidencePolicy, normalizeConfidence, renderPrompt, sanitizeAIInput, type AIProviderAdapter } from "../src/ai/platform";

describe("AI platform", () => {
  const provider: AIProviderAdapter = { name: "mock", supports: () => true, generate: async <TInput, TOutput>(request: { id: string; model: "vision" | "pose" | "language" | "recommendation" | "classification" | "embedding" }) => ({ requestId: request.id, model: request.model, output: { answer: "ok" } as TOutput, confidence: 1.2, latencyMs: 1, provider: "mock" as const, createdAt: Date.now() }) };
  it("routes and normalizes orchestrated responses", async () => { const response = await new AIOrchestrator(new AIRouter([provider])).run(buildAIRequest("language", { text: "hello" })); expect(response.output).toEqual({ answer: "ok" }); expect(response.confidence).toBe(1); });
  it("enforces confidence thresholds", () => { expect(normalizeConfidence(-1)).toBe(0); expect(canRecommendAction(.69)).toBe(false); expect(canRecommendAction(.7, defaultConfidencePolicy)).toBe(true); });
  it("sanitizes sensitive input and renders prompts", () => { expect(sanitizeAIInput({ token: "secret", text: "hello" })).toEqual({ text: "hello" }); expect(renderPrompt({ id: "coach", version: "1", system: "safe", user: "Hi {{name}}" }, { name: "Alex" }).user).toBe("Hi Alex"); });
  it("scores ideal framing higher than an off-frame body", () => { expect(calculateFramingScore({ x: .2, y: .05, width: .6, height: .9 })).toBe(1); expect(calculateFramingScore({ x: 0, y: 0, width: .2, height: .2 })).toBeLessThan(.5); });
});
