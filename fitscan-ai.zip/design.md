# FitScan AI Mobile Interface Design

## Product direction

FitScan AI is a premium, privacy-first fitness progress companion. The interface is designed for portrait orientation and one-handed use, with a calm near-white canvas, dark typography, indigo scan accents, and generous rounded surfaces. It emphasizes movement, consistency, and longitudinal progress rather than appearance ranking or body judgment.

## Screen list

| Screen | Primary content and functionality |
|---|---|
| Splash | FitScan AI mark, subtle scan-line motion, and a short transition into the welcome experience. |
| Welcome | “Your fitness journey, in 3D.” Hero visual, supporting copy, Get Started, and Explore Demo. |
| Privacy intro | Plain-language explanation of camera use, local/cloud processing, storage, deletion, and privacy controls. |
| Goals | Select movement and fitness interests such as strength, mobility, performance, awareness, and consistency. |
| Baseline setup | Confirm profile basics needed for responsible estimates: age range, height, unit, and scan frequency. |
| Camera permission | Explain why camera access is needed and offer Allow Camera or Not Now with a graceful fallback. |
| Scan setup | Large phone-stand instruction card, distance, rear-camera, lighting guidance, and readiness CTA. |
| Calibration | Quality ring with checks for framing, camera stability, lighting, background, and pose availability. |
| Guided scan | Capture boundary, multi-angle progress, pose guidance, stage label, and cancel/retry affordances. |
| Processing | Transparent processing stages: validating, reconstructing, measuring, and generating insights. |
| Scan quality | Quality score, confidence labels, captured-view summary, and retry or continue actions. |
| 3D result | Privacy-preserving body representation mock, scan date, quality status, and “estimated” labeling. |
| Measurement results | Measurement cards with values, units, confidence, and explanations of what is measured versus estimated. |
| Home dashboard | Greeting, latest scan, quality, movement consistency, progress trend, AI insight, and Start a new scan. |
| Progress | Timeline of scans, trend cards, consistency summary, and labeled demo data when applicable. |
| Movement | Movement assessment cards for mobility, balance, control, and stability with non-medical language. |
| AI insights | Actionable, encouraging insights generated from mock structured data, with confidence and privacy status. |
| Historical scans | Chronological scan list with date, quality, and status; opens scan detail. |
| Profile | Name, age range, height/unit preferences, interests, and baseline status. |
| Settings | Notifications, theme, scan reminders, and account/session controls. |
| Privacy controls | Processing preference, retention, delete scan data, export explanation, and privacy details. |
| Subscription | Clear plan comparison and feature framing without blocking the demo journey. |

## Navigation and key flows

The root experience uses a lightweight onboarding stack followed by a four-tab shell: Home, Progress, Movement, and Profile. The primary scan CTA is available from Home and can be reached from empty states. Supporting screens use stack navigation and preserve a visible back affordance.

### First-run flow

1. Splash transitions to Welcome.
2. Get Started opens Privacy intro.
3. Continue opens Goals, where the user chooses one or more interests.
4. Baseline setup collects only the minimum profile inputs and supports Skip where possible.
5. The user lands on Home with a helpful empty state and Create Baseline Scan CTA.

### Demo flow

1. The user taps Explore Demo from Welcome or View Demo from the empty state.
2. The app opens a labeled demo dashboard with realistic mock scan data.
3. Tapping the latest scan opens 3D result and measurement cards.
4. Tapping Progress, Movement, or AI insight opens the corresponding demo sections.
5. The UI consistently shows “Demo data” so mock results are never mistaken for personal measurements.

### Scan flow

1. Home → Start a new scan → Camera permission.
2. Allow Camera opens Scan setup; denied permission opens an explanatory fallback with Try Again and Explore Demo.
3. I’m ready opens Calibration.
4. Calibration reaches a passing state, then Guided scan cycles through front, side, and back views.
5. Processing shows structured stages with progress and no blank waiting screen.
6. Scan quality presents score and confidence; Continue opens 3D result.
7. Measurement results lead to Home, where the new scan is reflected in latest scan and progress cards.

## Visual system

| Token | Choice |
|---|---|
| Background | `#F7F8FA`, a cool near-white foundation that keeps the app light and calm. |
| Surface | `#FFFFFF`, used for cards, sheets, and elevated controls. |
| Foreground | `#101114`, for high-contrast headings and key values. |
| Muted | `#6B7280`, for supporting copy and metadata. |
| Border | `#E6E8EC`, for quiet dividers and card outlines. |
| Accent | `#5B5CE2`, an indigo-violet scan signal used for primary CTAs, progress rings, and active navigation. |
| Accent soft | `#ECECFF`, for tinted surfaces and scan-state backgrounds. |
| Success | `#22A06B`, for quality checks and positive progress. |
| Warning | `#D98A00`, for low-confidence or incomplete states. |
| Danger | `#D64545`, reserved for destructive privacy actions. |

Use 10, 16, 24, and 32 point radii for increasing hierarchy. Use system typography with 36–44 point display text, 28–32 point headlines, 20–24 point titles, 16–18 point body text, and 11–15 point metadata. Numeric results are prominent but never presented with false precision.

## Interaction and accessibility

Primary buttons use a full-width 54–56 point touch target near the lower portion of the screen for thumb reach. Secondary actions use quiet text or outline treatments. Cards provide opacity feedback on press, while primary actions use subtle scale feedback and light haptics. All scan states include clear status text in addition to color. Dynamic type, sufficient contrast, reduced-motion respect, and screen-reader labels are part of the implementation baseline.

## Privacy language

The experience uses direct language: camera data is used only when a scan starts; results are estimates or unavailable when confidence is insufficient; personal body imagery is sensitive; and the user can delete scan data from Privacy controls. No screen uses appearance ranking, dieting prompts, ideal-body comparisons, or clinical claims.
