import QRCode from "qrcode";

const url = "https://fitscanai-mhhdbubv.manus.space";
const output = "./assets/hosted-app-qr.png";

await QRCode.toFile(output, url, {
  width: 1200,
  margin: 4,
  errorCorrectionLevel: "H",
  color: { dark: "#111111", light: "#FFFFFF" },
});

console.log(`Wrote ${output} for ${url}`);
