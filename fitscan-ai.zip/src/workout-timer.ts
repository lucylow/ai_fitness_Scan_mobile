export type WorkoutTimerPhase = "work" | "rest" | "complete";

export interface WorkoutTimerInput {
  phase: WorkoutTimerPhase;
  seconds: number;
  exerciseIndex: number;
  totalExercises: number;
  restSeconds: number;
}

export interface WorkoutTimerTransition {
  phase: WorkoutTimerPhase;
  seconds: number;
  exerciseIndex: number;
  advancedExercise: boolean;
  completed: boolean;
}

export function shouldPauseWorkoutForAppState(nextAppState: string): boolean {
  return nextAppState !== "active";
}

export function shouldPersistWorkoutRecovery(isMounted: boolean, phase: WorkoutTimerPhase): boolean {
  return isMounted && phase !== "complete";
}

export function shouldCommitWorkoutCompletion(isMounted: boolean, phase: WorkoutTimerPhase, alreadyCommitted: boolean): boolean {
  return isMounted && phase === "complete" && !alreadyCommitted;
}

export function advanceWorkoutTimer(input: WorkoutTimerInput): WorkoutTimerTransition {
  const totalExercises = Math.max(1, Math.floor(input.totalExercises));
  const exerciseIndex = Math.max(0, Math.min(totalExercises - 1, Math.floor(input.exerciseIndex)));
  const seconds = Math.max(0, Math.floor(input.seconds));
  const restSeconds = Math.max(1, Math.floor(input.restSeconds));

  if (input.phase === "complete") {
    return { phase: "complete", seconds: 0, exerciseIndex, advancedExercise: false, completed: true };
  }

  if (seconds > 1) {
    return { phase: input.phase, seconds: seconds - 1, exerciseIndex, advancedExercise: false, completed: false };
  }

  if (input.phase === "work") {
    return { phase: "rest", seconds: restSeconds, exerciseIndex, advancedExercise: false, completed: false };
  }

  if (exerciseIndex < totalExercises - 1) {
    return { phase: "work", seconds: 30, exerciseIndex: exerciseIndex + 1, advancedExercise: true, completed: false };
  }

  return { phase: "complete", seconds: 0, exerciseIndex, advancedExercise: false, completed: true };
}
