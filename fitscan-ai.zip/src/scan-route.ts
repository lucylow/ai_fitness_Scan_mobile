export type ScanRouteStage = "idle" | "permission" | "setup" | "capture" | "processing" | "result";

export interface ScanStageTransition {
  stage: ScanRouteStage;
  view: number;
}

/**
 * Advance the guided scan by one user action. The helper is deliberately pure so
 * route behavior can be verified without camera permissions or native modules.
 */
export function advanceScanStage(stage: ScanRouteStage, view: number): ScanStageTransition {
  const safeView = Math.max(0, Math.min(2, Math.trunc(view)));

  if (stage === "permission") return { stage: "setup", view: safeView };
  if (stage === "setup") return { stage: "capture", view: safeView };
  if (stage === "capture" && safeView < 2) return { stage: "capture", view: safeView + 1 };
  if (stage === "capture") return { stage: "processing", view: 3 };

  return { stage, view: safeView };
}

export function scanCaptureLabel(view: number): "front" | "side" | "back" {
  return ["front", "side", "back"][Math.max(0, Math.min(2, Math.trunc(view)))] as "front" | "side" | "back";
}

export function cancelScan(stage: ScanRouteStage, view: number): ScanStageTransition {
  if (stage === "idle" || stage === "result") return { stage, view: Math.max(0, Math.min(2, Math.trunc(view))) };
  return { stage: "idle", view: 0 };
}

export interface ScanCancellationUndo {
  id: string;
  stage: Extract<ScanRouteStage, "permission" | "setup" | "capture">;
  view: number;
  expiresAt: number;
}

export function canUndoScanCancellation(undo: ScanCancellationUndo | undefined, now: number): boolean {
  return Boolean(undo && Number.isFinite(now) && now < undo.expiresAt);
}

export function restoreScanCancellation(undo: ScanCancellationUndo | undefined, now: number): ScanStageTransition | undefined {
  if (!canUndoScanCancellation(undo, now) || !undo) return undefined;
  return { stage: undo.stage, view: Math.max(0, Math.min(2, Math.trunc(undo.view))) };
}
