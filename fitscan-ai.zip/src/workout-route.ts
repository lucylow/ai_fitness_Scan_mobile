export const workoutTemplates = ["Full body", "Mobility", "Lower body", "Recovery"] as const;
export type WorkoutTemplate = (typeof workoutTemplates)[number];

export function normalizeWorkoutTemplate(value: unknown): WorkoutTemplate | undefined {
  const candidate = Array.isArray(value) ? value[0] : value;
  return typeof candidate === "string" && workoutTemplates.includes(candidate as WorkoutTemplate) ? candidate as WorkoutTemplate : undefined;
}

export function workoutLaunchTitle(template: WorkoutTemplate | undefined) {
  return template ? `${template} session` : "Quick reset";
}
