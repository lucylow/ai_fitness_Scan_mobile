import type { SupportedLanguage } from "./i18n";
import { formatNumber, translate } from "./i18n";
import type { ExercisePrescription } from "./workout-prescription";
import { localizedPrescriptionSummary } from "./workout-prescription";

export function localizedWorkoutTimerAccessibilityLabel(language: SupportedLanguage, exerciseName: string, phase: "work" | "rest", seconds: number): string {
  const phaseLabel = translate(language, phase === "work" ? "workout.phase.work" : "workout.phase.rest");
  return translate(language, "workout.accessibility.timer", "{exercise}, {phase}, {seconds} seconds remaining", { exercise: exerciseName, phase: phaseLabel, seconds: formatNumber(seconds, language) });
}

export function localizedWorkoutPrescriptionAccessibilityLabel(language: SupportedLanguage, prescription: ExercisePrescription): string {
  return translate(language, "workout.accessibility.prescription", "Prescription: {summary}", { summary: localizedPrescriptionSummary(language, prescription) });
}
