export const ONBOARDING_STEP_COUNT = 3;

export function onboardingProgress(step: number, stepCount = ONBOARDING_STEP_COUNT) {
  const safeStepCount = Math.max(1, stepCount);
  const safeStep = Math.max(0, Math.min(safeStepCount - 1, step));
  return (safeStep + 1) / safeStepCount;
}

export function toggleOnboardingGoal(selected: string[], goal: string) {
  return selected.includes(goal) ? selected.filter((item) => item !== goal) : [...selected, goal];
}

export function normalizeOnboardingName(name: string, fallback = "Alex") {
  const trimmed = name.trim();
  return trimmed || fallback;
}
