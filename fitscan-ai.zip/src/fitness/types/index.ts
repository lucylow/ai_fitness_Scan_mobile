export type FitnessInterest = "strength" | "mobility" | "cardio" | "conditioning" | "balance" | "general_fitness";
export type FitnessGoalType = "consistency" | "strength" | "mobility" | "endurance" | "movement_quality" | "habit";
export type Equipment = "none" | "mat" | "dumbbells" | "barbell" | "bench" | "resistance_band" | "kettlebell" | "pullup_bar" | "cable" | "machine" | "bike" | "treadmill" | "rower";
export type MovementPattern = "squat" | "hinge" | "push" | "pull" | "carry" | "rotation" | "locomotion" | "balance" | "mobility";
export type Difficulty = "beginner" | "intermediate" | "advanced";
export interface FitnessPreferences { units: "metric" | "imperial"; reminders: boolean; cameraFeedback: boolean; }
export interface FitnessGoal { id: string; type: FitnessGoalType; title: string; targetValue?: number; currentValue?: number; unit?: string; startDate: number; targetDate?: number; completed: boolean; }
export interface FitnessProfile { userId: string; experience: Difficulty; interests: FitnessInterest[]; availableDays: number[]; sessionDurationMinutes: number; preferredTrainingLocation: "home" | "gym" | "outdoor" | "mixed"; equipment: Equipment[]; goals: FitnessGoal[]; preferences: FitnessPreferences; }
export interface Exercise { id: string; name: string; category: FitnessInterest; primaryMuscles: string[]; secondaryMuscles: string[]; equipment: Equipment[]; difficulty: Difficulty; instructions: string[]; safetyNotes: string[]; movementPattern: MovementPattern; }
export interface WorkoutExercise { id: string; exerciseId: string; order: number; sets: number; reps?: number; durationSeconds?: number; restSeconds: number; targetRPE?: number; notes?: string; }
export interface Workout { id: string; name: string; durationMinutes: number; difficulty: Difficulty; exercises: WorkoutExercise[]; targetCategories: FitnessInterest[]; estimatedCalories?: number; completed: boolean; }
export type WorkoutSessionState = "idle" | "preparing" | "active" | "paused" | "resting" | "completed" | "cancelled";
export type TimerPhase = "work" | "rest" | "complete";
export interface RepQuality { depth: number; tempo: number; stability: number; consistency: number; confidence: number; }
export interface RepCounter { current: number; target?: number; qualityScore?: number; }
