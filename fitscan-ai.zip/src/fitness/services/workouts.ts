import type { Equipment, Exercise, FitnessInterest, FitnessProfile, MovementPattern, Workout } from "../types";

export const exerciseCatalog: Exercise[] = [
  { id: "air-squat", name: "Air squat", category: "strength", primaryMuscles: ["legs", "glutes"], secondaryMuscles: ["core"], equipment: ["none"], difficulty: "beginner", movementPattern: "squat", instructions: ["Stand with feet comfortable apart.", "Lower with control, then stand tall."], safetyNotes: ["Use a range that feels controlled."] },
  { id: "incline-push-up", name: "Incline push-up", category: "strength", primaryMuscles: ["chest", "arms"], secondaryMuscles: ["core"], equipment: ["bench"], difficulty: "beginner", movementPattern: "push", instructions: ["Place hands on a stable elevated surface.", "Lower your chest with a steady tempo."] , safetyNotes: ["Use a stable surface and stop if discomfort appears."] },
  { id: "dead-bug", name: "Dead bug", category: "mobility", primaryMuscles: ["core"], secondaryMuscles: ["hips"], equipment: ["mat"], difficulty: "beginner", movementPattern: "mobility", instructions: ["Lie on your back with arms up.", "Extend opposite arm and leg slowly."] , safetyNotes: ["Keep the movement small enough to maintain control."] },
  { id: "reverse-lunge", name: "Reverse lunge", category: "strength", primaryMuscles: ["legs", "glutes"], secondaryMuscles: ["balance"], equipment: ["none"], difficulty: "beginner", movementPattern: "locomotion", instructions: ["Step one foot back.", "Lower evenly, then return to standing."] , safetyNotes: ["Hold a support if balance is limited."] },
  { id: "march-in-place", name: "March in place", category: "cardio", primaryMuscles: ["legs"], secondaryMuscles: ["core"], equipment: ["none"], difficulty: "beginner", movementPattern: "locomotion", instructions: ["Stand tall and alternate lifting your knees.", "Keep a comfortable rhythm."] , safetyNotes: ["Choose a pace that lets you speak comfortably."] },
];

const id = () => `workout_${Date.now().toString(36)}`;
export function filterAvailableExercises(equipment: Equipment[], interests: FitnessInterest[]): Exercise[] {
  return exerciseCatalog.filter((exercise) => interests.includes(exercise.category) && exercise.equipment.every((item) => item === "none" || item === "mat" || equipment.includes(item)));
}
export function validateWorkout(workout: Workout): true {
  if (workout.exercises.length === 0) throw new Error("Workout contains no exercises");
  if (workout.durationMinutes <= 0) throw new Error("Invalid duration");
  return true;
}
export function generateQuickWorkout(profile: Pick<FitnessProfile, "experience" | "equipment" | "interests" | "sessionDurationMinutes">, durationMinutes = profile.sessionDurationMinutes): Workout {
  const requested: FitnessInterest[] = profile.interests.length ? profile.interests : ["general_fitness"];
  const interests: FitnessInterest[] = requested.includes("general_fitness") ? ["strength", "mobility", "cardio"] : requested;
  const available = filterAvailableExercises(profile.equipment, interests);
  const fallback = exerciseCatalog.filter((exercise) => exercise.equipment.includes("none"));
  const chosen = (available.length ? available : fallback).slice(0, 4);
  const workout: Workout = { id: id(), name: durationMinutes <= 10 ? "Quick reset" : "Balanced foundation", durationMinutes, difficulty: profile.experience, targetCategories: interests, estimatedCalories: durationMinutes * 6, completed: false, exercises: chosen.map((exercise, index) => ({ id: `${id()}_${index}`, exerciseId: exercise.id, order: index, sets: 2, reps: exercise.category === "cardio" ? undefined : 8, durationSeconds: exercise.category === "cardio" ? 45 : undefined, restSeconds: 30, targetRPE: 6 })) };
  validateWorkout(workout);
  return workout;
}

export function calculateRepQuality(rep: { depth: number; tempo: number; stability: number; consistency: number; confidence: number }): number {
  return Math.round((rep.depth * 0.25 + rep.tempo * 0.2 + rep.stability * 0.25 + rep.consistency * 0.2 + rep.confidence * 0.1) * 100);
}

export class WorkoutTimer {
  private startedAt?: number;
  private elapsedMs = 0;
  start() { this.startedAt = Date.now(); }
  pause() { if (this.startedAt) { this.elapsedMs += Date.now() - this.startedAt; this.startedAt = undefined; } }
  elapsed() { return this.elapsedMs + (this.startedAt ? Date.now() - this.startedAt : 0); }
}

export type { MovementPattern };
