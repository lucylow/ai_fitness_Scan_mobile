import type { StoredScan, StoredWorkout } from "./state/app-state";
import { actionSignals, type PersonalizationSignalRecord } from "./personalization-v7";
import type { UserAction } from "./personalization";

export function persistedScanSignals(userId: string, scans: StoredScan[]): PersonalizationSignalRecord[] {
  return scans.map((scan) => ({
    id: `scan:${scan.id}`,
    userId,
    type: "scan",
    feature: "scan_completed",
    value: scan.status === "complete" ? Math.max(0, Math.min(1, scan.quality / 100)) : 0,
    confidence: scan.status === "complete" ? 0.9 : 0.4,
    timestamp: scan.createdAt,
    metadata: { quality: scan.quality, status: scan.status, label: scan.label },
  }));
}

export function persistedWorkoutSignals(userId: string, workouts: StoredWorkout[]): PersonalizationSignalRecord[] {
  const actions: UserAction[] = workouts.flatMap((workout) => [
    { id: `workout:start:${workout.id}`, userId, type: "workout_started" as const, targetId: workout.label, timestamp: workout.completedAt - workout.durationMinutes * 60000, metadata: { durationMinutes: workout.durationMinutes } },
    { id: `workout:complete:${workout.id}`, userId, type: "workout_completed" as const, targetId: workout.label, timestamp: workout.completedAt, metadata: { durationMinutes: workout.durationMinutes } },
  ]);
  const signals = actionSignals(userId, actions);
  for (const workout of workouts) {
    if (typeof workout.effort !== "number") continue;
    const effort = Math.max(1, Math.min(10, workout.effort));
    signals.push({ id: `workout:effort:${workout.id}`, userId, type: "feedback", feature: "workout_effort", value: effort / 10, confidence: 0.95, timestamp: workout.completedAt, metadata: { effort, durationMinutes: workout.durationMinutes } });
  }
  return signals;
}

export interface EffortTrend { average: number; latest?: number; direction: "increasing" | "decreasing" | "steady"; count: number; }
export type EffortRangeDays = 7 | 30 | 365;
export function workoutsInEffortRange(workouts: StoredWorkout[], rangeDays: EffortRangeDays, now: number): StoredWorkout[] { const cutoff = now - rangeDays * 24 * 60 * 60 * 1000; return workouts.filter((workout) => workout.completedAt >= cutoff); }
export function recentEffortSeries(workouts: StoredWorkout[], limit = 5): number[] { return workouts.filter((workout) => typeof workout.effort === "number").slice(0, Math.max(1, limit)).map((workout) => Math.max(1, Math.min(10, workout.effort as number))).reverse(); }
export function effortAccessibilityLabels(values: number[]): string[] { return values.map((value, index) => `Workout ${index + 1}: effort ${value} out of 10`); }
export function summarizeEffort(workouts: StoredWorkout[]): EffortTrend {
  const values = workouts.filter((workout) => typeof workout.effort === "number").map((workout) => Math.max(1, Math.min(10, workout.effort as number)));
  if (!values.length) return { average: 0, direction: "steady", count: 0 };
  const average = values.reduce((sum, value) => sum + value, 0) / values.length;
  const latest = values[0];
  const previous = values[1];
  const delta = previous === undefined ? 0 : latest - previous;
  return { average: Math.round(average * 10) / 10, latest, direction: delta > 0.5 ? "increasing" : delta < -0.5 ? "decreasing" : "steady", count: values.length };
}

export function persistedHistorySignals(userId: string, scans: StoredScan[], workouts: StoredWorkout[]): PersonalizationSignalRecord[] {
  return [...persistedScanSignals(userId, scans), ...persistedWorkoutSignals(userId, workouts)].sort((a, b) => b.timestamp - a.timestamp);
}
