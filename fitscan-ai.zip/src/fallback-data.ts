import type { PersistenceStatus, StoredScan, StoredWorkout } from "@/src/state/app-state";

export const FALLBACK_SCAN: StoredScan = {
  id: "fallback_scan",
  createdAt: Date.UTC(2026, 7, 21),
  quality: 94,
  status: "complete",
  label: "Sample baseline",
};

export const FALLBACK_WORKOUT: StoredWorkout = {
  id: "fallback_workout",
  completedAt: Date.UTC(2026, 7, 20),
  durationMinutes: 20,
  label: "Sample full-body session",
  effort: 6,
};

export function shouldUseFallbackData(status: PersistenceStatus, hasLocalData: boolean): boolean {
  return status === "recovered" && !hasLocalData;
}

export function displayScanHistory(scans: StoredScan[], status: PersistenceStatus): StoredScan[] {
  return scans.length || !shouldUseFallbackData(status, false) ? scans : [FALLBACK_SCAN];
}

export function displayWorkoutHistory(workouts: StoredWorkout[], status: PersistenceStatus): StoredWorkout[] {
  return workouts.length || !shouldUseFallbackData(status, false) ? workouts : [FALLBACK_WORKOUT];
}
