import type { ExerciseDefinition } from "@/src/workouts/v6";

export const localExerciseCatalog: ExerciseDefinition[] = [
  { id: "air-squat", name: "Air squats", category: "strength", movementPattern: "squat", equipment: ["none"], difficulty: "beginner", defaultReps: 10, defaultSets: 3, defaultRestSeconds: 20, instructions: ["Move at a steady tempo."] },
  { id: "wall-pushup", name: "Wall push-ups", category: "strength", movementPattern: "push", equipment: ["none"], difficulty: "beginner", defaultReps: 8, defaultSets: 2, defaultRestSeconds: 20, instructions: ["Keep your body long and comfortable."] },
  { id: "dead-bug", name: "Dead bug", category: "mobility", movementPattern: "core", equipment: ["mat"], difficulty: "intermediate", defaultReps: 8, defaultSets: 3, defaultRestSeconds: 25, instructions: ["Move slowly while keeping your ribs relaxed."] },
  { id: "reverse-lunge", name: "Reverse lunges", category: "strength", movementPattern: "lunge", equipment: ["none"], difficulty: "intermediate", defaultReps: 8, defaultSets: 3, defaultRestSeconds: 30, instructions: ["Step back softly and keep the front knee steady."] },
  { id: "pushup", name: "Push-ups", category: "strength", movementPattern: "push", equipment: ["none"], difficulty: "advanced", defaultReps: 10, defaultSets: 4, defaultRestSeconds: 35, instructions: ["Keep a straight line and stop before form breaks down."] },
  { id: "split-squat", name: "Split squats", category: "strength", movementPattern: "lunge", equipment: ["none"], difficulty: "advanced", defaultReps: 10, defaultSets: 3, defaultRestSeconds: 35, instructions: ["Lower with control and drive evenly through the front foot."] },
];
