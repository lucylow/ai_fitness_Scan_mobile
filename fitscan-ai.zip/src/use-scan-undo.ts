import { useCallback, useEffect } from "react";

import type { ScanCancellationUndo } from "@/src/scan-route";

type SetUndoCancellation = (value: ScanCancellationUndo | undefined) => void;
type SetDiscardNotice = (value: boolean) => void;

export function scanUndoRemainingMs(expiresAt: number, now: number) {
  if (!Number.isFinite(expiresAt) || !Number.isFinite(now)) return 0;
  return Math.max(0, expiresAt - now);
}

export function useScanUndoLifecycle(
  undoCancellation: ScanCancellationUndo | undefined,
  setUndoCancellation: SetUndoCancellation,
  setDiscardNotice: SetDiscardNotice,
) {
  const clearScanUndo = useCallback(() => {
    setUndoCancellation(undefined);
    setDiscardNotice(false);
  }, [setDiscardNotice, setUndoCancellation]);

  useEffect(() => {
    if (!undoCancellation) return;
    const remaining = scanUndoRemainingMs(undoCancellation.expiresAt, Date.now());
    const timer = setTimeout(clearScanUndo, remaining);
    return () => clearTimeout(timer);
  }, [clearScanUndo, undoCancellation]);

  return { clearScanUndo };
}
