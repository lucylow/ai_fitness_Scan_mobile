export const supportedLanguageCodes = ["en", "fr", "es", "pt", "ar", "wo", "de", "it", "ja", "ko"] as const;
export type DetectedLanguage = (typeof supportedLanguageCodes)[number];

export function normalizeLanguage(value: unknown): DetectedLanguage {
  const raw = Array.isArray(value) ? value[0] : value;
  const base = typeof raw === "string" ? raw.toLowerCase().split(/[-_]/)[0] : "";
  return (supportedLanguageCodes as readonly string[]).includes(base) ? base as DetectedLanguage : "en";
}

export function detectDeviceLanguage(readLocale: () => string | undefined = () => {
  try {
    return Intl.DateTimeFormat().resolvedOptions().locale;
  } catch {
    return undefined;
  }
}): DetectedLanguage {
  try {
    return normalizeLanguage(readLocale());
  } catch {
    return "en";
  }
}

export function shouldRefreshDeviceLanguage(hasUserPreference: boolean, current: DetectedLanguage, detected: DetectedLanguage): boolean {
  return !hasUserPreference && current !== detected;
}
