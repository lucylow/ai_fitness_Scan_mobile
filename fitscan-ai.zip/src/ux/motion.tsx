import { ReactNode, useEffect } from "react";
import Animated, { useAnimatedStyle, useSharedValue, withSpring, withTiming } from "react-native-reanimated";

export function usePressScale() { const scale = useSharedValue(1); const pressIn = () => { scale.value = withTiming(0.97, { duration: 90 }); }; const pressOut = () => { scale.value = withTiming(1, { duration: 130 }); }; const animatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] })); return { pressIn, pressOut, animatedStyle }; }
export function FadeIn({ children, delay = 0 }: { children: ReactNode; delay?: number }) { const opacity = useSharedValue(0); useEffect(() => { const timer = setTimeout(() => { opacity.value = withTiming(1, { duration: 300 }); }, delay); return () => clearTimeout(timer); }, [delay, opacity]); return <Animated.View style={useAnimatedStyle(() => ({ opacity: opacity.value }))}>{children}</Animated.View>; }
export function SlideUp({ children }: { children: ReactNode }) { const y = useSharedValue(18); useEffect(() => { y.value = withSpring(0, { damping: 18, stiffness: 160 }); }, [y]); return <Animated.View style={useAnimatedStyle(() => ({ transform: [{ translateY: y.value }] }))}>{children}</Animated.View>; }
export function Stagger({ children }: { children: ReactNode[] }) { return <>{children.map((child, index) => <FadeIn key={index} delay={index * 70}>{child}</FadeIn>)}</>; }
