import type { SupportedLanguage } from "./i18n";
import { translate } from "./i18n";
import type { WorkoutPlanSummary, WorkoutType } from "./workouts/v6";
import type { WorkoutTemplate } from "./workout-route";

const templateKeys: Record<WorkoutTemplate, string> = {
  "Full body": "workout.template.fullBody",
  Mobility: "workout.template.mobility",
  "Lower body": "workout.template.lowerBody",
  Recovery: "workout.template.recovery",
};

const typeKeys: Record<WorkoutType, string> = {
  strength: "workout.type.strength",
  mobility: "workout.type.mobility",
  conditioning: "workout.type.conditioning",
  mixed: "workout.type.mixed",
  recovery: "workout.type.recovery",
  skill: "workout.type.skill",
};

export function localizedWorkoutLaunchTitle(language: SupportedLanguage, template?: WorkoutTemplate): string {
  const templateName = template ? translate(language, templateKeys[template], template) : translate(language, "workout.template.quickReset", "Quick reset");
  return translate(language, "workout.template.sessionTitle", "{template} session", { template: templateName });
}

export function localizedWorkoutPlanTitle(language: SupportedLanguage, plan: WorkoutPlanSummary): string {
  const typeName = translate(language, typeKeys[plan.type], plan.type);
  return translate(language, "workout.planTitle", "{type} {minutes}-minute session", { type: typeName, minutes: plan.durationMinutes });
}

export function localizedWorkoutPlanRationale(language: SupportedLanguage, plan: WorkoutPlanSummary): string {
  return translate(
    language,
    plan.exerciseIds.length ? "workout.rationale.selected" : "workout.rationale.empty",
    plan.rationale,
    { minutes: plan.durationMinutes },
  );
}
