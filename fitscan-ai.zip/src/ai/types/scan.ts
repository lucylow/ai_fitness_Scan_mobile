import type { ConfidenceScore } from "./core";

export interface PoseLandmark { name: string; x: number; y: number; z?: number; confidence: number; }
export interface ScanFrameAI { id: string; timestamp: number; angle: number; imageUri?: string; landmarks: PoseLandmark[]; bodyVisibility: number; blurScore: number; lightingScore: number; poseConfidence: number; }
export interface ScanAIInput { frames: ScanFrameAI[]; heightCm?: number; cameraModel?: string; deviceOrientation?: string; }
export interface ScanRegionEstimate { region: string; value?: number; unit: "cm" | "in"; confidence: ConfidenceScore; }
export interface ScanAIOutput { completeness: number; consistency: number; landmarks: PoseLandmark[]; measurements: ScanRegionEstimate[]; warnings: string[]; modelVersion: string; }
