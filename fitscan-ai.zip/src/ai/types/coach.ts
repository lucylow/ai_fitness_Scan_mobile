import type { ConfidenceScore } from "./core";
import type { PoseLandmark } from "./scan";

export type MovementName = "squat" | "lunge" | "overhead_reach" | "single_leg_balance" | "shoulder_rotation";
export interface MovementFrame { timestamp: number; landmarks: PoseLandmark[]; }
export interface MovementRep { index: number; startMs: number; endMs: number; durationMs: number; rangeScore: number; stabilityScore: number; symmetryScore?: number; }
export interface MovementAnalysis { movement: MovementName; repetitions: MovementRep[]; tempoConsistency: number; stability: number; rangeOfMotion: number; symmetry?: number; confidence: ConfidenceScore; observations: string[]; }
export type EvidenceType = "scan" | "movement" | "habit" | "goal" | "profile";
export interface EvidenceItem { type: EvidenceType; id?: string; description: string; }
export interface CoachMessage { id: string; role: "user" | "assistant" | "system"; text: string; createdAt: number; evidence?: EvidenceItem[]; }
export interface CoachRequest { message: string; conversation: CoachMessage[]; latestScan?: unknown; previousScans?: unknown[]; movementResults?: unknown[]; goals?: unknown[]; habits?: unknown[]; }
export interface CoachResponse { answer: string; evidence: EvidenceItem[]; confidence: ConfidenceScore; suggestedActions: string[]; safetyFlags: string[]; }
