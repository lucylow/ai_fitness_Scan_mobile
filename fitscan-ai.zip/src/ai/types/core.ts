export type AIProviderName = "mock" | "openai" | "anthropic" | "gemini" | "custom";
export type AIProcessingMode = "local" | "remote" | "hybrid";
export type ConfidenceLevel = "high" | "moderate" | "low" | "unavailable";

export interface ConfidenceScore { value: number; level: ConfidenceLevel; reasons: string[]; }
export interface AIContext { userId?: string; scanId?: string; sessionId: string; timestamp: number; provider: AIProviderName; mode: AIProcessingMode; }
export interface AIRequest<T> { context: AIContext; input: T; }
export interface AIResponse<T> { output: T; confidence?: ConfidenceScore; latencyMs: number; provider: AIProviderName; requestId: string; }
export interface AIErrorShape { code: string; message: string; retryable: boolean; requestId?: string; }
