import type { AIProviderName } from "./types/core";

export interface AIFeatures { mockAI: boolean; scanVision: boolean; movementVision: boolean; coach: boolean; personalization: boolean; retrieval: boolean; safetyLayer: boolean; cloudInference: boolean; }
export const aiFeatures: AIFeatures = { mockAI: true, scanVision: false, movementVision: false, coach: true, personalization: true, retrieval: false, safetyLayer: true, cloudInference: false };
export interface AIConfig { provider: AIProviderName; apiBaseUrl?: string; timeoutMs: number; maxRetries: number; temperature: number; maxOutputTokens: number; }
export const aiConfig: AIConfig = { provider: "mock", timeoutMs: 30_000, maxRetries: 2, temperature: 0.2, maxOutputTokens: 1_500 };
export const createRequestId = (prefix = "ai") => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
export class AIServiceError extends Error { constructor(message: string, public readonly code: string, public readonly retryable = false, public readonly requestId?: string) { super(message); this.name = "AIServiceError"; } }
export async function withRetry<T>(operation: () => Promise<T>, attempts = 3): Promise<T> { let lastError: unknown; for (let index = 0; index < attempts; index += 1) { try { return await operation(); } catch (error) { lastError = error; if (index < attempts - 1) await new Promise((resolve) => setTimeout(resolve, 100 * 2 ** index)); } } throw lastError; }
export function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> { return Promise.race([promise, new Promise<T>((_, reject) => setTimeout(() => reject(new AIServiceError(`AI request exceeded ${timeoutMs}ms`, "TIMEOUT", true)), timeoutMs))]); }
