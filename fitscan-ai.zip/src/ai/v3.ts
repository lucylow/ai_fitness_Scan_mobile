export type AgentType = "vision" | "pose" | "scan" | "measurement" | "movement" | "workout" | "progress" | "recommendation" | "coach" | "safety" | "personalization";
export type AIConfidenceLevel = "very-low" | "low" | "moderate" | "high" | "very-high";
export type AITaskPriority = "background" | "normal" | "high" | "critical";
export interface Evidence { source: string; value: unknown; confidence: number; }
export interface AgentContext { userId?: string; sessionId: string; timestamp: number; data: Record<string, unknown>; }
export interface AgentResult<T = unknown> { agent: AgentType; output: T; confidence: number; evidence: Evidence[]; latencyMs: number; }
export interface AITask<T = unknown> { id: string; agent: AgentType; priority: AITaskPriority; input: T; createdAt: number; deadlineMs?: number; }
export interface AIModel<I, O> { id: string; version: string; supports(input: I): boolean; predict(input: I): Promise<O>; }
export function createTask<T>(agent: AgentType, input: T, priority: AITaskPriority = "normal", now = Date.now()): AITask<T> { return { id: `ai_task_${now}`, agent, priority, input, createdAt: now }; }
export function validateConfidence(confidence: number) { return Number.isFinite(confidence) && confidence >= 0 && confidence <= 1; }
export function validateAgentResult(result: AgentResult) { if (!validateConfidence(result.confidence)) throw new Error("Invalid AI confidence"); if (!result.agent) throw new Error("Missing AI agent"); return true; }
export function calibrateConfidence(raw: number, sampleCount: number, evidenceStrength: number) { const sampleFactor = Math.min(1, Math.max(0, sampleCount) / 10); return Math.max(0, Math.min(1, raw * 0.5 + sampleFactor * 0.2 + Math.max(0, Math.min(1, evidenceStrength)) * 0.3)); }
export function confidenceLevel(value: number): AIConfidenceLevel { if (value < .2) return "very-low"; if (value < .4) return "low"; if (value < .65) return "moderate"; if (value < .85) return "high"; return "very-high"; }
export class ModelRegistry { private models = new Map<string, AIModel<unknown, unknown>>(); register<I, O>(model: AIModel<I, O>) { this.models.set(model.id, model as AIModel<unknown, unknown>); } get(id: string) { return this.models.get(id); } findForInput(input: unknown) { return [...this.models.values()].filter((model) => model.supports(input)); } }
export class ModelRouter { constructor(private registry: ModelRegistry) {} route(input: unknown) { const model = this.registry.findForInput(input)[0]; if (!model) throw new Error("No AI model available"); return model; } }
export class FallbackChain { constructor(private models: AIModel<unknown, unknown>[]) {} async predict(input: unknown) { let lastError: unknown; for (const model of this.models) { try { if (model.supports(input)) return await model.predict(input); } catch (error) { lastError = error; } } throw lastError ?? new Error("All AI models failed"); } }
export interface VisionFeatures { bodyDetected: boolean; bodyConfidence: number; silhouetteConfidence: number; lightingScore: number; framingScore: number; blurScore: number; poseConfidence: number; }
export function calculateVisionQuality(features: VisionFeatures) { return features.bodyConfidence * .25 + features.silhouetteConfidence * .2 + features.lightingScore * .15 + features.framingScore * .15 + features.blurScore * .1 + features.poseConfidence * .15; }
export function adaptiveCameraGuidance(features: VisionFeatures) { if (features.bodyConfidence < .5) return "Step into the camera view."; if (features.framingScore < .6) return "Adjust the phone so your full body is visible."; if (features.lightingScore < .6) return "Move to a brighter area."; if (features.blurScore < .55) return "Move more slowly."; return "Camera setup looks good."; }
export function shouldAllowAction(confidence: number, threshold = .75) { return validateConfidence(confidence) && confidence >= threshold; }
export function safetyGate(confidence: number, message: string) { return shouldAllowAction(confidence) ? { allowed: true, message } : { allowed: false, message: "This insight is not confident enough to act on yet. Try another scan or use a general workout." }; }
