import type { AIRequest, AIResponse } from "./types/core";
import type { ScanAIInput, ScanAIOutput } from "./types/scan";
import type { CoachRequest, CoachResponse, MovementAnalysis } from "./types/coach";

export interface AIProvider {
  readonly name: string;
  analyzeScan(request: AIRequest<ScanAIInput>): Promise<AIResponse<ScanAIOutput>>;
  analyzeMovement(request: AIRequest<{ movement: "squat"; frames: unknown[] }>): Promise<AIResponse<MovementAnalysis>>;
  generateCoachResponse(request: AIRequest<CoachRequest>): Promise<AIResponse<CoachResponse>>;
}

const confidence = { value: 0.94, level: "high" as const, reasons: ["Clear framing", "Consistent lighting", "Three guided views"] };
export class MockAIProvider implements AIProvider {
  readonly name = "mock" as const;
  async analyzeScan(request: AIRequest<ScanAIInput>): Promise<AIResponse<ScanAIOutput>> {
    return { provider: "mock", requestId: `mock_scan_${request.context.sessionId}`, latencyMs: 120, confidence, output: { completeness: 0.96, consistency: 0.91, landmarks: [], warnings: ["Results are estimates for fitness tracking, not clinical measurements."], modelVersion: "mock-1.0", measurements: [{ region: "Shoulder width", value: 44, unit: "cm", confidence }, { region: "Torso length", value: 61, unit: "cm", confidence: { ...confidence, value: 0.82, level: "moderate", reasons: ["Good frame coverage"] } }] } };
  }
  async analyzeMovement(request: AIRequest<{ movement: "squat"; frames: unknown[] }>): Promise<AIResponse<MovementAnalysis>> {
    return { provider: "mock", requestId: `mock_move_${request.context.sessionId}`, latencyMs: 96, confidence, output: { movement: "squat", repetitions: [], tempoConsistency: 0.82, stability: 0.88, rangeOfMotion: 0.76, symmetry: 0.84, confidence, observations: ["Your latest repetitions were less consistent near the end.", "Try keeping the movement slower."] } };
  }
  async generateCoachResponse(request: AIRequest<CoachRequest>): Promise<AIResponse<CoachResponse>> {
    return { provider: "mock", requestId: `mock_coach_${request.context.sessionId}`, latencyMs: 140, confidence, output: { answer: "Your recent pattern looks steady. Keep your current rhythm and use a slower tempo when you want to explore control.", evidence: [{ type: "movement", description: "Recent movement check" }, { type: "habit", description: "Consistent weekly activity" }], confidence, suggestedActions: ["Try a 10-minute mobility reset", "Repeat a scan in two weeks"], safetyFlags: ["Fitness guidance only; not medical advice."] } };
  }
}
const providers: Record<string, AIProvider> = { mock: new MockAIProvider() };
export function registerAIProvider(provider: AIProvider) { providers[provider.name] = provider; }
export function getAIProvider(name = "mock"): AIProvider { const provider = providers[name]; if (!provider) throw new Error(`AI provider "${name}" is not registered`); return provider; }
