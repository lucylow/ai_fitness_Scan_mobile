export type AIModelType = "vision" | "pose" | "language" | "recommendation" | "classification" | "embedding";
export type AIProvider = "local" | "remote" | "mock";
export interface AIRequest<T = unknown> { id: string; model: AIModelType; provider: AIProvider; input: T; createdAt: number; }
export interface AIResponse<T = unknown> { requestId: string; model: AIModelType; output: T; confidence: number; latencyMs: number; provider: AIProvider; createdAt: number; }
export type AIErrorCode = "MODEL_UNAVAILABLE" | "INVALID_INPUT" | "LOW_CONFIDENCE" | "TIMEOUT" | "SAFETY_BLOCK" | "RATE_LIMIT" | "INVALID_OUTPUT" | "UNKNOWN";
export class AIError extends Error { constructor(public readonly code: AIErrorCode, message: string, public readonly retryable = false) { super(message); this.name = "AIError"; } }
export interface AIProviderAdapter { name: AIProvider; supports(model: AIModelType): boolean; generate<TInput, TOutput>(request: AIRequest<TInput>): Promise<AIResponse<TOutput>>; }
export class AIRouter { constructor(private readonly providers: AIProviderAdapter[]) {} select(model: AIModelType) { const provider = this.providers.find((candidate) => candidate.supports(model)); if (!provider) throw new AIError("MODEL_UNAVAILABLE", `No provider supports ${model}`); return provider; } }
export class AIOrchestrator { constructor(private readonly router: AIRouter) {} async run<TInput, TOutput>(request: AIRequest<TInput>) { const response = await this.router.select(request.model).generate<TInput, TOutput>(request); validateAIOutput(response.output); return { ...response, confidence: normalizeConfidence(response.confidence) }; } }
export function buildAIRequest<T>(model: AIModelType, input: T, provider: AIProvider = "mock"): AIRequest<T> { return { id: `ai_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`, model, provider, input, createdAt: Date.now() }; }
export function validateAIOutput(output: unknown) { if (output === null || output === undefined) throw new AIError("INVALID_OUTPUT", "AI returned empty output"); return true; }
export function normalizeConfidence(value: unknown) { const parsed = Number(value); return Number.isFinite(parsed) ? Math.max(0, Math.min(1, parsed)) : 0; }
export interface ConfidencePolicy { minimumForDisplay: number; minimumForAction: number; }
export const defaultConfidencePolicy: ConfidencePolicy = { minimumForDisplay: 0.55, minimumForAction: 0.7 };
export function canDisplay(confidence: number, policy = defaultConfidencePolicy) { return normalizeConfidence(confidence) >= policy.minimumForDisplay; }
export function canRecommendAction(confidence: number, policy = defaultConfidencePolicy) { return normalizeConfidence(confidence) >= policy.minimumForAction; }
export interface ModelDefinition { id: string; type: AIModelType; version: string; capabilities: string[]; active?: boolean; }
export class ModelRegistry { private readonly models = new Map<string, ModelDefinition>(); register(model: ModelDefinition) { this.models.set(model.id, model); } get(id: string) { return this.models.get(id); } list() { return [...this.models.values()]; } active(type?: AIModelType) { return this.list().filter((model) => model.active !== false && (!type || model.type === type)); } }
const blockedKeys = new Set(["password", "token", "secret", "accessToken", "refreshToken"]);
export function sanitizeAIInput(input: Record<string, unknown>) { return Object.fromEntries(Object.entries(input).filter(([key]) => !blockedKeys.has(key))); }
export interface PromptTemplate { id: string; version: string; system: string; user: string; }
export function renderPrompt(template: PromptTemplate, variables: Record<string, string>) { let user = template.user; Object.entries(variables).forEach(([key, value]) => { user = user.replaceAll(`{{${key}}}`, value); }); return { system: template.system, user }; }
export interface VisionFrame { uri: string; timestamp: number; width: number; height: number; }
export interface BoundingBox { x: number; y: number; width: number; height: number; }
export interface BodyDetection { detected: boolean; confidence: number; boundingBox?: BoundingBox; }
export interface PoseLandmark { name: string; x: number; y: number; z?: number; confidence: number; }
export interface PoseFrame { timestamp: number; landmarks: PoseLandmark[]; confidence: number; }
export interface MeasurementEstimate { name: string; value: number; unit: string; confidence: number; method: "mock" | "vision" | "manual"; }
export function boxArea(box: BoundingBox) { return Math.max(0, box.width) * Math.max(0, box.height); }
export function boxCenter(box: BoundingBox) { return { x: box.x + box.width / 2, y: box.y + box.height / 2 }; }
export function normalizeBox(box: BoundingBox, frame: { width: number; height: number }): BoundingBox { if (frame.width <= 0 || frame.height <= 0) return { x: 0, y: 0, width: 0, height: 0 }; return { x: box.x / frame.width, y: box.y / frame.height, width: box.width / frame.width, height: box.height / frame.height }; }
export function calculateFramingScore(box: BoundingBox) { const ideal = { x: .2, y: .05, width: .6, height: .9 }; const difference = Math.abs(box.x - ideal.x) + Math.abs(box.y - ideal.y) + Math.abs(box.width - ideal.width) + Math.abs(box.height - ideal.height); return Math.max(0, Math.min(1, 1 - difference)); }
export function bodyVisibility(box: BoundingBox) { return (Number(box.y >= 0 && box.y <= .1) + Number(box.y + box.height >= .85) + Number(box.x >= 0) + Number(box.x + box.width <= 1)) / 4; }
