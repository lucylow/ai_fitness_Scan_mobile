import type { SupportedLanguage } from "./i18n";
import { translate } from "./i18n";

export function formatActivityDate(timestamp: number, language: SupportedLanguage = "en") {
  return new Intl.DateTimeFormat(language, { month: "short", day: "numeric", year: "numeric" }).format(new Date(timestamp));
}

export function summarizeActivity(scans: number, workouts: number, language: SupportedLanguage = "en") {
  if (!scans && !workouts) return translate(language, "activity.empty", "No activity yet");
  const parts: string[] = [];
  if (scans) parts.push(translate(language, scans === 1 ? "activity.scan.one" : "activity.scan.other", `${scans} scan${scans === 1 ? "" : "s"}`, { count: scans }));
  if (workouts) parts.push(translate(language, workouts === 1 ? "activity.workout.one" : "activity.workout.other", `${workouts} workout${workouts === 1 ? "" : "s"}`, { count: workouts }));
  return parts.join(" · ");
}

export function formatStoredLocally(language: SupportedLanguage) {
  return translate(language, "activity.storedLocally", "Stored locally");
}

export function formatQuality(language: SupportedLanguage) {
  return translate(language, "activity.quality", "quality");
}
