import { translate, type SupportedLanguage } from "./i18n";

export type ProfileRecommendationAction = "start_workout" | "review_progress" | "complete_scan";

const actionKeys: Record<ProfileRecommendationAction, string> = {
  start_workout: "profile.action.startWorkout",
  review_progress: "profile.action.reviewProgress",
  complete_scan: "profile.action.completeScan",
};

export function localizedProfileAction(language: SupportedLanguage, action: ProfileRecommendationAction): string {
  return translate(language, actionKeys[action], action.replaceAll("_", " "));
}

export function localizedProfileRecommendation(language: SupportedLanguage, action: ProfileRecommendationAction): string {
  return translate(language, "profile.nextAction", "Your next best action is to {action}. You can change these preferences anytime.", { action: localizedProfileAction(language, action) });
}
