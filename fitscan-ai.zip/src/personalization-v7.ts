import type { PersonalizationProfile, UserAction } from "./personalization";

export type PersonalizationSignal =
  | "preference" | "goal" | "workout" | "scan" | "movement"
  | "habit" | "coach" | "feedback" | "schedule" | "engagement";

export interface PersonalizationSignalRecord {
  id: string;
  userId: string;
  type: PersonalizationSignal;
  feature: string;
  value: number;
  confidence: number;
  timestamp: number;
  metadata?: Record<string, unknown>;
}

export interface PersonalizationProfileV7 {
  userId: string;
  preferredWorkoutTypes: string[];
  preferredDurationMinutes: number;
  preferredDifficulty: "beginner" | "intermediate" | "advanced";
  preferredDays: number[];
  preferredHour?: number;
  favoriteExercises: string[];
  avoidedExercises: string[];
  coachTone: "friendly" | "concise" | "detailed" | "motivational" | "technical";
  proactiveCoach: boolean;
  recommendationConfidence: number;
  version: number;
  updatedAt: number;
}

export const defaultPersonalizationV7 = (userId: string, now = Date.now()): PersonalizationProfileV7 => ({
  userId, preferredWorkoutTypes: ["mixed"], preferredDurationMinutes: 20,
  preferredDifficulty: "beginner", preferredDays: [1, 3, 5], preferredHour: 17,
  favoriteExercises: [], avoidedExercises: [], coachTone: "friendly", proactiveCoach: true,
  recommendationConfidence: 0.35, version: 1, updatedAt: now,
});

const importance: Record<PersonalizationSignal, number> = {
  preference: 1, goal: 0.95, workout: 0.85, movement: 0.8, habit: 0.75,
  scan: 0.7, coach: 0.7, feedback: 0.95, schedule: 0.8, engagement: 0.5,
};

export const normalizeSignal = (value: number) => Math.max(0, Math.min(1, value));
export const signalImportance = (type: PersonalizationSignal) => importance[type];
export function recencyWeight(timestamp: number, now = Date.now(), halfLifeDays = 30) {
  const ageDays = Math.max(0, now - timestamp) / 86400000;
  return Math.pow(0.5, ageDays / Math.max(1, halfLifeDays));
}
export function signalScore(signal: PersonalizationSignalRecord, now = Date.now()) {
  return signal.value * normalizeSignal(signal.confidence) * signalImportance(signal.type) * recencyWeight(signal.timestamp, now);
}
export function aggregateSignals(signals: PersonalizationSignalRecord[], now = Date.now()): Record<string, number> {
  const totals = new Map<string, { score: number; weight: number }>();
  for (const signal of signals) {
    const current = totals.get(signal.feature) ?? { score: 0, weight: 0 };
    current.score += signalScore(signal, now);
    current.weight += normalizeSignal(signal.confidence);
    totals.set(signal.feature, current);
  }
  return Object.fromEntries([...totals].map(([feature, item]) => [feature, item.weight ? item.score / item.weight : 0]));
}

export function actionSignals(userId: string, actions: UserAction[], now = Date.now()): PersonalizationSignalRecord[] {
  return actions.map((action) => {
    const completed = ["workout_completed", "exercise_completed", "goal_completed", "recommendation_completed"].includes(action.type);
    const skipped = ["workout_skipped", "exercise_skipped"].includes(action.type);
    const type: PersonalizationSignal = skipped ? "feedback" : action.type.startsWith("coach") ? "coach" : action.type.startsWith("scan") ? "scan" : "workout";
    return { id: action.id, userId, type, feature: action.targetId ?? action.type, value: skipped ? 0 : completed ? 1 : 0.5, confidence: completed || skipped ? 0.9 : 0.5, timestamp: action.timestamp || now, metadata: action.metadata };
  });
}

export type NextBestAction = "start_workout" | "complete_scan" | "review_progress" | "ask_coach";
export interface Recommendation { action: NextBestAction; confidence: number; reasons: string[]; }
export function recommendNextAction(profile: PersonalizationProfileV7 | PersonalizationProfile, signals: PersonalizationSignalRecord[], now = Date.now()): Recommendation {
  const aggregated = aggregateSignals(signals, now);
  const completed = aggregated["workout_completed"] ?? 0;
  const scans = aggregated["scan_completed"] ?? 0;
  const engagement = Object.keys(aggregated).length;
  if (scans < 0.35) return { action: "complete_scan", confidence: 0.82, reasons: ["A baseline scan would improve personalization."] };
  if (completed < 0.45) return { action: "start_workout", confidence: 0.74, reasons: [`A ${profile.preferredDurationMinutes}-minute ${profile.preferredWorkoutTypes[0] ?? "mixed"} session matches your preferences.`] };
  const detailedCoaching = "coachTone" in profile ? profile.coachTone === "detailed" : profile.coachingStyle === "detailed";
  if (detailedCoaching) return { action: "ask_coach", confidence: 0.6, reasons: ["Your coaching preference favors more guidance."] };
  return { action: "review_progress", confidence: Math.min(0.9, 0.45 + engagement * 0.04), reasons: ["Recent activity is ready for a progress review."] };
}

export function recommendationConfidence(recommendations: Recommendation[]): number {
  if (!recommendations.length) return 0;
  return recommendations.reduce((sum, item) => sum + item.confidence, 0) / recommendations.length;
}
