import type { SupportedLanguage } from "./i18n";
import { formatNumber, translate } from "./i18n";
import type { ExerciseDefinition } from "./workouts/v6";

export interface ExercisePrescription {
  sets: number;
  targetLabel: string;
  restSeconds: number;
}

export function prescriptionForExercise(exercise: ExerciseDefinition): ExercisePrescription {
  const sets = Math.max(1, exercise.defaultSets);
  const restSeconds = Math.max(10, exercise.defaultRestSeconds);
  const targetLabel = exercise.defaultReps ? `${exercise.defaultReps} reps` : `${Math.max(10, exercise.defaultSeconds ?? 30)} sec`;
  return { sets, targetLabel, restSeconds };
}

export function prescriptionSummary(prescription: ExercisePrescription): string {
  return `${prescription.sets} sets × ${prescription.targetLabel} · ${prescription.restSeconds}s rest`;
}

export function localizedPrescriptionSummary(language: SupportedLanguage, prescription: ExercisePrescription): string {
  const targetMatch = /^(\d+)\s+(reps|sec)$/.exec(prescription.targetLabel.trim());
  const target = targetMatch
    ? translate(language, targetMatch[2] === "reps" ? "workout.prescription.reps" : "workout.prescription.seconds", targetMatch[2] === "reps" ? "{count} reps" : "{count} sec", { count: formatNumber(Number(targetMatch[1]), language) })
    : prescription.targetLabel;
  const rest = translate(language, "workout.prescription.rest", "{seconds}s rest", { seconds: formatNumber(prescription.restSeconds, language) });
  return translate(language, "workout.prescription.summary", "{sets} sets × {target} · {rest}", { sets: formatNumber(prescription.sets, language), target, rest });
}
