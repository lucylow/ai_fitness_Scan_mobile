import type { Difficulty, Equipment, ExerciseDefinition } from "@/src/workouts/v6";

export function difficultyAwareCatalog(catalog: ExerciseDefinition[], preferred: Difficulty): ExerciseDefinition[] {
  const matching = catalog.filter((exercise) => exercise.difficulty === preferred);
  return matching.length ? matching : catalog;
}

export function equipmentAwareCatalog(catalog: ExerciseDefinition[], available: Equipment[]): ExerciseDefinition[] {
  const compatible = catalog.filter((exercise) => exercise.equipment.every((item) => item === "none" || available.includes(item)));
  return compatible.length ? compatible : catalog.filter((exercise) => exercise.equipment.includes("none"));
}

export function clampSessionDuration(minutes: number): number {
  return Math.max(5, Math.min(180, Math.round(minutes)));
}
