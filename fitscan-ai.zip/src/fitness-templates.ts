export type FitnessEquipment = "none" | "mat" | "band" | "dumbbells";

export type FitnessTemplateDefinition = {
  id: string;
  requiredEquipment: readonly FitnessEquipment[];
};

/**
 * Keeps a template visible when all of its required equipment is available.
 * Bodyweight templates declare `none` and remain available for every profile.
 */
export function filterFitnessTemplates<T extends FitnessTemplateDefinition>(
  templates: readonly T[],
  availableEquipment: readonly FitnessEquipment[],
): T[] {
  const equipment = new Set(availableEquipment);
  return templates.filter((template) =>
    template.requiredEquipment.every((item) => item === "none" || equipment.has(item)),
  );
}

export function hasVisibleFitnessTemplates<T extends FitnessTemplateDefinition>(
  templates: readonly T[],
  availableEquipment: readonly FitnessEquipment[],
): boolean {
  return filterFitnessTemplates(templates, availableEquipment).length > 0;
}
