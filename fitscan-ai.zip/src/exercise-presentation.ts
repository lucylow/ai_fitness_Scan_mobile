import type { SupportedLanguage } from "./i18n";
import { translate } from "./i18n";
import type { ExerciseDefinition } from "./workouts/v6";

const exerciseKeys: Record<string, { name: string; instruction: string }> = {
  "air-squat": { name: "exercise.airSquat.name", instruction: "exercise.airSquat.instruction" },
  "wall-pushup": { name: "exercise.wallPushup.name", instruction: "exercise.wallPushup.instruction" },
  "dead-bug": { name: "exercise.deadBug.name", instruction: "exercise.deadBug.instruction" },
  "reverse-lunge": { name: "exercise.reverseLunge.name", instruction: "exercise.reverseLunge.instruction" },
  pushup: { name: "exercise.pushup.name", instruction: "exercise.pushup.instruction" },
  "split-squat": { name: "exercise.splitSquat.name", instruction: "exercise.splitSquat.instruction" },
};

export function localizedExerciseName(language: SupportedLanguage, exercise: ExerciseDefinition): string {
  const keys = exerciseKeys[exercise.id];
  return keys ? translate(language, keys.name, exercise.name) : exercise.name;
}

export function localizedExerciseInstruction(language: SupportedLanguage, exercise: ExerciseDefinition, index = 0): string {
  const fallback = exercise.instructions[index] ?? exercise.instructions[0] ?? "";
  const keys = exerciseKeys[exercise.id];
  return keys ? translate(language, keys.instruction, fallback) : fallback;
}
