import { APP_STATE_SCHEMA_VERSION } from "./app-state-constants";
import type { AppState, CoachTone, InterruptedActivity, PreferredDifficulty, SessionDuration } from "./app-state";
import type { Equipment } from "@/src/workouts/v6";
import { normalizeLanguage } from "../i18n-device";

const tones: CoachTone[] = ["calm", "encouraging", "direct"];
const difficulties: PreferredDifficulty[] = ["beginner", "intermediate", "advanced"];
const durations: SessionDuration[] = [15, 30, 45];
const equipment: Equipment[] = ["none", "mat", "band", "dumbbells", "bench", "chair", "pullup_bar"];

const isRecord = (value: unknown): value is Record<string, unknown> => Boolean(value) && typeof value === "object";
const oneOf = <T extends string>(value: unknown, values: readonly T[], fallback: T) => values.includes(value as T) ? value as T : fallback;
const normalizeInterruptedActivity = (value: unknown): InterruptedActivity | undefined => {
  if (!isRecord(value) || (value.kind !== "scan" && value.kind !== "workout") || typeof value.id !== "string" || typeof value.step !== "string" || typeof value.updatedAt !== "number") return undefined;
  const exerciseIndex = typeof value.exerciseIndex === "number" && Number.isInteger(value.exerciseIndex) && value.exerciseIndex >= 0 ? value.exerciseIndex : undefined;
  const secondsRemaining = typeof value.secondsRemaining === "number" && Number.isInteger(value.secondsRemaining) && value.secondsRemaining >= 0 ? value.secondsRemaining : undefined;
  return { kind: value.kind, id: value.id, step: value.step, updatedAt: value.updatedAt, scanView: typeof value.scanView === "number" ? value.scanView : undefined, workoutRound: typeof value.workoutRound === "number" ? value.workoutRound : undefined, exerciseIndex, totalSteps: typeof value.totalSteps === "number" ? value.totalSteps : undefined, secondsRemaining, pausedByLifecycle: typeof value.pausedByLifecycle === "boolean" ? value.pausedByLifecycle : undefined };
};

export type MigrationReadiness = "ready" | "migrated" | "recovered";
export function persistenceStatusFor(raw: unknown, currentVersion: number): MigrationReadiness {
  if (!isRecord(raw)) return "recovered";
  return raw.schemaVersion === currentVersion ? "ready" : "migrated";
}

export function normalizeAppState(raw: unknown, defaults: AppState): AppState {
  const input = isRecord(raw) ? raw : {};
  const selectedEquipment = Array.isArray(input.availableEquipment) ? input.availableEquipment.filter((item): item is Equipment => equipment.includes(item as Equipment)) : defaults.availableEquipment;
  const selectedPreviewEquipment = Array.isArray(input.previewEquipment) ? input.previewEquipment.filter((item): item is Equipment => equipment.includes(item as Equipment)) : defaults.previewEquipment;
  const previewEquipment = selectedPreviewEquipment.length ? [...new Set(selectedPreviewEquipment)] : ["none"];
  const rawDuration = typeof input.preferredDurationMinutes === "number" ? input.preferredDurationMinutes : Number(input.preferredDurationMinutes);
  const preferredDurationMinutes = durations.includes(rawDuration as SessionDuration) ? rawDuration as SessionDuration : defaults.preferredDurationMinutes;
  const dismissedMigrationNoticeVersion = typeof input.dismissedMigrationNoticeVersion === "number" && Number.isInteger(input.dismissedMigrationNoticeVersion) && input.dismissedMigrationNoticeVersion >= 0 ? input.dismissedMigrationNoticeVersion : defaults.dismissedMigrationNoticeVersion;
  const availableEquipment = selectedEquipment.length ? [...new Set(selectedEquipment)] : ["none"];
  return {
    ...defaults,
    schemaVersion: APP_STATE_SCHEMA_VERSION,
    ...input,
    language: input.language === undefined ? defaults.language : normalizeLanguage(input.language),
    languageFollowsDevice: typeof input.languageFollowsDevice === "boolean" ? input.languageFollowsDevice : input.language === undefined,
    reduceMotion: typeof input.reduceMotion === "boolean" ? input.reduceMotion : defaults.reduceMotion,
    coachTone: oneOf(input.coachTone, tones, defaults.coachTone),
    preferredDurationMinutes,
    preferredDifficulty: oneOf(input.preferredDifficulty, difficulties, defaults.preferredDifficulty),
    dismissedMigrationNoticeVersion,
    scanRemindersEnabled: typeof input.scanRemindersEnabled === "boolean" ? input.scanRemindersEnabled : defaults.scanRemindersEnabled,
    availableEquipment: (availableEquipment.includes("none") && availableEquipment.length > 1 ? availableEquipment.filter((item) => item !== "none") : availableEquipment) as Equipment[],
    previewEquipment: (previewEquipment.includes("none") && previewEquipment.length > 1 ? previewEquipment.filter((item) => item !== "none") : previewEquipment) as Equipment[],
    interests: Array.isArray(input.interests) ? input.interests.filter((item): item is string => typeof item === "string").slice(0, 20) : defaults.interests,
    scans: Array.isArray(input.scans) ? input.scans : defaults.scans,
    workouts: Array.isArray(input.workouts) ? input.workouts : defaults.workouts,
    interruptedActivity: normalizeInterruptedActivity(input.interruptedActivity) ?? defaults.interruptedActivity,
  };
}
