import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, ReactNode, useContext, useEffect, useMemo, useState } from "react";
import { AppState as NativeAppState } from "react-native";
import type { SupportedLanguage } from "@/src/i18n";
import { detectDeviceLanguage, shouldRefreshDeviceLanguage } from "@/src/i18n-device";
import type { EffortRangeDays } from "@/src/personalization-adapter";
import type { Equipment } from "@/src/workouts/v6";
import { APP_STATE_SCHEMA_VERSION } from "./app-state-constants";
import { normalizeAppState, persistenceStatusFor } from "./app-state-migration";

export interface StoredScan { id: string; createdAt: number; quality: number; status: "complete" | "processing" | "failed"; label: string; }
export interface StoredWorkout { id: string; completedAt: number; durationMinutes: number; label: string; effort?: number; }
export type CoachTone = "calm" | "encouraging" | "direct";
export type PreferredDifficulty = "beginner" | "intermediate" | "advanced";
export type SessionDuration = 15 | 30 | 45;
export interface InterruptedActivity { kind: "scan" | "workout"; id: string; step: string; updatedAt: number; scanView?: number; workoutRound?: number; exerciseIndex?: number; totalSteps?: number; secondsRemaining?: number; pausedByLifecycle?: boolean; }
export { APP_STATE_SCHEMA_VERSION } from "./app-state-constants";
export interface AppState { schemaVersion: number; hasCompletedOnboarding: boolean; demoMode: boolean; displayName: string; preferredUnit: "metric" | "imperial"; language: SupportedLanguage; languageFollowsDevice: boolean; reduceMotion: boolean; effortRangeDays: EffortRangeDays; coachTone: CoachTone; preferredDurationMinutes: SessionDuration; preferredDifficulty: PreferredDifficulty; availableEquipment: Equipment[]; previewEquipment: Equipment[]; dismissedMigrationNoticeVersion?: number; scanRemindersEnabled: boolean; interests: string[]; scans: StoredScan[]; workouts: StoredWorkout[]; interruptedActivity?: InterruptedActivity; }
const initialState: AppState = { schemaVersion: APP_STATE_SCHEMA_VERSION, hasCompletedOnboarding: false, demoMode: false, displayName: "Alex", preferredUnit: "metric", language: detectDeviceLanguage(), languageFollowsDevice: true, reduceMotion: false, effortRangeDays: 30, coachTone: "encouraging", preferredDurationMinutes: 30, preferredDifficulty: "beginner", availableEquipment: ["none"], previewEquipment: ["none"], dismissedMigrationNoticeVersion: undefined, scanRemindersEnabled: false, interests: ["movement awareness"], scans: [], workouts: [] };
export type PersistenceStatus = "hydrating" | "ready" | "migrated" | "recovered";
interface AppStateContextValue { state: AppState; hydrated: boolean; persistenceStatus: PersistenceStatus; updateState: (patch: Partial<AppState>) => void; addScan: (scan: StoredScan) => void; addWorkout: (workout: StoredWorkout) => void; setInterruptedActivity: (activity: InterruptedActivity) => void; clearInterruptedActivity: () => void; resetLocalData: () => Promise<void>; }
const AppStateContext = createContext<AppStateContextValue | null>(null);
const STORAGE_KEY = "fitscan_ai_state_v1";
async function persistAppState(nextState: AppState, onFailure: () => void) {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(nextState));
  } catch {
    onFailure();
  }
}
export function AppStateProvider({ children }: { children: ReactNode }) { const [state, setState] = useState(initialState); const [hydrated, setHydrated] = useState(false); const [persistenceStatus, setPersistenceStatus] = useState<PersistenceStatus>("hydrating"); useEffect(() => { AsyncStorage.getItem(STORAGE_KEY).then((value) => { if (value) { try { const parsed = JSON.parse(value) as Record<string, unknown>; setState(normalizeAppState(parsed, initialState)); setPersistenceStatus(persistenceStatusFor(parsed, APP_STATE_SCHEMA_VERSION)); } catch { setState(initialState); setPersistenceStatus("recovered"); } } else { setPersistenceStatus("ready"); } setHydrated(true); }).catch(() => { setPersistenceStatus("recovered"); setHydrated(true); }); }, []);   useEffect(() => { if (hydrated) void persistAppState(state, () => setPersistenceStatus("recovered")); }, [state, hydrated]); useEffect(() => { if (!hydrated) return; const subscription = NativeAppState.addEventListener("change", (nextState) => { if (nextState !== "active") return; const detected = detectDeviceLanguage(); setState((current) => shouldRefreshDeviceLanguage(!current.languageFollowsDevice, current.language, detected) ? { ...current, language: detected } : current); }); return () => subscription.remove(); }, [hydrated]); const value = useMemo<AppStateContextValue>(() => ({ state, hydrated, persistenceStatus, updateState: (patch) => setState((current) => ({ ...current, ...patch })), addScan: (scan) => setState((current) => ({ ...current, scans: [scan, ...current.scans].slice(0, 20) })), addWorkout: (workout) => setState((current) => ({ ...current, workouts: [workout, ...current.workouts].slice(0, 50) })), setInterruptedActivity: (activity) => setState((current) => ({ ...current, interruptedActivity: activity })), clearInterruptedActivity: () => setState((current) => { const next = { ...current }; delete next.interruptedActivity; return next; }), resetLocalData: async () => { try { await AsyncStorage.removeItem(STORAGE_KEY); setState(initialState); setPersistenceStatus("ready"); } catch { setPersistenceStatus("recovered"); throw new Error("Unable to reset local data"); } } }), [state, hydrated, persistenceStatus]); return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>; }
export function useAppState() { const value = useContext(AppStateContext); if (!value) throw new Error("useAppState must be used within AppStateProvider"); return value; }
