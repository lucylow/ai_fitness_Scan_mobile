import type { SupportedLanguage } from "./i18n";
import { translate } from "./i18n";
import { adaptNextInstruction } from "./workouts/v6";

const cueKeys = {
  reduce: "workout.adaptiveCue.reduce",
  progress: "workout.adaptiveCue.progress",
  steady: "workout.adaptiveCue.steady",
} as const;

function cueKey(completedSets: number, targetSets: number, perceivedEffort: number): string {
  const cue = adaptNextInstruction(completedSets, targetSets, perceivedEffort);
  if (cue.startsWith("Reduce the next set")) return cueKeys.reduce;
  if (cue.startsWith("You have room to progress")) return cueKeys.progress;
  return cueKeys.steady;
}

export function localizedAdaptiveCue(language: SupportedLanguage, completedSets: number, targetSets: number, perceivedEffort: number): string {
  const key = cueKey(completedSets, targetSets, perceivedEffort);
  return translate(language, key, adaptNextInstruction(completedSets, targetSets, perceivedEffort));
}

export function localizedAdaptiveCueAccessibilityLabel(language: SupportedLanguage, completedSets: number, targetSets: number, perceivedEffort: number): string {
  return translate(language, "workout.adaptiveCue.label", "Adaptive coaching cue: {cue}", { cue: localizedAdaptiveCue(language, completedSets, targetSets, perceivedEffort) });
}
