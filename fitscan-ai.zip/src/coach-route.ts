export interface CoachRequestInput {
  message: string;
  conversation: [];
}

export function normalizeCoachQuestion(message: unknown): string {
  if (typeof message !== "string") return "How should I train today?";
  const normalized = message.trim();
  return normalized || "How should I train today?";
}

export function canSubmitCoachRequest(isAsking: boolean): boolean {
  return !isAsking;
}

export function buildCoachRequestInput(message: unknown): CoachRequestInput {
  return { message: normalizeCoachQuestion(message), conversation: [] };
}
