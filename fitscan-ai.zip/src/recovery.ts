export function clampProgress(value: number | undefined, total: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(Math.max(0, total), Math.trunc(value as number)));
}

export function resumeScanView(view: number | undefined, totalViews = 3): number {
  return clampProgress(view, Math.max(0, totalViews - 1));
}

export function resumeWorkoutRound(round: number | undefined, totalRounds = 3): number {
  return Math.max(1, Math.min(Math.max(1, totalRounds), Math.trunc(round ?? 1)));
}

export function recoveryLabel(kind: "scan" | "workout", progress: number, total: number): string {
  return kind === "scan" ? `Scan view ${progress + 1} of ${total}` : `Workout round ${progress} of ${total}`;
}
