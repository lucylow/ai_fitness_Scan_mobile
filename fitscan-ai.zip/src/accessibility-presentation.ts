import type { SupportedLanguage } from "./i18n";
import { formatNumber, translate } from "./i18n";

export function localizedScanQualityAccessibilityLabel(language: SupportedLanguage, percent: number, guidance: string): string {
  return translate(language, "scan.accessibility.quality", "Scan quality: {percent} percent, {guidance}", { percent: formatNumber(percent, language), guidance });
}

export function localizedScanLandmarksAccessibilityLabel(language: SupportedLanguage, landmarkCount: number): string {
  return translate(language, "scan.accessibility.landmarks", "Body alignment guide with {count} landmarks", { count: formatNumber(landmarkCount, language) });
}

export function localizedScanResultAccessibilityLabel(language: SupportedLanguage, confidencePercent: number): string {
  return translate(language, "scan.accessibility.result", "Scan result, {percent} percent confidence", { percent: formatNumber(confidencePercent, language) });
}

export function localizedMobilityAccessibilityLabel(language: SupportedLanguage, direction: "increasing" | "steady", change: number): string {
  const trend = translate(language, direction === "increasing" ? "progress.mobilityIncreasing" : "progress.mobilitySteady");
  return translate(language, "progress.accessibility.mobility", "Mobility trend: {trend}. {change} points across your last 2 scans.", { trend, change: formatNumber(Math.round(change), language) });
}

export function localizedEffortAccessibilityLabel(language: SupportedLanguage, average: number | null, direction: "increasing" | "decreasing" | "steady" | null): string {
  const effort = average === null ? translate(language, "progress.effortStart") : translate(language, "progress.effortAverage", "{value}/10 average effort", { value: formatNumber(average, language) });
  const trend = direction ? translate(language, direction === "increasing" ? "progress.effortRising" : direction === "decreasing" ? "progress.effortEasing" : "progress.effortSteady") : "";
  return translate(language, "progress.accessibility.effort", "Workout effort: {effort}. {trend}", { effort, trend });
}

export function localizedScanHistoryAccessibilityLabel(language: SupportedLanguage, label: string, date: string, quality: string, storedLocally: string): string {
  return translate(language, "progress.accessibility.scan", "{label}, {date}, {quality}, {stored}", { label, date, quality, stored: storedLocally });
}

export function localizedFitnessPreviewSelectionLabel(language: SupportedLanguage, label: string, selected: boolean): string {
  const selectedLabel = selected ? translate(language, "fitness.accessibility.selected", ", selected") : "";
  return translate(language, "fitness.accessibility.previewSelection", "Equipment preview: {label}{selected}", { label, selected: selectedLabel });
}

export function localizedProfileOptionAccessibilityLabel(language: SupportedLanguage, label: string, selected: boolean): string {
  return selected ? translate(language, "profile.accessibility.selected", "{label}, selected", { label }) : label;
}
