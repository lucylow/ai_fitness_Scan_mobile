import { useEffect, useRef, useState, type ReactNode } from "react";
import { AccessibilityInfo, Animated, Pressable, type PressableProps, type StyleProp, type TextStyle, type ViewStyle } from "react-native";
import { animationDuration, normalizeAnimationProgress } from "./animation-core";
import { useAppState } from "@/src/state/app-state";

export function useReducedMotionPreference() {
  const { state } = useAppState();
  const [deviceReduceMotion, setDeviceReduceMotion] = useState(false);

  useEffect(() => {
    let mounted = true;
    AccessibilityInfo.isReduceMotionEnabled().then((enabled) => {
      if (mounted) setDeviceReduceMotion(enabled);
    }).catch(() => undefined);
    const subscription = AccessibilityInfo.addEventListener("reduceMotionChanged", setDeviceReduceMotion);
    return () => {
      mounted = false;
      subscription?.remove();
    };
  }, []);

  return state.reduceMotion || deviceReduceMotion;
}

export function AnimatedReveal({ children, delay = 0, style }: { children: ReactNode; delay?: number; style?: StyleProp<ViewStyle> }) {
  const reduceMotion = useReducedMotionPreference();
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(8)).current;

  useEffect(() => {
    if (reduceMotion) {
      opacity.setValue(1);
      translateY.setValue(0);
      return;
    }
    opacity.setValue(0);
    translateY.setValue(8);
    const animation = Animated.parallel([
      Animated.timing(opacity, { toValue: 1, duration: animationDuration(reduceMotion, 260), delay, useNativeDriver: true }),
      Animated.timing(translateY, { toValue: 0, duration: animationDuration(reduceMotion, 260), delay, useNativeDriver: true }),
    ]);
    animation.start();
    return () => animation.stop();
  }, [delay, opacity, reduceMotion, translateY]);

  return <Animated.View style={[{ opacity, transform: [{ translateY }] }, style]}>{children}</Animated.View>;
}

export function AnimatedPressable({ children, style, onPressIn, onPressOut, ...props }: PressableProps) {
  const reduceMotion = useReducedMotionPreference();
  const scale = useRef(new Animated.Value(1)).current;
  const animateScale = (toValue: number) => {
    if (reduceMotion) {
      scale.setValue(1);
      return;
    }
    Animated.timing(scale, { toValue, duration: animationDuration(reduceMotion, 90), useNativeDriver: true }).start();
  };

  return (
    <Pressable
      {...props}
      onPressIn={(event) => {
        animateScale(0.98);
        onPressIn?.(event);
      }}
      onPressOut={(event) => {
        animateScale(1);
        onPressOut?.(event);
      }}
      style={(state) => {
        const resolvedStyle = typeof style === "function" ? style(state) : style;
        return [resolvedStyle, { transform: [{ scale }] }];
      }}
    >
      {children}
    </Pressable>
  );
}

export function AnimatedNumber({ value, prefix = "", suffix = "", duration = 420, style }: { value: number; prefix?: string; suffix?: string; duration?: number; style?: StyleProp<TextStyle> }) {
  const reduceMotion = useReducedMotionPreference();
  const animatedValue = useRef(new Animated.Value(value)).current;
  const [displayValue, setDisplayValue] = useState(value);

  useEffect(() => {
    if (reduceMotion) {
      animatedValue.setValue(value);
      setDisplayValue(value);
      return;
    }
    const listenerId = animatedValue.addListener(({ value: nextValue }) => setDisplayValue(Math.round(nextValue)));
    const animation = Animated.timing(animatedValue, { toValue: value, duration: animationDuration(reduceMotion, duration), useNativeDriver: false });
    animation.start(({ finished }) => {
      if (finished) setDisplayValue(value);
    });
    return () => {
      animatedValue.removeListener(listenerId);
      animation.stop();
    };
  }, [animatedValue, duration, reduceMotion, value]);

  return <Animated.Text style={style}>{prefix}{displayValue}{suffix}</Animated.Text>;
}

export function AnimatedProgress({ progress, style }: { progress: number; style?: StyleProp<ViewStyle> }) {
  const reduceMotion = useReducedMotionPreference();
  const width = useRef(new Animated.Value(0)).current;
  const clampedProgress = normalizeAnimationProgress(progress);

  useEffect(() => {
    if (reduceMotion) {
      width.setValue(clampedProgress);
      return;
    }
    const animation = Animated.timing(width, { toValue: clampedProgress, duration: animationDuration(reduceMotion, 320), useNativeDriver: false });
    animation.start();
    return () => animation.stop();
  }, [clampedProgress, reduceMotion, width]);

  return <Animated.View style={[{ width: width.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] }) }, style]} />;
}
