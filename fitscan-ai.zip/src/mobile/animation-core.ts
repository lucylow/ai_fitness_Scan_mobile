export function animationDuration(reduceMotion: boolean, duration: number) {
  return reduceMotion ? 0 : Math.max(0, duration);
}

export function normalizeAnimationProgress(progress: number) {
  return Math.max(0, Math.min(1, progress));
}
