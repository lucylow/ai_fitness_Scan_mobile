import { Platform } from "react-native";
import { Camera } from "expo-camera";
import type { CameraCapabilities, CameraPermissionService, PermissionStatus } from "./scan-pipeline";

function mapStatus(status: string): PermissionStatus { return status === "granted" ? "granted" : status === "denied" ? "denied" : "undetermined"; }
export const expoCameraPermissionService: CameraPermissionService = { async getStatus() { if (Platform.OS === "web") return "undetermined"; return mapStatus((await Camera.getCameraPermissionsAsync()).status); }, async request() { if (Platform.OS === "web") return "denied"; return mapStatus((await Camera.requestCameraPermissionsAsync()).status) as "granted" | "denied"; } };
export async function getCameraCapabilities(): Promise<CameraCapabilities> { if (Platform.OS === "web") return { available: true, rearCamera: true, frontCamera: true, flash: false, video: true, photo: true, supportsTorch: false, deviceModel: "web-camera" }; const permission = await Camera.getCameraPermissionsAsync(); const available = permission.status !== "denied"; return { available, rearCamera: available, frontCamera: available, flash: available, video: available, photo: available, supportsTorch: available }; }
export async function getCameraReadiness() { const [capabilities, permission] = await Promise.all([getCameraCapabilities(), expoCameraPermissionService.getStatus()]); return { capabilities, permission, ready: capabilities.available && permission === "granted" }; }
