export type VisualMediaType = "image" | "video" | "landmark" | "silhouette" | "mesh" | "chart" | "animation";

export interface LandmarkPoint {
  name: string;
  x: number;
  y: number;
  z?: number;
  confidence: number;
}

export interface VisualQualityInput {
  brightness: number;
  sharpness: number;
  contrast: number;
  stability: number;
  subjectVisibility: number;
}

export interface VisualQuality extends VisualQualityInput {
  overall: number;
}

export interface VisualFrame {
  id: string;
  timestamp: number;
  uri?: string;
  landmarks: LandmarkPoint[];
  quality: VisualQuality;
  angle: number;
}

const clamp01 = (value: number) => Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0));

export function calculateVisualQuality(input: VisualQualityInput): VisualQuality {
  const normalized = {
    brightness: clamp01(input.brightness),
    sharpness: clamp01(input.sharpness),
    contrast: clamp01(input.contrast),
    stability: clamp01(input.stability),
    subjectVisibility: clamp01(input.subjectVisibility),
  };
  const overall = normalized.brightness * 0.15 + normalized.sharpness * 0.2 + normalized.contrast * 0.1 + normalized.stability * 0.2 + normalized.subjectVisibility * 0.35;
  return { ...normalized, overall: clamp01(overall) };
}

export function shouldAcceptVisualFrame(quality: VisualQuality, minimum = 0.65): boolean {
  return quality.overall >= clamp01(minimum) && quality.subjectVisibility >= 0.6;
}

export function filterLandmarks(landmarks: LandmarkPoint[], confidence = 0.65): LandmarkPoint[] {
  const threshold = clamp01(confidence);
  return landmarks.filter((point) => point.confidence >= threshold);
}

export function normalizeLandmarks(landmarks: LandmarkPoint[], width: number, height: number): LandmarkPoint[] {
  return landmarks.map((point) => ({ ...point, x: width > 0 ? clamp01(point.x / width) : 0, y: height > 0 ? clamp01(point.y / height) : 0 }));
}

export function visualGuidanceLabel(quality: VisualQuality): "ready" | "adjust" | "reframe" {
  if (quality.overall >= 0.8 && quality.subjectVisibility >= 0.75) return "ready";
  if (quality.subjectVisibility >= 0.6) return "adjust";
  return "reframe";
}

export function visualQualityPercent(quality: VisualQuality): number {
  return Math.round(clamp01(quality.overall) * 100);
}
